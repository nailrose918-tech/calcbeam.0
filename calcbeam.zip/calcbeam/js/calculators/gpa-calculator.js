(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const rowsWrap = document.getElementById("courseRows");
  const GRADE_POINTS = { "A+":4.0,"A":4.0,"A-":3.7,"B+":3.3,"B":3.0,"B-":2.7,"C+":2.3,"C":2.0,"C-":1.7,"D+":1.3,"D":1.0,"F":0.0 };
  let rowCount = 0;

  function addRow(grade, credits){
    rowCount++;
    const id = "course" + rowCount;
    const div = document.createElement("div");
    div.className = "field-row";
    div.style.alignItems = "end";
    div.innerHTML = `
      <div class="field">
        <label for="${id}-grade">Course ${rowCount} grade</label>
        <select id="${id}-grade" class="gpa-grade">
          ${Object.keys(GRADE_POINTS).map(g => `<option value="${g}" ${g===(grade||"A")?"selected":""}>${g}</option>`).join("")}
        </select>
      </div>
      <div class="field" style="display:flex;gap:8px;align-items:flex-end;">
        <div style="flex:1;">
          <label for="${id}-credits">Credit hours</label>
          <input type="number" id="${id}-credits" class="gpa-credits" min="0" step="0.5" value="${credits || 3}">
        </div>
        <button type="button" class="icon-btn remove-row" aria-label="Remove course" style="margin-bottom:2px;">&times;</button>
      </div>`;
    rowsWrap.appendChild(div);
    div.querySelector(".gpa-grade").addEventListener("change", calculate);
    div.querySelector(".gpa-credits").addEventListener("input", calculate);
    div.querySelector(".remove-row").addEventListener("click", () => { div.remove(); calculate(); });
  }

  function calculate(){
    CalcUtils.clearError(err);
    const grades = rowsWrap.querySelectorAll(".gpa-grade");
    const credits = rowsWrap.querySelectorAll(".gpa-credits");
    let totalPoints = 0, totalCredits = 0;
    let hasInvalid = false;

    grades.forEach((g, i) => {
      const c = CalcUtils.num(credits[i].value);
      if(Number.isNaN(c) || c < 0){ hasInvalid = true; return; }
      totalPoints += GRADE_POINTS[g.value] * c;
      totalCredits += c;
    });

    if(grades.length === 0){ showEmpty(); return; }
    if(hasInvalid){ CalcUtils.showError(err, "Credit hours must be zero or a positive number."); }
    if(totalCredits === 0){ showEmpty(); return; }

    const gpa = totalPoints / totalCredits;
    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmt(gpa,2)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Total credit hours</span><span class="rval">${CalcUtils.fmt(totalCredits,1)}</span></div>
        <div class="result-row"><span class="rlabel">Total quality points</span><span class="rval">${CalcUtils.fmt(totalPoints,2)}</span></div>
        <div class="result-row"><span class="rlabel">Courses counted</span><span class="rval">${grades.length}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Add your courses to calculate GPA.</p>';
  }

  document.getElementById("addCourseBtn").addEventListener("click", () => { addRow(); calculate(); });
  document.getElementById("calcReset").addEventListener("click", () => {
    rowsWrap.innerHTML = "";
    rowCount = 0;
    addRow("A", 3); addRow("B+", 3); addRow("A-", 4);
    CalcUtils.clearError(err);
    calculate();
  });

  addRow("A", 3); addRow("B+", 3); addRow("A-", 4);
  calculate();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("gpa-calculator");
})();
