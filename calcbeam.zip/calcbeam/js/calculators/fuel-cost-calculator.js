(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["fcDistance","fcEfficiency","fcPrice"];

  function calculate(){
    CalcUtils.clearError(err);
    const distance = CalcUtils.num(document.getElementById("fcDistance").value);
    const mpg = CalcUtils.num(document.getElementById("fcEfficiency").value);
    const price = CalcUtils.num(document.getElementById("fcPrice").value);
    if([distance, mpg, price].some(Number.isNaN)){ showEmpty(); return; }
    if(distance < 0 || price < 0){ CalcUtils.showError(err, "Distance and price can't be negative."); showEmpty(); return; }
    if(mpg <= 0){ CalcUtils.showError(err, "Fuel efficiency must be greater than zero."); showEmpty(); return; }

    const gallonsNeeded = distance / mpg;
    const cost = gallonsNeeded * price;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtMoney(cost)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Distance</span><span class="rval">${CalcUtils.fmt(distance)} miles</span></div>
        <div class="result-row"><span class="rlabel">Fuel efficiency</span><span class="rval">${CalcUtils.fmt(mpg)} mpg</span></div>
        <div class="result-row"><span class="rlabel">Fuel needed</span><span class="rval">${CalcUtils.fmt(gallonsNeeded)} gallons</span></div>
        <div class="result-row"><span class="rlabel">Estimated cost</span><span class="rval">${CalcUtils.fmtMoney(cost)}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter distance, fuel efficiency, and price per gallon to see the trip cost.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("fuel-cost-calculator");
})();
