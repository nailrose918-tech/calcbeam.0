(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["homePrice","downPayment","interestRate","loanTerm","propertyTax","homeInsurance"];

  function calculate(){
    CalcUtils.clearError(err);
    const price = CalcUtils.num(document.getElementById("homePrice").value);
    const down = CalcUtils.num(document.getElementById("downPayment").value) || 0;
    const rate = CalcUtils.num(document.getElementById("interestRate").value);
    const years = CalcUtils.num(document.getElementById("loanTerm").value);
    const tax = CalcUtils.num(document.getElementById("propertyTax").value) || 0;
    const insurance = CalcUtils.num(document.getElementById("homeInsurance").value) || 0;

    if(Number.isNaN(price) || Number.isNaN(rate) || Number.isNaN(years)){ showEmpty(); return; }
    if(price <= 0 || years <= 0){ CalcUtils.showError(err, "Home price and loan term must be greater than zero."); showEmpty(); return; }
    if(down < 0 || down >= price){ CalcUtils.showError(err, "Down payment must be less than the home price."); showEmpty(); return; }
    if(rate < 0){ CalcUtils.showError(err, "Interest rate can't be negative."); showEmpty(); return; }

    const principal = price - down;
    const n = years * 12;
    const monthlyRate = rate / 100 / 12;

    let monthlyPI;
    if(rate === 0){
      monthlyPI = principal / n;
    }else{
      monthlyPI = principal * (monthlyRate * Math.pow(1 + monthlyRate, n)) / (Math.pow(1 + monthlyRate, n) - 1);
    }
    const monthlyTax = tax / 12;
    const monthlyInsurance = insurance / 12;
    const totalMonthly = monthlyPI + monthlyTax + monthlyInsurance;
    const totalPaid = monthlyPI * n;
    const totalInterest = totalPaid - principal;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtMoney(totalMonthly)}<span class="unit">/mo</span></div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Principal &amp; interest</span><span class="rval">${CalcUtils.fmtMoney(monthlyPI)}</span></div>
        <div class="result-row"><span class="rlabel">Monthly tax</span><span class="rval">${CalcUtils.fmtMoney(monthlyTax)}</span></div>
        <div class="result-row"><span class="rlabel">Monthly insurance</span><span class="rval">${CalcUtils.fmtMoney(monthlyInsurance)}</span></div>
        <div class="result-row"><span class="rlabel">Loan amount</span><span class="rval">${CalcUtils.fmtMoney(principal)}</span></div>
        <div class="result-row"><span class="rlabel">Total interest paid</span><span class="rval">${CalcUtils.fmtMoney(totalInterest)}</span></div>
        <div class="result-row"><span class="rlabel">Total repayment</span><span class="rval">${CalcUtils.fmtMoney(totalPaid)}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter loan details to see your monthly payment.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("mortgage-calculator");
})();
