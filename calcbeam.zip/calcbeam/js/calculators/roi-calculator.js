(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["roiInitial","roiFinal","roiYears"];

  function calculate(){
    CalcUtils.clearError(err);
    const initial = CalcUtils.num(document.getElementById("roiInitial").value);
    const final = CalcUtils.num(document.getElementById("roiFinal").value);
    const years = CalcUtils.num(document.getElementById("roiYears").value);
    if(Number.isNaN(initial) || Number.isNaN(final)){ showEmpty(); return; }
    if(initial <= 0){ CalcUtils.showError(err, "Initial investment must be greater than zero."); showEmpty(); return; }

    const profit = final - initial;
    const roiPct = (profit / initial) * 100;
    let annualizedHtml = "";
    if(!Number.isNaN(years) && years > 0){
      const annualized = (Math.pow(final / initial, 1/years) - 1) * 100;
      annualizedHtml = `<div class="result-row"><span class="rlabel">Annualized ROI</span><span class="rval">${CalcUtils.fmtPercent(annualized)}</span></div>`;
    }

    resultBody.innerHTML = `
      <div class="readout">${roiPct >= 0 ? "+" : ""}${CalcUtils.fmtPercent(roiPct)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Initial investment</span><span class="rval">${CalcUtils.fmtMoney(initial)}</span></div>
        <div class="result-row"><span class="rlabel">Final value</span><span class="rval">${CalcUtils.fmtMoney(final)}</span></div>
        <div class="result-row"><span class="rlabel">Profit / loss</span><span class="rval">${CalcUtils.fmtMoney(profit)}</span></div>
        <div class="result-row"><span class="rlabel">ROI</span><span class="rval">${CalcUtils.fmtPercent(roiPct)}</span></div>
        ${annualizedHtml}
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter your initial investment and final value to see your ROI.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("roi-calculator");
})();
