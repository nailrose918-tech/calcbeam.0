(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["mkCost","mkPct"];

  function calculate(){
    CalcUtils.clearError(err);
    const cost = CalcUtils.num(document.getElementById("mkCost").value);
    const pct = CalcUtils.num(document.getElementById("mkPct").value);
    if(Number.isNaN(cost) || Number.isNaN(pct)){ showEmpty(); return; }
    if(cost < 0){ CalcUtils.showError(err, "Cost can't be negative."); showEmpty(); return; }
    if(pct < 0){ CalcUtils.showError(err, "Markup percentage can't be negative."); showEmpty(); return; }

    const markupAmount = cost * (pct/100);
    const sellingPrice = cost + markupAmount;
    const marginPct = sellingPrice === 0 ? NaN : (markupAmount / sellingPrice) * 100;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtMoney(sellingPrice)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Cost</span><span class="rval">${CalcUtils.fmtMoney(cost)}</span></div>
        <div class="result-row"><span class="rlabel">Markup amount</span><span class="rval">${CalcUtils.fmtMoney(markupAmount)}</span></div>
        <div class="result-row"><span class="rlabel">Selling price</span><span class="rval">${CalcUtils.fmtMoney(sellingPrice)}</span></div>
        <div class="result-row"><span class="rlabel">Resulting profit margin</span><span class="rval">${Number.isFinite(marginPct) ? CalcUtils.fmtPercent(marginPct) : "—"}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter a cost and markup percentage to see the selling price.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("markup-calculator");
})();
