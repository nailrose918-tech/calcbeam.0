(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["fracN1","fracD1","fracN2","fracD2"];
  const opSelect = document.getElementById("fracOp");

  function gcd(a, b){ a = Math.abs(a); b = Math.abs(b); while(b){ [a,b] = [b, a % b]; } return a || 1; }

  function calculate(){
    CalcUtils.clearError(err);
    const n1 = CalcUtils.num(document.getElementById("fracN1").value);
    const d1 = CalcUtils.num(document.getElementById("fracD1").value);
    const n2 = CalcUtils.num(document.getElementById("fracN2").value);
    const d2 = CalcUtils.num(document.getElementById("fracD2").value);
    const op = opSelect.value;
    if([n1,d1,n2,d2].some(Number.isNaN)){ showEmpty(); return; }
    if(!Number.isInteger(n1) || !Number.isInteger(d1) || !Number.isInteger(n2) || !Number.isInteger(d2)){
      CalcUtils.showError(err, "Numerators and denominators must be whole numbers."); showEmpty(); return;
    }
    if(d1 === 0 || d2 === 0){ CalcUtils.showError(err, "A denominator can't be zero."); showEmpty(); return; }

    let rn, rd;
    if(op === "add"){ rn = n1*d2 + n2*d1; rd = d1*d2; }
    else if(op === "sub"){ rn = n1*d2 - n2*d1; rd = d1*d2; }
    else if(op === "mul"){ rn = n1*n2; rd = d1*d2; }
    else { // div
      if(n2 === 0){ CalcUtils.showError(err, "Can't divide by a fraction equal to zero."); showEmpty(); return; }
      rn = n1*d2; rd = d1*n2;
    }
    if(rd < 0){ rn = -rn; rd = -rd; }
    const d = gcd(rn, rd);
    const simpN = rn / d, simpD = rd / d;
    const decimal = simpD !== 0 ? simpN / simpD : NaN;

    const opSymbol = { add: "+", sub: "\u2212", mul: "\u00d7", div: "\u00f7" }[op];

    resultBody.innerHTML = `
      <div class="readout">${simpN} / ${simpD}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Expression</span><span class="rval">${n1}/${d1} ${opSymbol} ${n2}/${d2}</span></div>
        <div class="result-row"><span class="rlabel">Result (simplified)</span><span class="rval">${simpN} / ${simpD}</span></div>
        <div class="result-row"><span class="rlabel">Decimal</span><span class="rval">${CalcUtils.fmt(decimal, 4)}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter two fractions to add, subtract, multiply or divide.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  opSelect.addEventListener("change", calculate);
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("fraction-calculator");
})();
