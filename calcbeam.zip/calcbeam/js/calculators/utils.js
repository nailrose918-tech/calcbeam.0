/* =========================================================
   CALCBEAM — calculator utilities
   Shared by every calculator script. No eval(), no innerHTML
   of unsanitized user input.
   ========================================================= */

const CalcUtils = {
  // Parse a numeric input safely. Returns NaN (never throws) if invalid.
  num(value){
    if(value === null || value === undefined) return NaN;
    const cleaned = String(value).trim().replace(/,/g, "");
    if(cleaned === "") return NaN;
    const n = Number(cleaned);
    return Number.isFinite(n) ? n : NaN;
  },

  // Format a number with fixed decimals and thousands separators.
  fmt(n, decimals = 2){
    if(!Number.isFinite(n)) return "—";
    return n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  },

  // Format as currency (no locale/currency guessing — always plain $ prefix, static site).
  fmtMoney(n, decimals = 2){
    if(!Number.isFinite(n)) return "—";
    const sign = n < 0 ? "-" : "";
    return `${sign}$${this.fmt(Math.abs(n), decimals)}`;
  },

  fmtPercent(n, decimals = 2){
    if(!Number.isFinite(n)) return "—";
    return `${this.fmt(n, decimals)}%`;
  },

  // Show / hide an inline error message element.
  showError(el, message){
    if(!el) return;
    el.textContent = message;
    el.classList.add("show");
  },
  clearError(el){
    if(!el) return;
    el.textContent = "";
    el.classList.remove("show");
  },

  // Reveal the beam underline animation once a result is produced.
  playBeam(el){
    if(!el) return;
    el.classList.remove("filled");
    void el.offsetWidth; // restart animation
    el.classList.add("filled");
  },

  // Set text content only (never innerHTML) for anything derived from user input.
  setText(el, text){
    if(el) el.textContent = text;
  },

  clamp(n, min, max){
    return Math.min(Math.max(n, min), max);
  },

  // Escape HTML special characters before interpolating any string into
  // an innerHTML template. Defense-in-depth even where input is already
  // constrained (e.g. button-built expressions).
  escapeHtml(str){
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }
};
