(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["loanAmount","loanRate","loanTermYears"];

  function calculate(){
    CalcUtils.clearError(err);
    const amount = CalcUtils.num(document.getElementById("loanAmount").value);
    const rate = CalcUtils.num(document.getElementById("loanRate").value);
    const years = CalcUtils.num(document.getElementById("loanTermYears").value);

    if(Number.isNaN(amount) || Number.isNaN(rate) || Number.isNaN(years)){ showEmpty(); return; }
    if(amount <= 0 || years <= 0){ CalcUtils.showError(err, "Loan amount and term must be greater than zero."); showEmpty(); return; }
    if(rate < 0){ CalcUtils.showError(err, "Interest rate can't be negative."); showEmpty(); return; }

    const n = years * 12;
    const monthlyRate = rate / 100 / 12;
    let payment;
    if(rate === 0){
      payment = amount / n;
    }else{
      payment = amount * (monthlyRate * Math.pow(1 + monthlyRate, n)) / (Math.pow(1 + monthlyRate, n) - 1);
    }
    const totalPaid = payment * n;
    const totalInterest = totalPaid - amount;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtMoney(payment)}<span class="unit">/mo</span></div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Loan amount</span><span class="rval">${CalcUtils.fmtMoney(amount)}</span></div>
        <div class="result-row"><span class="rlabel">Total interest</span><span class="rval">${CalcUtils.fmtMoney(totalInterest)}</span></div>
        <div class="result-row"><span class="rlabel">Total repayment</span><span class="rval">${CalcUtils.fmtMoney(totalPaid)}</span></div>
        <div class="result-row"><span class="rlabel">Number of payments</span><span class="rval">${n}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter your loan details to see the monthly payment.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("loan-calculator");
})();
