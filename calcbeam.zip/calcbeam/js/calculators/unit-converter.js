(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const categorySel = document.getElementById("convCategory");
  const fromSel = document.getElementById("convFrom");
  const toSel = document.getElementById("convTo");
  const valueInput = document.getElementById("convValue");

  // All factors are relative to a base unit within each category (except temperature, handled separately).
  const UNITS = {
    length: { base:"meters", units:{
      millimeters:0.001, centimeters:0.01, meters:1, kilometers:1000,
      inches:0.0254, feet:0.3048, yards:0.9144, miles:1609.344
    }},
    weight: { base:"kilograms", units:{
      milligrams:0.000001, grams:0.001, kilograms:1, "metric tons":1000,
      ounces:0.0283495, pounds:0.453592, stone:6.35029
    }},
    area: { base:"square meters", units:{
      "square meters":1, "square kilometers":1000000, "square feet":0.092903,
      "square yards":0.836127, acres:4046.86, hectares:10000
    }},
    volume: { base:"liters", units:{
      milliliters:0.001, liters:1, "cubic meters":1000,
      "US gallons":3.78541, "US quarts":0.946353, "US cups":0.24, "fluid ounces":0.0295735
    }},
    speed: { base:"meters/sec", units:{
      "meters/sec":1, "kilometers/hour":0.277778, "miles/hour":0.44704, knots:0.514444
    }},
  };
  const TEMP_UNITS = ["Celsius","Fahrenheit","Kelvin"];

  function populateUnitSelects(category){
    fromSel.innerHTML = ""; toSel.innerHTML = "";
    const names = category === "temperature" ? TEMP_UNITS : Object.keys(UNITS[category].units);
    names.forEach((u, i) => {
      fromSel.add(new Option(cap(u), u, i===0, i===0));
      toSel.add(new Option(cap(u), u, i===1, i===1));
    });
    if(names.length > 1){ toSel.selectedIndex = 1; }
  }
  function cap(s){ return s.charAt(0).toUpperCase() + s.slice(1); }

  function toCelsius(v, unit){
    if(unit === "Celsius") return v;
    if(unit === "Fahrenheit") return (v - 32) * 5/9;
    if(unit === "Kelvin") return v - 273.15;
  }
  function fromCelsius(c, unit){
    if(unit === "Celsius") return c;
    if(unit === "Fahrenheit") return c * 9/5 + 32;
    if(unit === "Kelvin") return c + 273.15;
  }

  function calculate(){
    CalcUtils.clearError(err);
    const category = categorySel.value;
    const value = CalcUtils.num(valueInput.value);
    if(Number.isNaN(value)){ showEmpty(); return; }

    let result;
    if(category === "temperature"){
      const c = toCelsius(value, fromSel.value);
      result = fromCelsius(c, toSel.value);
      if(category === "temperature" && toCelsius(value, fromSel.value) < -273.15){
        CalcUtils.showError(err, "That's below absolute zero — please check your value.");
        showEmpty(); return;
      }
    }else{
      const table = UNITS[category].units;
      const inBase = value * table[fromSel.value];
      result = inBase / table[toSel.value];
    }

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmt(result, 4)}<span class="unit">${cap(toSel.value)}</span></div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Input</span><span class="rval">${CalcUtils.fmt(value,4)} ${cap(fromSel.value)}</span></div>
        <div class="result-row"><span class="rlabel">Category</span><span class="rval">${cap(category)}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter a value to convert.</p>';
  }

  categorySel.addEventListener("change", () => { populateUnitSelects(categorySel.value); calculate(); });
  [fromSel, toSel, valueInput].forEach(el => el.addEventListener("input", calculate));
  document.getElementById("swapUnits").addEventListener("click", () => {
    const f = fromSel.value; fromSel.value = toSel.value; toSel.value = f; calculate();
  });
  document.getElementById("calcReset").addEventListener("click", () => {
    valueInput.value = "";
    categorySel.value = "length";
    populateUnitSelects("length");
    CalcUtils.clearError(err);
    showEmpty();
  });

  populateUnitSelects("length");
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("unit-converter");
})();
