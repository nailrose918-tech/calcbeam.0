(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["billAmount","tipPercent","peopleCount"];
  const pillButtons = document.querySelectorAll(".tip-pill");

  pillButtons.forEach(btn => btn.addEventListener("click", () => {
    document.getElementById("tipPercent").value = btn.dataset.tip;
    calculate();
  }));

  function calculate(){
    CalcUtils.clearError(err);
    const bill = CalcUtils.num(document.getElementById("billAmount").value);
    const tipPct = CalcUtils.num(document.getElementById("tipPercent").value);
    const people = CalcUtils.num(document.getElementById("peopleCount").value) || 1;

    if(Number.isNaN(bill) || Number.isNaN(tipPct)){ showEmpty(); return; }
    if(bill < 0 || tipPct < 0){ CalcUtils.showError(err, "Bill amount and tip percentage can't be negative."); showEmpty(); return; }
    if(people < 1){ CalcUtils.showError(err, "Number of people must be at least 1."); showEmpty(); return; }

    const tipAmount = bill * (tipPct / 100);
    const total = bill + tipAmount;
    const perPerson = total / people;
    const tipPerPerson = tipAmount / people;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtMoney(perPerson)}<span class="unit">/person</span></div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Tip amount</span><span class="rval">${CalcUtils.fmtMoney(tipAmount)}</span></div>
        <div class="result-row"><span class="rlabel">Tip per person</span><span class="rval">${CalcUtils.fmtMoney(tipPerPerson)}</span></div>
        <div class="result-row"><span class="rlabel">Total bill</span><span class="rval">${CalcUtils.fmtMoney(total)}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter the bill amount to calculate the tip.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("tip-calculator");
})();
