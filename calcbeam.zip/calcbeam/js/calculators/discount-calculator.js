(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["origPrice","discountPct"];

  function calculate(){
    CalcUtils.clearError(err);
    const price = CalcUtils.num(document.getElementById("origPrice").value);
    const pct = CalcUtils.num(document.getElementById("discountPct").value);
    if(Number.isNaN(price) || Number.isNaN(pct)){ showEmpty(); return; }
    if(price < 0){ CalcUtils.showError(err, "Original price can't be negative."); showEmpty(); return; }
    if(pct < 0 || pct > 100){ CalcUtils.showError(err, "Discount percentage must be between 0 and 100."); showEmpty(); return; }

    const amountOff = price * (pct / 100);
    const finalPrice = price - amountOff;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtMoney(finalPrice)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Original price</span><span class="rval">${CalcUtils.fmtMoney(price)}</span></div>
        <div class="result-row"><span class="rlabel">You save</span><span class="rval">${CalcUtils.fmtMoney(amountOff)}</span></div>
        <div class="result-row"><span class="rlabel">Discount</span><span class="rval">${CalcUtils.fmt(pct)}%</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter a price and discount to see the sale price.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("discount-calculator");
})();
