(function(){
  const tabs = document.querySelectorAll(".tool-tab");
  const panels = document.querySelectorAll(".calc-panel");
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");

  function setMode(mode){
    tabs.forEach(t => t.setAttribute("aria-selected", t.dataset.mode === mode ? "true" : "false"));
    panels.forEach(p => p.style.display = p.dataset.panel === mode ? "" : "none");
    CalcUtils.clearError(err);
    calculate(mode);
  }
  tabs.forEach(t => t.addEventListener("click", () => setMode(t.dataset.mode)));
  function currentMode(){
    return document.querySelector(".tool-tab[aria-selected='true']").dataset.mode;
  }

  function calculate(modeOverride){
    const mode = modeOverride || currentMode();
    CalcUtils.clearError(err);

    if(mode === "addsub"){
      const baseVal = document.getElementById("addBaseDate").value;
      const days = CalcUtils.num(document.getElementById("addDays").value);
      const op = document.getElementById("addOp").value;
      if(!baseVal || Number.isNaN(days)){ showEmpty(); return; }
      const base = new Date(baseVal + "T00:00:00");
      if(isNaN(base.getTime())){ CalcUtils.showError(err, "Please enter a valid start date."); showEmpty(); return; }
      const result = new Date(base);
      result.setDate(result.getDate() + (op === "add" ? days : -days));
      resultBody.innerHTML = `
        <div class="readout" style="font-size:1.6rem;">${result.toDateString()}</div>
        <div class="beam-underline" id="beamLine"></div>
        <div class="result-rows">
          <div class="result-row"><span class="rlabel">Start date</span><span class="rval">${base.toDateString()}</span></div>
          <div class="result-row"><span class="rlabel">${op === "add" ? "Days added" : "Days subtracted"}</span><span class="rval">${days}</span></div>
        </div>`;
      CalcUtils.playBeam(document.getElementById("beamLine"));

    }else if(mode === "diff"){
      const startVal = document.getElementById("diffStart").value;
      const endVal = document.getElementById("diffEnd").value;
      if(!startVal || !endVal){ showEmpty(); return; }
      const start = new Date(startVal + "T00:00:00");
      const end = new Date(endVal + "T00:00:00");
      if(isNaN(start.getTime()) || isNaN(end.getTime())){ CalcUtils.showError(err, "Please enter two valid dates."); showEmpty(); return; }

      const totalDays = Math.round((end - start) / 86400000);
      const absDays = Math.abs(totalDays);
      const weeks = Math.floor(absDays / 7);
      const businessDays = countBusinessDays(start, end);

      resultBody.innerHTML = `
        <div class="readout">${absDays}<span class="unit">days</span></div>
        <div class="beam-underline" id="beamLine"></div>
        <div class="result-rows">
          <div class="result-row"><span class="rlabel">Full weeks</span><span class="rval">${weeks}</span></div>
          <div class="result-row"><span class="rlabel">Business days (Mon–Fri)</span><span class="rval">${businessDays}</span></div>
          <div class="result-row"><span class="rlabel">Direction</span><span class="rval">${totalDays >= 0 ? "End is after start" : "End is before start"}</span></div>
        </div>`;
      CalcUtils.playBeam(document.getElementById("beamLine"));
    }
  }

  function countBusinessDays(start, end){
    let a = new Date(Math.min(start, end));
    const b = new Date(Math.max(start, end));
    let count = 0;
    while(a <= b){
      const day = a.getDay();
      if(day !== 0 && day !== 6) count++;
      a.setDate(a.getDate() + 1);
    }
    return count;
  }

  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Fill in the dates to see your result.</p>';
  }

  document.querySelectorAll(".calc-panel input, .calc-panel select").forEach(el => el.addEventListener("input", () => calculate()));
  document.getElementById("calcReset").addEventListener("click", () => {
    document.querySelectorAll(".calc-panel input").forEach(el => el.value = "");
    CalcUtils.clearError(err);
    showEmpty();
  });

  setMode("addsub");
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("date-calculator");
})();
