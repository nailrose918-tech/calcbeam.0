(function(){
  const tabs = document.querySelectorAll(".tool-tab");
  const panels = document.querySelectorAll(".calc-panel");
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");

  function setMode(mode){
    tabs.forEach(t => t.setAttribute("aria-selected", t.dataset.mode === mode ? "true" : "false"));
    panels.forEach(p => p.style.display = p.dataset.panel === mode ? "" : "none");
    CalcUtils.clearError(err);
    calculate(mode);
  }
  tabs.forEach(t => t.addEventListener("click", () => setMode(t.dataset.mode)));
  function currentMode(){
    const active = document.querySelector(".tool-tab[aria-selected='true']");
    return active ? active.dataset.mode : "addsub";
  }
  function row(label, val){ return `<div class="result-row"><span class="rlabel">${label}</span><span class="rval">${val}</span></div>`; }

  function toSeconds(h, m, s){ return h*3600 + m*60 + s; }
  function fmtHMS(totalSeconds){
    const sign = totalSeconds < 0 ? "-" : "";
    totalSeconds = Math.abs(Math.round(totalSeconds));
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    return `${sign}${h}h ${m}m ${s}s`;
  }

  function calculate(modeOverride){
    const mode = modeOverride || currentMode();
    CalcUtils.clearError(err);

    if(mode === "addsub"){
      const h1 = CalcUtils.num(document.getElementById("t1h").value) || 0;
      const m1 = CalcUtils.num(document.getElementById("t1m").value) || 0;
      const s1 = CalcUtils.num(document.getElementById("t1s").value) || 0;
      const op = document.getElementById("tOp").value;
      const h2 = CalcUtils.num(document.getElementById("t2h").value) || 0;
      const m2 = CalcUtils.num(document.getElementById("t2m").value) || 0;
      const s2 = CalcUtils.num(document.getElementById("t2s").value) || 0;
      if([h1,m1,s1,h2,m2,s2].every(n => n === 0) &&
         !document.getElementById("t1h").value && !document.getElementById("t2h").value){ showEmpty(); return; }

      const sec1 = toSeconds(h1,m1,s1);
      const sec2 = toSeconds(h2,m2,s2);
      const result = op === "add" ? sec1 + sec2 : sec1 - sec2;

      resultBody.innerHTML = `<div class="readout">${fmtHMS(result)}</div><div class="beam-underline" id="beamLine"></div><div class="result-rows">${
        row("First time", fmtHMS(sec1)) + row("Second time", fmtHMS(sec2)) + row("Total seconds", Math.round(result).toLocaleString("en-US"))
      }</div>`;
    } else {
      const start = document.getElementById("tStart").value;
      const end = document.getElementById("tEnd").value;
      if(!start || !end){ showEmpty(); return; }
      const [sh, sm] = start.split(":").map(Number);
      const [eh, em] = end.split(":").map(Number);
      let diffMin = (eh*60 + em) - (sh*60 + sm);
      let crossesMidnight = false;
      if(diffMin < 0){ diffMin += 24*60; crossesMidnight = true; }
      const h = Math.floor(diffMin / 60);
      const m = diffMin % 60;

      resultBody.innerHTML = `<div class="readout">${h}h ${m}m</div><div class="beam-underline" id="beamLine"></div><div class="result-rows">${
        row("Start", start) + row("End", end) + row("Duration", `${h}h ${m}m`) + (crossesMidnight ? row("Note", "Crosses midnight") : "")
      }</div>`;
    }
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter time values to add, subtract, or find a duration.</p>';
  }
  document.querySelectorAll(".calc-panel input, .calc-panel select").forEach(inp => {
    inp.addEventListener("input", () => calculate());
    inp.addEventListener("change", () => calculate());
  });
  document.getElementById("calcReset").addEventListener("click", () => {
    document.querySelectorAll(".calc-panel input").forEach(inp => inp.value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  setMode("addsub");
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("time-calculator");
})();
