(function(){
  const tabs = document.querySelectorAll(".tool-tab");
  const panels = document.querySelectorAll(".calc-panel");
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const resultCard = document.getElementById("resultCard");

  function setMode(mode){
    tabs.forEach(t => t.setAttribute("aria-selected", t.dataset.mode === mode ? "true" : "false"));
    panels.forEach(p => p.style.display = p.dataset.panel === mode ? "" : "none");
    CalcUtils.clearError(err);
    resultBody.innerHTML = '<p class="result-empty">Fill in the fields to see your result.</p>';
    calculate(mode);
  }
  tabs.forEach(t => t.addEventListener("click", () => setMode(t.dataset.mode)));

  function currentMode(){
    const active = document.querySelector(".tool-tab[aria-selected='true']");
    return active ? active.dataset.mode : "of";
  }

  function calculate(modeOverride){
    const mode = modeOverride || currentMode();
    CalcUtils.clearError(err);
    let rowsHtml = "";
    let headline = "";

    if(mode === "of"){
      const pct = CalcUtils.num(document.getElementById("ofPct").value);
      const base = CalcUtils.num(document.getElementById("ofBase").value);
      if(Number.isNaN(pct) || Number.isNaN(base)){ showEmpty(); return; }
      const result = (pct/100) * base;
      headline = CalcUtils.fmt(result);
      rowsHtml = row("Percentage", pct + "%") + row("Of number", CalcUtils.fmt(base));

    }else if(mode === "isWhat"){
      const part = CalcUtils.num(document.getElementById("iwPart").value);
      const whole = CalcUtils.num(document.getElementById("iwWhole").value);
      if(Number.isNaN(part) || Number.isNaN(whole)){ showEmpty(); return; }
      if(whole === 0){ CalcUtils.showError(err, "The second number can't be zero — division by zero is undefined."); showEmpty(); return; }
      const result = (part/whole) * 100;
      headline = CalcUtils.fmtPercent(result);
      rowsHtml = row("Value", CalcUtils.fmt(part)) + row("Out of", CalcUtils.fmt(whole));

    }else if(mode === "increase"){
      const from = CalcUtils.num(document.getElementById("incFrom").value);
      const to = CalcUtils.num(document.getElementById("incTo").value);
      if(Number.isNaN(from) || Number.isNaN(to)){ showEmpty(); return; }
      if(from === 0){ CalcUtils.showError(err, "The starting value can't be zero — percentage change is undefined."); showEmpty(); return; }
      const change = ((to - from) / Math.abs(from)) * 100;
      headline = (change >= 0 ? "+" : "") + CalcUtils.fmtPercent(change);
      rowsHtml = row("From", CalcUtils.fmt(from)) + row("To", CalcUtils.fmt(to)) + row("Direction", change >= 0 ? "Increase" : "Decrease");

    }else if(mode === "decrease"){
      const original = CalcUtils.num(document.getElementById("decOriginal").value);
      const pct = CalcUtils.num(document.getElementById("decPct").value);
      if(Number.isNaN(original) || Number.isNaN(pct)){ showEmpty(); return; }
      const result = original * (1 - pct/100);
      const amount = original - result;
      headline = CalcUtils.fmt(result);
      rowsHtml = row("Original value", CalcUtils.fmt(original)) + row("Decrease", pct + "%") + row("Amount removed", CalcUtils.fmt(amount));
    }

    resultBody.innerHTML = `<div class="readout">${headline}</div><div class="beam-underline" id="beamLine"></div><div class="result-rows">${rowsHtml}</div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }

  function row(label, val){
    return `<div class="result-row"><span class="rlabel">${label}</span><span class="rval">${val}</span></div>`;
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Fill in the fields to see your result.</p>';
  }

  document.querySelectorAll(".calc-panel input").forEach(inp => inp.addEventListener("input", () => calculate()));
  document.getElementById("calcReset").addEventListener("click", () => {
    document.querySelectorAll(".calc-panel input").forEach(inp => inp.value = "");
    CalcUtils.clearError(err);
    showEmpty();
  });

  setMode("of");
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("percentage-calculator");
})();
