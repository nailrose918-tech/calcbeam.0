(function(){
  const dobInput = document.getElementById("dobInput");
  const asOfInput = document.getElementById("asOfInput");
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");

  const today = new Date();
  asOfInput.value = today.toISOString().slice(0,10);
  asOfInput.max = today.toISOString().slice(0,10);
  dobInput.max = today.toISOString().slice(0,10);

  function daysInMonth(year, month){ return new Date(year, month + 1, 0).getDate(); }

  function calculate(){
    CalcUtils.clearError(err);
    const dobVal = dobInput.value;
    const asOfVal = asOfInput.value;
    if(!dobVal){ showEmpty(); return; }
    const dob = new Date(dobVal + "T00:00:00");
    const asOf = new Date((asOfVal || today.toISOString().slice(0,10)) + "T00:00:00");

    if(isNaN(dob.getTime())){ CalcUtils.showError(err, "Please enter a valid date of birth."); showEmpty(); return; }
    if(dob > asOf){ CalcUtils.showError(err, "Date of birth must be before the comparison date."); showEmpty(); return; }

    let years = asOf.getFullYear() - dob.getFullYear();
    let months = asOf.getMonth() - dob.getMonth();
    let days = asOf.getDate() - dob.getDate();

    if(days < 0){
      months -= 1;
      const prevMonth = asOf.getMonth() === 0 ? 11 : asOf.getMonth() - 1;
      const prevMonthYear = asOf.getMonth() === 0 ? asOf.getFullYear() - 1 : asOf.getFullYear();
      days += daysInMonth(prevMonthYear, prevMonth);
    }
    if(months < 0){
      years -= 1;
      months += 12;
    }

    const totalDays = Math.round((asOf - dob) / 86400000);
    const totalWeeks = Math.floor(totalDays / 7);
    const totalMonthsApprox = years * 12 + months;

    let next = new Date(asOf.getFullYear(), dob.getMonth(), dob.getDate());
    if(next < asOf || (next.getMonth()===asOf.getMonth() && next.getDate()===asOf.getDate() && false)) {
      // if birthday already passed this year (or is today), use next year
    }
    if(next < asOf){
      next = new Date(asOf.getFullYear() + 1, dob.getMonth(), dob.getDate());
    }
    const daysToNext = Math.round((next - asOf) / 86400000);

    resultBody.innerHTML = `
      <div class="readout">${years}<span class="unit">yrs</span> ${months}<span class="unit">mo</span> ${days}<span class="unit">d</span></div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Total days lived</span><span class="rval">${CalcUtils.fmt(totalDays,0)}</span></div>
        <div class="result-row"><span class="rlabel">Total weeks</span><span class="rval">${CalcUtils.fmt(totalWeeks,0)}</span></div>
        <div class="result-row"><span class="rlabel">Total months</span><span class="rval">${CalcUtils.fmt(totalMonthsApprox,0)}</span></div>
        <div class="result-row"><span class="rlabel">Next birthday in</span><span class="rval">${daysToNext === 0 ? "Today!" : daysToNext + " days"}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }

  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter a date of birth to see your exact age.</p>';
  }

  dobInput.addEventListener("input", calculate);
  asOfInput.addEventListener("input", calculate);
  document.getElementById("calcReset").addEventListener("click", () => {
    dobInput.value = "";
    asOfInput.value = today.toISOString().slice(0,10);
    CalcUtils.clearError(err);
    showEmpty();
  });

  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("age-calculator");
})();
