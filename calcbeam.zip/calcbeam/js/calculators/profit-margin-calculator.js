(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["pmRevenue","pmCost"];

  function calculate(){
    CalcUtils.clearError(err);
    const revenue = CalcUtils.num(document.getElementById("pmRevenue").value);
    const cost = CalcUtils.num(document.getElementById("pmCost").value);
    if(Number.isNaN(revenue) || Number.isNaN(cost)){ showEmpty(); return; }
    if(revenue < 0 || cost < 0){ CalcUtils.showError(err, "Revenue and cost can't be negative."); showEmpty(); return; }
    if(revenue === 0){ CalcUtils.showError(err, "Revenue can't be zero — margin is undefined."); showEmpty(); return; }

    const profit = revenue - cost;
    const marginPct = (profit / revenue) * 100;
    const markupPct = cost === 0 ? NaN : (profit / cost) * 100;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtPercent(marginPct)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Revenue</span><span class="rval">${CalcUtils.fmtMoney(revenue)}</span></div>
        <div class="result-row"><span class="rlabel">Cost</span><span class="rval">${CalcUtils.fmtMoney(cost)}</span></div>
        <div class="result-row"><span class="rlabel">Profit</span><span class="rval">${CalcUtils.fmtMoney(profit)}</span></div>
        <div class="result-row"><span class="rlabel">Profit margin</span><span class="rval">${CalcUtils.fmtPercent(marginPct)}</span></div>
        <div class="result-row"><span class="rlabel">Markup</span><span class="rval">${Number.isFinite(markupPct) ? CalcUtils.fmtPercent(markupPct) : "—"}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter revenue and cost to see profit margin and markup.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("profit-margin-calculator");
})();
