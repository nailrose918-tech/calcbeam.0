(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const display = document.getElementById("sciDisplay");
  const degToggle = document.getElementById("degModeToggle");
  let expr = "";
  let degMode = true;

  degToggle.addEventListener("click", () => {
    degMode = !degMode;
    degToggle.textContent = degMode ? "DEG" : "RAD";
    degToggle.setAttribute("aria-pressed", degMode ? "false" : "true");
  });

  // ---------- Safe tokenizer / recursive-descent parser (NEVER uses eval) ----------
  function tokenize(str){
    const tokens = [];
    let i = 0;
    const funcs = ["sin","cos","tan","asin","acos","atan","log","ln","sqrt","exp"];
    while(i < str.length){
      const c = str[i];
      if(/\s/.test(c)){ i++; continue; }
      if(/[0-9.]/.test(c)){
        let num = "";
        while(i < str.length && /[0-9.]/.test(str[i])){ num += str[i]; i++; }
        tokens.push({type:"num", value: parseFloat(num)});
        continue;
      }
      if(/[a-zA-Z]/.test(c)){
        let word = "";
        while(i < str.length && /[a-zA-Z]/.test(str[i])){ word += str[i]; i++; }
        if(funcs.includes(word)) tokens.push({type:"func", value: word});
        else if(word === "pi") tokens.push({type:"num", value: Math.PI});
        else if(word === "e") tokens.push({type:"num", value: Math.E});
        else throw new Error("Unknown symbol: " + word);
        continue;
      }
      if("+-*/^(),%".includes(c)){ tokens.push({type:"op", value: c}); i++; continue; }
      throw new Error("Unexpected character: " + c);
    }
    return tokens;
  }

  function parse(tokens){
    let pos = 0;
    function peek(){ return tokens[pos]; }
    function next(){ return tokens[pos++]; }

    function parseExpr(){ return parseAddSub(); }

    function parseAddSub(){
      let left = parseMulDiv();
      while(peek() && peek().type === "op" && (peek().value === "+" || peek().value === "-")){
        const op = next().value;
        const right = parseMulDiv();
        left = op === "+" ? left + right : left - right;
      }
      return left;
    }
    function parseMulDiv(){
      let left = parsePercent();
      while(peek() && peek().type === "op" && (peek().value === "*" || peek().value === "/")){
        const op = next().value;
        const right = parsePercent();
        if(op === "/" && right === 0) throw new Error("Division by zero");
        left = op === "*" ? left * right : left / right;
      }
      return left;
    }
    function parsePercent(){
      let left = parsePower();
      while(peek() && peek().type === "op" && peek().value === "%"){
        next();
        left = left / 100;
      }
      return left;
    }
    function parsePower(){
      let left = parseUnary();
      if(peek() && peek().type === "op" && peek().value === "^"){
        next();
        const right = parsePower(); // right-associative
        left = Math.pow(left, right);
      }
      return left;
    }
    function parseUnary(){
      if(peek() && peek().type === "op" && peek().value === "-"){
        next();
        return -parseUnary();
      }
      if(peek() && peek().type === "op" && peek().value === "+"){
        next();
        return parseUnary();
      }
      return parseAtom();
    }
    function parseAtom(){
      const t = peek();
      if(!t) throw new Error("Unexpected end of expression");
      if(t.type === "num"){ next(); return t.value; }
      if(t.type === "func"){
        next();
        if(!peek() || peek().value !== "(") throw new Error("Expected ( after " + t.value);
        next();
        const arg = parseExpr();
        if(!peek() || peek().value !== ")") throw new Error("Expected )");
        next();
        return applyFunc(t.value, arg);
      }
      if(t.type === "op" && t.value === "("){
        next();
        const v = parseExpr();
        if(!peek() || peek().value !== ")") throw new Error("Expected )");
        next();
        return v;
      }
      throw new Error("Unexpected token: " + t.value);
    }

    const result = parseExpr();
    if(pos < tokens.length) throw new Error("Unexpected trailing input");
    return result;
  }

  function applyFunc(name, arg){
    const rad = degMode ? arg * Math.PI / 180 : arg;
    switch(name){
      case "sin": return Math.sin(rad);
      case "cos": return Math.cos(rad);
      case "tan": return Math.tan(rad);
      case "asin": { const v = Math.asin(arg); return degMode ? v * 180/Math.PI : v; }
      case "acos": { const v = Math.acos(arg); return degMode ? v * 180/Math.PI : v; }
      case "atan": { const v = Math.atan(arg); return degMode ? v * 180/Math.PI : v; }
      case "log": if(arg <= 0) throw new Error("log of non-positive number"); return Math.log10(arg);
      case "ln": if(arg <= 0) throw new Error("ln of non-positive number"); return Math.log(arg);
      case "sqrt": if(arg < 0) throw new Error("sqrt of negative number"); return Math.sqrt(arg);
      case "exp": return Math.exp(arg);
    }
  }

  function safeEvaluate(str){
    const tokens = tokenize(str);
    return parse(tokens);
  }

  function updateDisplay(){
    display.textContent = expr || "0";
  }

  function press(val){
    CalcUtils.clearError(err);
    expr += val;
    updateDisplay();
  }
  function pressFunc(fn){
    CalcUtils.clearError(err);
    expr += fn + "(";
    updateDisplay();
  }
  function clearAll(){
    expr = "";
    updateDisplay();
    resultBody.innerHTML = '<p class="result-empty">Enter an expression to see the result.</p>';
    CalcUtils.clearError(err);
  }
  function backspace(){
    expr = expr.slice(0, -1);
    updateDisplay();
  }
  function equals(){
    CalcUtils.clearError(err);
    if(!expr.trim()){ return; }
    try{
      const result = safeEvaluate(expr);
      if(!Number.isFinite(result)) throw new Error("Result is undefined");
      resultBody.innerHTML = `
        <div class="readout">${CalcUtils.fmt(result, 6).replace(/\.?0+$/,'').replace(/^$/,'0')}</div>
        <div class="beam-underline" id="beamLine"></div>
        <div class="result-rows"><div class="result-row"><span class="rlabel">Expression</span><span class="rval" style="font-size:.85rem;">${CalcUtils.escapeHtml(expr)}</span></div></div>`;
      CalcUtils.playBeam(document.getElementById("beamLine"));
    }catch(e){
      CalcUtils.showError(err, "Invalid expression — " + e.message);
    }
  }

  document.querySelectorAll(".sci-key").forEach(btn => {
    btn.addEventListener("click", () => {
      const action = btn.dataset.action;
      const val = btn.dataset.val;
      if(action === "clear") clearAll();
      else if(action === "back") backspace();
      else if(action === "equals") equals();
      else if(action === "func") pressFunc(val);
      else press(val);
    });
  });
  document.getElementById("calcReset").addEventListener("click", clearAll);

  updateDisplay();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("scientific-calculator");
})();
