(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["invInitial","invMonthly","invReturn","invYears"];

  function calculate(){
    CalcUtils.clearError(err);
    const initial = CalcUtils.num(document.getElementById("invInitial").value);
    const monthly = CalcUtils.num(document.getElementById("invMonthly").value);
    const annualReturn = CalcUtils.num(document.getElementById("invReturn").value);
    const years = CalcUtils.num(document.getElementById("invYears").value);
    if([initial, monthly, annualReturn, years].some(Number.isNaN)){ showEmpty(); return; }
    if(initial < 0 || monthly < 0){ CalcUtils.showError(err, "Investment amounts can't be negative."); showEmpty(); return; }
    if(years <= 0){ CalcUtils.showError(err, "Duration must be greater than zero."); showEmpty(); return; }

    const months = years * 12;
    const i = (annualReturn / 100) / 12;

    let futureValue;
    if(i === 0){
      futureValue = initial + monthly * months;
    } else {
      futureValue = initial * Math.pow(1 + i, months) + monthly * ((Math.pow(1 + i, months) - 1) / i);
    }
    const totalContributions = initial + monthly * months;
    const growth = futureValue - totalContributions;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtMoney(futureValue)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Total contributions</span><span class="rval">${CalcUtils.fmtMoney(totalContributions)}</span></div>
        <div class="result-row"><span class="rlabel">Estimated growth</span><span class="rval">${CalcUtils.fmtMoney(growth)}</span></div>
        <div class="result-row"><span class="rlabel">Final balance</span><span class="rval">${CalcUtils.fmtMoney(futureValue)}</span></div>
      </div>
      <p style="font-size:.85rem;color:var(--ink-soft);margin-top:.75rem;">Estimate only — actual investment returns are never guaranteed and can go down as well as up.</p>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter your investment details to project a future balance.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("investment-calculator");
})();
