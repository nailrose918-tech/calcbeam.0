(function(){
  const tabs = document.querySelectorAll(".tool-tab");
  const panels = document.querySelectorAll(".calc-panel");
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");

  const ACTIVITY = {
    "1.2": "Sedentary (little or no exercise)",
    "1.375": "Light (exercise 1–3 days/week)",
    "1.55": "Moderate (exercise 3–5 days/week)",
    "1.725": "Active (exercise 6–7 days/week)",
    "1.9": "Very active (hard exercise, physical job)"
  };

  function setMode(mode){
    tabs.forEach(t => t.setAttribute("aria-selected", t.dataset.mode === mode ? "true" : "false"));
    panels.forEach(p => p.style.display = p.dataset.panel === mode ? "" : "none");
    CalcUtils.clearError(err);
    calculate(mode);
  }
  tabs.forEach(t => t.addEventListener("click", () => setMode(t.dataset.mode)));
  function currentMode(){
    const active = document.querySelector(".tool-tab[aria-selected='true']");
    return active ? active.dataset.mode : "metric";
  }
  function row(label, val){ return `<div class="result-row"><span class="rlabel">${label}</span><span class="rval">${val}</span></div>`; }

  function bmr(sex, weightKg, heightCm, age){
    // Mifflin-St Jeor equation
    const base = 10*weightKg + 6.25*heightCm - 5*age;
    return sex === "male" ? base + 5 : base - 161;
  }

  function calculate(modeOverride){
    const mode = modeOverride || currentMode();
    CalcUtils.clearError(err);

    let weightKg, heightCm, age, sex, activity;
    if(mode === "metric"){
      weightKg = CalcUtils.num(document.getElementById("calWeightKg").value);
      heightCm = CalcUtils.num(document.getElementById("calHeightCm").value);
      age = CalcUtils.num(document.getElementById("calAgeM").value);
      sex = document.getElementById("calSexM").value;
      activity = document.getElementById("calActivityM").value;
    } else {
      const lb = CalcUtils.num(document.getElementById("calWeightLb").value);
      const ft = CalcUtils.num(document.getElementById("calHeightFt").value);
      const inch = CalcUtils.num(document.getElementById("calHeightIn").value);
      age = CalcUtils.num(document.getElementById("calAgeI").value);
      sex = document.getElementById("calSexI").value;
      activity = document.getElementById("calActivityI").value;
      weightKg = lb * 0.45359237;
      heightCm = (ft * 12 + (Number.isNaN(inch) ? 0 : inch)) * 2.54;
    }

    if([weightKg, heightCm, age].some(Number.isNaN)){ showEmpty(); return; }
    if(weightKg <= 0 || heightCm <= 0 || age <= 0){
      CalcUtils.showError(err, "Weight, height, and age must be greater than zero."); showEmpty(); return;
    }
    if(age > 120){ CalcUtils.showError(err, "Please enter a realistic age."); showEmpty(); return; }

    const b = bmr(sex, weightKg, heightCm, age);
    const mult = parseFloat(activity);
    const tdee = b * mult;

    resultBody.innerHTML = `
      <div class="readout">${Math.round(tdee).toLocaleString("en-US")}<span class="unit">cal/day</span></div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Base metabolic rate (BMR)</span><span class="rval">${Math.round(b).toLocaleString("en-US")} cal/day</span></div>
        <div class="result-row"><span class="rlabel">Activity level</span><span class="rval">${ACTIVITY[activity] || ""}</span></div>
        <div class="result-row"><span class="rlabel">Maintenance calories</span><span class="rval">${Math.round(tdee).toLocaleString("en-US")} cal/day</span></div>
      </div>
      <p style="font-size:.85rem;color:var(--ink-soft);margin-top:.75rem;">This calculator provides an estimate and is not medical advice.</p>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Fill in your details to estimate daily calorie needs.</p>';
  }
  document.querySelectorAll(".calc-panel input, .calc-panel select").forEach(inp => inp.addEventListener("input", () => calculate()));
  document.getElementById("calcReset").addEventListener("click", () => {
    document.querySelectorAll(".calc-panel input").forEach(inp => inp.value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  setMode("metric");
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("calorie-calculator");
})();
