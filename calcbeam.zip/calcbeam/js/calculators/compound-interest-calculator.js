(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["ciPrincipal","ciRate","ciYears","ciFreq","ciContribution"];

  function calculate(){
    CalcUtils.clearError(err);
    const principal = CalcUtils.num(document.getElementById("ciPrincipal").value);
    const rate = CalcUtils.num(document.getElementById("ciRate").value);
    const years = CalcUtils.num(document.getElementById("ciYears").value);
    const freq = CalcUtils.num(document.getElementById("ciFreq").value);
    const contribution = CalcUtils.num(document.getElementById("ciContribution").value) || 0;

    if(Number.isNaN(principal) || Number.isNaN(rate) || Number.isNaN(years) || Number.isNaN(freq)){ showEmpty(); return; }
    if(principal < 0 || years <= 0){ CalcUtils.showError(err, "Starting amount can't be negative and duration must be greater than zero."); showEmpty(); return; }
    if(rate < 0){ CalcUtils.showError(err, "Interest rate can't be negative."); showEmpty(); return; }

    const periods = freq * years;
    const periodicRate = (rate / 100) / freq;
    const growthFactor = Math.pow(1 + periodicRate, periods);
    let balance = principal * growthFactor;

    // Monthly contributions, converted to per-period equivalent, added with their own compounding.
    if(contribution > 0){
      const monthlyToPeriod = contribution * (12 / freq);
      if(periodicRate === 0){
        balance += monthlyToPeriod * periods;
      }else{
        balance += monthlyToPeriod * ((growthFactor - 1) / periodicRate);
      }
    }

    const totalContributed = principal + contribution * 12 * years;
    const interestEarned = balance - totalContributed;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtMoney(balance)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Starting amount</span><span class="rval">${CalcUtils.fmtMoney(principal)}</span></div>
        <div class="result-row"><span class="rlabel">Total contributions</span><span class="rval">${CalcUtils.fmtMoney(totalContributed - principal)}</span></div>
        <div class="result-row"><span class="rlabel">Interest earned</span><span class="rval">${CalcUtils.fmtMoney(interestEarned)}</span></div>
        <div class="result-row"><span class="rlabel">Final balance</span><span class="rval">${CalcUtils.fmtMoney(balance)}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter your savings details to project growth.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => { const el = document.getElementById(id); if(el.tagName === "SELECT") el.selectedIndex = 1; else el.value = ""; });
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("compound-interest-calculator");
})();
