(function(){
  const tabs = document.querySelectorAll(".tool-tab");
  const panels = document.querySelectorAll(".calc-panel");
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");

  function setMode(mode){
    tabs.forEach(t => t.setAttribute("aria-selected", t.dataset.mode === mode ? "true" : "false"));
    panels.forEach(p => p.style.display = p.dataset.panel === mode ? "" : "none");
    CalcUtils.clearError(err);
    calculate(mode);
  }
  tabs.forEach(t => t.addEventListener("click", () => setMode(t.dataset.mode)));
  function currentMode(){
    const active = document.querySelector(".tool-tab[aria-selected='true']");
    return active ? active.dataset.mode : "weighted";
  }
  function row(label, val){ return `<div class="result-row"><span class="rlabel">${label}</span><span class="rval">${val}</span></div>`; }

  // ---------- Weighted current grade (dynamic rows) ----------
  const rowsWrap = document.getElementById("gradeRows");
  let rowId = 0;
  function addRow(score, weight){
    rowId++;
    const id = "gr" + rowId;
    const div = document.createElement("div");
    div.className = "field-row";
    div.style.alignItems = "end";
    div.innerHTML = `
      <div class="field"><label for="${id}-score">Score</label><div class="input-suffix"><input type="number" id="${id}-score" class="grade-score" min="0" max="100" value="${score !== undefined ? score : ''}" placeholder="e.g. 88"><span>%</span></div></div>
      <div class="field" style="display:flex;gap:8px;align-items:flex-end;">
        <div style="flex:1;">
          <label for="${id}-weight">Weight</label>
          <div class="input-suffix"><input type="number" id="${id}-weight" class="grade-weight" min="0" max="100" value="${weight !== undefined ? weight : ''}" placeholder="e.g. 20"><span>%</span></div>
        </div>
        <button type="button" class="icon-btn remove-row" aria-label="Remove item" style="margin-bottom:2px;">&times;</button>
      </div>`;
    rowsWrap.appendChild(div);
    div.querySelectorAll("input").forEach(inp => inp.addEventListener("input", calcWeighted));
    div.querySelector(".remove-row").addEventListener("click", () => { div.remove(); calcWeighted(); });
  }
  const addBtn = document.getElementById("addGradeRow");
  if(addBtn) addBtn.addEventListener("click", () => addRow());

  function calcWeighted(){
    CalcUtils.clearError(err);
    const scores = rowsWrap.querySelectorAll(".grade-score");
    const weights = rowsWrap.querySelectorAll(".grade-weight");
    if(scores.length === 0){ showEmpty(); return; }
    let weightedSum = 0, totalWeight = 0, anyFilled = false;
    for(let i=0; i<scores.length; i++){
      const s = CalcUtils.num(scores[i].value);
      const w = CalcUtils.num(weights[i].value);
      if(Number.isNaN(s) || Number.isNaN(w)) continue;
      anyFilled = true;
      weightedSum += s * w;
      totalWeight += w;
    }
    if(!anyFilled || totalWeight === 0){ showEmpty(); return; }
    const grade = weightedSum / totalWeight;
    resultBody.innerHTML = `<div class="readout">${CalcUtils.fmt(grade)}%</div><div class="beam-underline" id="beamLine"></div><div class="result-rows">${
      row("Weighted average", CalcUtils.fmt(grade) + "%") + row("Total weight used", CalcUtils.fmt(totalWeight) + "%")
    }</div>${totalWeight !== 100 ? '<p style="font-size:.85rem;color:var(--ink-soft);margin-top:.75rem;">Weights add up to ' + CalcUtils.fmt(totalWeight) + '%, not 100% — the average is still calculated correctly relative to the weight you entered.</p>' : ''}`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }

  // ---------- Required final exam score ----------
  function calcFinal(){
    CalcUtils.clearError(err);
    const current = CalcUtils.num(document.getElementById("gfCurrent").value);
    const weight = CalcUtils.num(document.getElementById("gfWeight").value);
    const target = CalcUtils.num(document.getElementById("gfTarget").value);
    if([current, weight, target].some(Number.isNaN)){ showEmpty(); return; }
    if(weight <= 0 || weight > 100){ CalcUtils.showError(err, "Final exam weight must be between 0 and 100."); showEmpty(); return; }

    const w = weight / 100;
    const needed = (target - current * (1 - w)) / w;

    let note = "";
    if(needed > 100) note = '<p style="font-size:.85rem;color:var(--ink-soft);margin-top:.75rem;">This score is above 100% — reaching your target grade may not be possible from here.</p>';
    if(needed < 0) note = '<p style="font-size:.85rem;color:var(--ink-soft);margin-top:.75rem;">You\'ve already secured this grade regardless of your final exam score.</p>';

    resultBody.innerHTML = `<div class="readout">${CalcUtils.fmt(needed)}%</div><div class="beam-underline" id="beamLine"></div><div class="result-rows">${
      row("Current grade", CalcUtils.fmt(current) + "%") + row("Final exam weight", CalcUtils.fmt(weight) + "%") + row("Target grade", CalcUtils.fmt(target) + "%") + row("Score needed on final", CalcUtils.fmt(needed) + "%")
    }</div>${note}`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }

  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Fill in your grades to see the result.</p>';
  }

  ["gfCurrent","gfWeight","gfTarget"].forEach(id => {
    const el = document.getElementById(id);
    if(el) el.addEventListener("input", calcFinal);
  });

  document.getElementById("calcReset").addEventListener("click", () => {
    if(currentMode() === "weighted"){
      rowsWrap.innerHTML = "";
      addRow(); addRow(); addRow();
      calcWeighted();
    } else {
      ["gfCurrent","gfWeight","gfTarget"].forEach(id => { const el = document.getElementById(id); if(el) el.value = ""; });
      showEmpty();
    }
    CalcUtils.clearError(err);
  });

  function calculate(modeOverride){
    const mode = modeOverride || currentMode();
    if(mode === "weighted") calcWeighted(); else calcFinal();
  }

  // seed with 3 starter rows
  addRow(88, 20); addRow(92, 30); addRow(79, 50);
  setMode("weighted");
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("grade-calculator");
})();
