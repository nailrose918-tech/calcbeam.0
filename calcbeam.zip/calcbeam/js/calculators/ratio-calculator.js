(function(){
  const tabs = document.querySelectorAll(".tool-tab");
  const panels = document.querySelectorAll(".calc-panel");
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");

  function gcd(a, b){ a = Math.abs(a); b = Math.abs(b); while(b){ [a,b] = [b, a % b]; } return a || 1; }

  function setMode(mode){
    tabs.forEach(t => t.setAttribute("aria-selected", t.dataset.mode === mode ? "true" : "false"));
    panels.forEach(p => p.style.display = p.dataset.panel === mode ? "" : "none");
    CalcUtils.clearError(err);
    calculate(mode);
  }
  tabs.forEach(t => t.addEventListener("click", () => setMode(t.dataset.mode)));
  function currentMode(){
    const active = document.querySelector(".tool-tab[aria-selected='true']");
    return active ? active.dataset.mode : "simplify";
  }
  function row(label, val){ return `<div class="result-row"><span class="rlabel">${label}</span><span class="rval">${val}</span></div>`; }

  function calculate(modeOverride){
    const mode = modeOverride || currentMode();
    CalcUtils.clearError(err);

    if(mode === "simplify"){
      const a = CalcUtils.num(document.getElementById("simA").value);
      const b = CalcUtils.num(document.getElementById("simB").value);
      if(Number.isNaN(a) || Number.isNaN(b)){ showEmpty(); return; }
      if(a < 0 || b < 0){ CalcUtils.showError(err, "Ratio values should be positive numbers."); showEmpty(); return; }
      if(b === 0){ CalcUtils.showError(err, "The second value can't be zero."); showEmpty(); return; }
      if(!Number.isInteger(a) || !Number.isInteger(b)){
        CalcUtils.showError(err, "Simplification requires whole numbers. Try the missing-value tab for decimals.");
        showEmpty(); return;
      }
      const d = gcd(a, b);
      resultBody.innerHTML = `<div class="readout">${a/d} : ${b/d}</div><div class="beam-underline" id="beamLine"></div><div class="result-rows">${
        row("Original ratio", `${a} : ${b}`) + row("Simplified ratio", `${a/d} : ${b/d}`) + row("Divided by (GCD)", d)
      }</div>`;

    } else {
      const a = CalcUtils.num(document.getElementById("mvA").value);
      const b = CalcUtils.num(document.getElementById("mvB").value);
      const c = CalcUtils.num(document.getElementById("mvC").value);
      if(Number.isNaN(a) || Number.isNaN(b) || Number.isNaN(c)){ showEmpty(); return; }
      if(a === 0){ CalcUtils.showError(err, "The first value can't be zero — it would make the ratio undefined."); showEmpty(); return; }
      const d = (b * c) / a;
      resultBody.innerHTML = `<div class="readout">${CalcUtils.fmt(d)}</div><div class="beam-underline" id="beamLine"></div><div class="result-rows">${
        row("A : B", `${CalcUtils.fmt(a)} : ${CalcUtils.fmt(b)}`) + row("C : D", `${CalcUtils.fmt(c)} : ${CalcUtils.fmt(d)}`)
      }</div>`;
    }
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter ratio values to simplify or solve for the missing number.</p>';
  }
  document.querySelectorAll(".calc-panel input").forEach(inp => inp.addEventListener("input", () => calculate()));
  document.getElementById("calcReset").addEventListener("click", () => {
    document.querySelectorAll(".calc-panel input").forEach(inp => inp.value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  setMode("simplify");
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("ratio-calculator");
})();
