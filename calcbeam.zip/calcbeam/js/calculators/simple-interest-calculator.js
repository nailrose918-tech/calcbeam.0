(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const ids = ["siPrincipal","siRate","siTime"];

  function calculate(){
    CalcUtils.clearError(err);
    const p = CalcUtils.num(document.getElementById("siPrincipal").value);
    const r = CalcUtils.num(document.getElementById("siRate").value);
    const t = CalcUtils.num(document.getElementById("siTime").value);
    if(Number.isNaN(p) || Number.isNaN(r) || Number.isNaN(t)){ showEmpty(); return; }
    if(p < 0){ CalcUtils.showError(err, "Principal can't be negative."); showEmpty(); return; }
    if(t < 0){ CalcUtils.showError(err, "Time can't be negative."); showEmpty(); return; }

    const interest = p * (r/100) * t;
    const finalAmount = p + interest;

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmtMoney(finalAmount)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Principal</span><span class="rval">${CalcUtils.fmtMoney(p)}</span></div>
        <div class="result-row"><span class="rlabel">Interest earned</span><span class="rval">${CalcUtils.fmtMoney(interest)}</span></div>
        <div class="result-row"><span class="rlabel">Rate</span><span class="rval">${CalcUtils.fmt(r)}% / year</span></div>
        <div class="result-row"><span class="rlabel">Time</span><span class="rval">${CalcUtils.fmt(t)} years</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter principal, rate, and time to see the interest earned.</p>';
  }
  ids.forEach(id => document.getElementById(id).addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    ids.forEach(id => document.getElementById(id).value = "");
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("simple-interest-calculator");
})();
