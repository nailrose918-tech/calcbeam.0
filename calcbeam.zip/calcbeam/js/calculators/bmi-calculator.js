(function(){
  const tabs = document.querySelectorAll(".tool-tab");
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");

  function setUnit(unit){
    tabs.forEach(t => t.setAttribute("aria-selected", t.dataset.mode === unit ? "true" : "false"));
    document.getElementById("panel-metric").style.display = unit === "metric" ? "" : "none";
    document.getElementById("panel-imperial").style.display = unit === "imperial" ? "" : "none";
    calculate();
  }
  tabs.forEach(t => t.addEventListener("click", () => setUnit(t.dataset.mode)));

  function category(bmi){
    if(bmi < 18.5) return ["Underweight", "var(--beam)"];
    if(bmi < 25) return ["Healthy weight", "var(--success)"];
    if(bmi < 30) return ["Overweight", "var(--warm)"];
    return ["Obesity", "var(--danger)"];
  }

  function calculate(){
    CalcUtils.clearError(err);
    const unit = document.querySelector(".tool-tab[aria-selected='true']").dataset.mode;
    let bmi;
    if(unit === "metric"){
      const cm = CalcUtils.num(document.getElementById("mHeight").value);
      const kg = CalcUtils.num(document.getElementById("mWeight").value);
      if(Number.isNaN(cm) || Number.isNaN(kg)){ showEmpty(); return; }
      if(cm <= 0 || kg <= 0){ CalcUtils.showError(err, "Height and weight must be greater than zero."); showEmpty(); return; }
      const m = cm / 100;
      bmi = kg / (m * m);
    }else{
      const ft = CalcUtils.num(document.getElementById("iFeet").value);
      const inch = CalcUtils.num(document.getElementById("iInches").value) || 0;
      const lb = CalcUtils.num(document.getElementById("iWeight").value);
      if(Number.isNaN(ft) || Number.isNaN(lb)){ showEmpty(); return; }
      const totalInches = ft * 12 + inch;
      if(totalInches <= 0 || lb <= 0){ CalcUtils.showError(err, "Height and weight must be greater than zero."); showEmpty(); return; }
      bmi = (703 * lb) / (totalInches * totalInches);
    }
    if(!Number.isFinite(bmi) || bmi <= 0 || bmi > 300){ CalcUtils.showError(err, "Please check your inputs — that doesn't look like a valid height/weight combination."); showEmpty(); return; }

    const [label, color] = category(bmi);
    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmt(bmi,1)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Category</span><span class="rval" style="color:${color}">${label}</span></div>
        <div class="result-row"><span class="rlabel">Healthy BMI range</span><span class="rval">18.5 – 24.9</span></div>
      </div>
      <p style="font-size:.78rem;color:var(--ink-faint);margin-top:14px;">This calculator provides an estimate and is not medical advice.</p>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter your height and weight to see your BMI.</p>';
  }

  document.querySelectorAll(".tool-card input").forEach(inp => inp.addEventListener("input", calculate));
  document.getElementById("calcReset").addEventListener("click", () => {
    document.querySelectorAll(".tool-card input").forEach(inp => inp.value = "");
    CalcUtils.clearError(err);
    showEmpty();
  });

  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("bmi-calculator");
})();
