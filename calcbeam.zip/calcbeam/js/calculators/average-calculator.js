(function(){
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");
  const input = document.getElementById("avgNumbers");

  function parseNumbers(str){
    return str.split(/[,\s]+/).map(s => s.trim()).filter(s => s !== "").map(Number);
  }

  function mode(arr){
    const counts = new Map();
    arr.forEach(n => counts.set(n, (counts.get(n) || 0) + 1));
    let max = 0;
    counts.forEach(c => { if(c > max) max = c; });
    if(max <= 1) return null; // no repeats -> no mode
    const modes = [...counts.entries()].filter(([,c]) => c === max).map(([n]) => n);
    return modes.sort((a,b) => a-b);
  }

  function calculate(){
    CalcUtils.clearError(err);
    const raw = input.value;
    if(!raw || raw.trim() === ""){ showEmpty(); return; }
    const nums = parseNumbers(raw);
    if(nums.length === 0 || nums.some(Number.isNaN)){
      CalcUtils.showError(err, "Enter numbers separated by commas or spaces, e.g. 4, 8, 15, 16, 23.");
      showEmpty(); return;
    }

    const sum = nums.reduce((a,b) => a+b, 0);
    const mean = sum / nums.length;
    const sorted = [...nums].sort((a,b) => a-b);
    const mid = Math.floor(sorted.length / 2);
    const median = sorted.length % 2 === 0 ? (sorted[mid-1] + sorted[mid]) / 2 : sorted[mid];
    const modes = mode(nums);
    const modeText = modes === null ? "None (no repeated value)" : modes.map(m => CalcUtils.fmt(m, 2)).join(", ");
    const range = sorted[sorted.length-1] - sorted[0];

    resultBody.innerHTML = `
      <div class="readout">${CalcUtils.fmt(mean)}</div>
      <div class="beam-underline" id="beamLine"></div>
      <div class="result-rows">
        <div class="result-row"><span class="rlabel">Count</span><span class="rval">${nums.length}</span></div>
        <div class="result-row"><span class="rlabel">Mean (average)</span><span class="rval">${CalcUtils.fmt(mean)}</span></div>
        <div class="result-row"><span class="rlabel">Median</span><span class="rval">${CalcUtils.fmt(median)}</span></div>
        <div class="result-row"><span class="rlabel">Mode</span><span class="rval">${modeText}</span></div>
        <div class="result-row"><span class="rlabel">Range</span><span class="rval">${CalcUtils.fmt(range)}</span></div>
      </div>`;
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter a list of numbers to see the mean, median, mode and range.</p>';
  }
  input.addEventListener("input", calculate);
  document.getElementById("calcReset").addEventListener("click", () => {
    input.value = "";
    CalcUtils.clearError(err); showEmpty();
  });
  showEmpty();
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("average-calculator");
})();
