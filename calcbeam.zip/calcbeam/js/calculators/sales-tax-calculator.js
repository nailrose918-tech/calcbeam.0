(function(){
  const tabs = document.querySelectorAll(".tool-tab");
  const panels = document.querySelectorAll(".calc-panel");
  const err = document.getElementById("calcError");
  const resultBody = document.getElementById("resultBody");

  function setMode(mode){
    tabs.forEach(t => t.setAttribute("aria-selected", t.dataset.mode === mode ? "true" : "false"));
    panels.forEach(p => p.style.display = p.dataset.panel === mode ? "" : "none");
    CalcUtils.clearError(err);
    calculate(mode);
  }
  tabs.forEach(t => t.addEventListener("click", () => setMode(t.dataset.mode)));

  function currentMode(){
    const active = document.querySelector(".tool-tab[aria-selected='true']");
    return active ? active.dataset.mode : "add";
  }

  function row(label, val){
    return `<div class="result-row"><span class="rlabel">${label}</span><span class="rval">${val}</span></div>`;
  }

  function calculate(modeOverride){
    const mode = modeOverride || currentMode();
    CalcUtils.clearError(err);

    if(mode === "add"){
      const price = CalcUtils.num(document.getElementById("stPrice").value);
      const rate = CalcUtils.num(document.getElementById("stRate").value);
      if(Number.isNaN(price) || Number.isNaN(rate)){ showEmpty(); return; }
      if(price < 0 || rate < 0){ CalcUtils.showError(err, "Price and tax rate can't be negative."); showEmpty(); return; }
      const tax = price * (rate/100);
      const total = price + tax;
      resultBody.innerHTML = `<div class="readout">${CalcUtils.fmtMoney(total)}</div><div class="beam-underline" id="beamLine"></div><div class="result-rows">${
        row("Pre-tax price", CalcUtils.fmtMoney(price)) + row("Tax rate", CalcUtils.fmt(rate) + "%") + row("Tax amount", CalcUtils.fmtMoney(tax)) + row("Final price", CalcUtils.fmtMoney(total))
      }</div>`;
    } else {
      const total = CalcUtils.num(document.getElementById("stTotal").value);
      const rate = CalcUtils.num(document.getElementById("stRate2").value);
      if(Number.isNaN(total) || Number.isNaN(rate)){ showEmpty(); return; }
      if(total < 0 || rate < 0){ CalcUtils.showError(err, "Total and tax rate can't be negative."); showEmpty(); return; }
      const preTax = total / (1 + rate/100);
      const tax = total - preTax;
      resultBody.innerHTML = `<div class="readout">${CalcUtils.fmtMoney(preTax)}</div><div class="beam-underline" id="beamLine"></div><div class="result-rows">${
        row("Total (tax included)", CalcUtils.fmtMoney(total)) + row("Tax rate", CalcUtils.fmt(rate) + "%") + row("Tax amount", CalcUtils.fmtMoney(tax)) + row("Pre-tax price", CalcUtils.fmtMoney(preTax))
      }</div>`;
    }
    CalcUtils.playBeam(document.getElementById("beamLine"));
  }
  function showEmpty(){
    resultBody.innerHTML = '<p class="result-empty">Enter a price and tax rate to see the result.</p>';
  }

  document.querySelectorAll(".calc-panel input").forEach(inp => inp.addEventListener("input", () => calculate()));
  document.getElementById("calcReset").addEventListener("click", () => {
    document.querySelectorAll(".calc-panel input").forEach(inp => inp.value = "");
    CalcUtils.clearError(err); showEmpty();
  });

  setMode("add");
  if(typeof trackRecentCalculator === "function") trackRecentCalculator("sales-tax-calculator");
})();
