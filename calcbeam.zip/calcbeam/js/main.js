/* =========================================================
   CALCBEAM — main.js
   Shared registry + site behaviour (theme, nav, search, recents)
   ========================================================= */

// ---- Calculator registry (single source of truth for search / listings) ----
const CALCBEAM_CALCS = [
  { id:"percentage-calculator", name:"Percentage Calculator", cat:"Math", url:"percentage-calculator.html",
    desc:"Find a percentage of a number, percentage change, and more.", kw:["percent","percentage increase","percentage decrease","percent of"] },
  { id:"average-calculator", name:"Average Calculator", cat:"Math", url:"average-calculator.html",
    desc:"Mean, median, mode and range for any list of numbers.", kw:["mean","median","mode","range","statistics"] },
  { id:"ratio-calculator", name:"Ratio Calculator", cat:"Math", url:"ratio-calculator.html",
    desc:"Simplify ratios, compare ratios, and solve for a missing value.", kw:["simplify ratio","proportion","compare ratios"] },
  { id:"fraction-calculator", name:"Fraction Calculator", cat:"Math", url:"fraction-calculator.html",
    desc:"Add, subtract, multiply and divide fractions with steps.", kw:["add fractions","simplify fraction","mixed numbers"] },
  { id:"scientific-calculator", name:"Scientific Calculator", cat:"Math", url:"scientific-calculator.html",
    desc:"Full scientific calculator with trig, logs, powers and roots.", kw:["sin cos tan","log","square root","exponent"] },

  { id:"mortgage-calculator", name:"Mortgage Calculator", cat:"Finance", url:"mortgage-calculator.html",
    desc:"Estimate your monthly mortgage payment including tax and insurance.", kw:["home loan","monthly payment","house payment"] },
  { id:"loan-calculator", name:"Loan Calculator", cat:"Finance", url:"loan-calculator.html",
    desc:"Monthly payment, total interest and payoff for any loan.", kw:["car loan","personal loan","amortization"] },
  { id:"compound-interest-calculator", name:"Compound Interest Calculator", cat:"Finance", url:"compound-interest-calculator.html",
    desc:"See how savings grow with compounding and regular contributions.", kw:["compounding","interest growth","savings growth"] },
  { id:"simple-interest-calculator", name:"Simple Interest Calculator", cat:"Finance", url:"simple-interest-calculator.html",
    desc:"Calculate interest earned or owed using the simple interest formula.", kw:["interest earned","principal","simple interest formula"] },
  { id:"investment-calculator", name:"Investment Calculator", cat:"Finance", url:"investment-calculator.html",
    desc:"Project the future value of an investment with monthly contributions.", kw:["future value","investment growth","monthly contribution"] },
  { id:"discount-calculator", name:"Discount Calculator", cat:"Finance", url:"discount-calculator.html",
    desc:"Work out the sale price and amount saved on any discount.", kw:["sale price","percent off","coupon"] },
  { id:"sales-tax-calculator", name:"Sales Tax Calculator", cat:"Finance", url:"sales-tax-calculator.html",
    desc:"Add or remove sales tax from a price in seconds.", kw:["tax amount","price with tax","vat"] },
  { id:"tip-calculator", name:"Tip Calculator", cat:"Finance", url:"tip-calculator.html",
    desc:"Split the bill and calculate the right tip per person.", kw:["gratuity","split bill","restaurant tip"] },
  { id:"profit-margin-calculator", name:"Profit Margin Calculator", cat:"Finance", url:"profit-margin-calculator.html",
    desc:"Calculate profit, margin percentage and markup from cost and revenue.", kw:["gross margin","markup vs margin","revenue"] },
  { id:"roi-calculator", name:"ROI Calculator", cat:"Finance", url:"roi-calculator.html",
    desc:"Calculate return on investment as a percentage and annualized rate.", kw:["return on investment","annualized return"] },
  { id:"markup-calculator", name:"Markup Calculator", cat:"Finance", url:"markup-calculator.html",
    desc:"Turn cost into selling price using a target markup percentage.", kw:["cost plus","selling price","pricing"] },

  { id:"bmi-calculator", name:"BMI Calculator", cat:"Health", url:"bmi-calculator.html",
    desc:"Body mass index from height and weight, metric or imperial.", kw:["body mass index","healthy weight"] },
  { id:"calorie-calculator", name:"Calorie Calculator", cat:"Health", url:"calorie-calculator.html",
    desc:"Estimate daily calorie needs based on age, sex and activity level.", kw:["tdee","bmr","daily calories","maintenance calories"] },

  { id:"gpa-calculator", name:"GPA Calculator", cat:"Education", url:"gpa-calculator.html",
    desc:"Calculate your grade point average from courses and credit hours.", kw:["grade point average","semester gpa","cumulative gpa"] },
  { id:"grade-calculator", name:"Grade Calculator", cat:"Education", url:"grade-calculator.html",
    desc:"Find your current grade and the score you need on the final.", kw:["final grade needed","weighted grade","class grade"] },

  { id:"age-calculator", name:"Age Calculator", cat:"Date & Time", url:"age-calculator.html",
    desc:"Exact age in years, months and days, plus your next birthday.", kw:["how old am i","date of birth","birthday countdown"] },
  { id:"date-calculator", name:"Date Calculator", cat:"Date & Time", url:"date-calculator.html",
    desc:"Add or subtract days from a date, or find the days between two dates.", kw:["days between dates","add days","business days"] },
  { id:"time-calculator", name:"Time Calculator", cat:"Date & Time", url:"time-calculator.html",
    desc:"Add or subtract hours, minutes and seconds, or find a duration.", kw:["duration","hours minutes seconds","time difference"] },

  { id:"unit-converter", name:"Unit Converter", cat:"Conversion", url:"unit-converter.html",
    desc:"Convert length, weight, temperature, area, volume and speed.", kw:["length converter","weight converter","temperature converter","cm to inches","kg to lbs"] },
  { id:"fuel-cost-calculator", name:"Fuel Cost Calculator", cat:"Conversion", url:"fuel-cost-calculator.html",
    desc:"Estimate trip fuel use and cost from distance and efficiency.", kw:["gas cost","mpg","trip fuel cost"] },
];

const CALCBEAM_CATEGORIES = [
  { name:"Math", url:"math-calculators.html", desc:"Percentages, ratios, fractions, averages and a full scientific calculator." },
  { name:"Finance", url:"finance-calculators.html", desc:"Loans, mortgages, interest, tips, tax, margin and ROI." },
  { name:"Health", url:"health-calculators.html", desc:"BMI and calorie estimators for everyday health tracking." },
  { name:"Education", url:"education-calculators.html", desc:"GPA and grade calculators for students." },
  { name:"Date & Time", url:"date-time-calculators.html", desc:"Age, date differences, and time duration tools." },
  { name:"Conversion", url:"conversion-calculators.html", desc:"Unit conversion for length, weight, temperature and more." },
];

// ---- Theme ----
(function initTheme(){
  const saved = localStorage.getItem("calcbeam-theme");
  const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  const theme = saved || (prefersDark ? "dark" : "light");
  document.documentElement.setAttribute("data-theme", theme);
})();

function toggleTheme(){
  const current = document.documentElement.getAttribute("data-theme");
  const next = current === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", next);
  localStorage.setItem("calcbeam-theme", next);
  updateThemeIcon(next);
}
function updateThemeIcon(theme){
  const btn = document.getElementById("themeToggle");
  if(!btn) return;
  btn.setAttribute("aria-label", theme === "dark" ? "Switch to light mode" : "Switch to dark mode");
}

// ---- Mobile nav ----
function initMobileNav(){
  const toggle = document.getElementById("menuToggle");
  const nav = document.getElementById("mainNav");
  if(!toggle || !nav) return;
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", open ? "true" : "false");
  });
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  }));
}

// ---- Recently used calculators ----
function trackRecentCalculator(id){
  try{
    let recents = JSON.parse(localStorage.getItem("calcbeam-recent") || "[]");
    recents = recents.filter(r => r !== id);
    recents.unshift(id);
    recents = recents.slice(0, 6);
    localStorage.setItem("calcbeam-recent", JSON.stringify(recents));
  }catch(e){ /* localStorage unavailable — fail silently */ }
}

function renderRecentCalculators(containerId){
  const el = document.getElementById(containerId);
  if(!el) return;
  let recents = [];
  try{ recents = JSON.parse(localStorage.getItem("calcbeam-recent") || "[]"); }catch(e){}
  const items = recents.map(id => CALCBEAM_CALCS.find(c => c.id === id)).filter(Boolean);
  if(items.length === 0){
    el.closest(".section")?.classList.add("visually-hidden");
    return;
  }
  el.innerHTML = items.map(c => `<a class="recent-chip" href="${c.url}">${c.name}</a>`).join("");
}

// ---- Search ----
function searchCalculators(query){
  const q = query.trim().toLowerCase();
  if(!q) return [];
  return CALCBEAM_CALCS.filter(c => {
    return c.name.toLowerCase().includes(q) ||
           c.cat.toLowerCase().includes(q) ||
           c.desc.toLowerCase().includes(q) ||
           c.kw.some(k => k.toLowerCase().includes(q));
  }).slice(0, 8);
}

function initHeaderSearch(){
  const input = document.getElementById("headerSearchInput");
  const results = document.getElementById("headerSearchResults");
  const form = document.getElementById("headerSearchForm");
  if(!input || !results) return;

  input.addEventListener("input", () => {
    const matches = searchCalculators(input.value);
    if(input.value.trim() === ""){ results.classList.remove("show"); results.innerHTML = ""; return; }
    if(matches.length === 0){
      results.innerHTML = `<div class="search-empty">No calculators found. Try “percentage”, “loan”, or “BMI”.</div>`;
    }else{
      results.innerHTML = matches.map(c =>
        `<a href="${prefixPath(c.url)}"><div class="sr-cat">${c.cat}</div>${c.name}</a>`
      ).join("");
    }
    results.classList.add("show");
  });

  document.addEventListener("click", (e) => {
    if(!results.contains(e.target) && e.target !== input) results.classList.remove("show");
  });

  if(form){
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const matches = searchCalculators(input.value);
      if(matches[0]) window.location.href = prefixPath(matches[0].url);
    });
  }
}

// Adjust relative links when this script is loaded from a subfolder (e.g. /blog/)
function prefixPath(url){
  const isSubfolder = window.location.pathname.includes("/blog/");
  return isSubfolder ? "../" + url : url;
}

// ---- Header/Footer partials (avoids duplicating nav markup by hand) ----
document.addEventListener("DOMContentLoaded", () => {
  initMobileNav();
  initHeaderSearch();
  const themeBtn = document.getElementById("themeToggle");
  if(themeBtn){
    themeBtn.addEventListener("click", toggleTheme);
    updateThemeIcon(document.documentElement.getAttribute("data-theme"));
  }
  renderRecentCalculators("recentStrip");
});
