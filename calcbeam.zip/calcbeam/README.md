# CalcBeam

**Smart Calculators. Simple Answers.**

A 100% static HTML/CSS/JavaScript calculator website. No build step, no
framework, no backend, no database — every calculation runs entirely in
the visitor's browser.

---

## What's included — all 25 calculators, fully working

- Full design system (`css/style.css`) with light + dark mode
- Shared header/footer, mobile nav, client-side search, "recently used"
  calculators via `localStorage` (`js/main.js`)
- **All 25 calculators from the original spec, fully functional and
  browser-tested:** Percentage, Age, BMI, Mortgage, Loan, Compound
  Interest, Discount, Calorie, GPA, Grade, Scientific, Simple Interest,
  Investment, Profit Margin, Date, Sales Tax, Tip, Ratio, Fraction,
  Average, Time, Unit Converter, Fuel Cost, ROI, Markup
- Category hub pages (Math, Finance, Health, Education, Date & Time,
  Conversion) and the main `calculators.html` directory
- Blog with 4 real articles
- Trust/legal pages: About, Contact, Privacy Policy, Terms, Disclaimer,
  Cookie Policy, Search, 404
- `robots.txt` and `sitemap.xml` covering every page, including blog
  articles
- SEO: unique titles/descriptions, canonical tags, Open Graph + Twitter
  cards, breadcrumb + FAQ JSON-LD structured data on every calculator/blog
  page

**Verified with an automated browser test suite** (Playwright) against
real hand-calculated expected values for every calculator — see
"Testing" below.


---

## 1. Run it locally

No build step needed. Either:

- Just double-click `index.html` to open it in a browser, **or**
- Serve it properly (recommended, avoids relative-path quirks):
  ```bash
  cd calcbeam
  python3 -m http.server 8080
  # then open http://localhost:8080
  ```

## 2. Deploy to Hostinger

1. Log in to hPanel → **File Manager** (or use FTP/SFTP).
2. Upload the entire contents of the `calcbeam/` folder into
   `public_html/` (so `index.html` sits directly inside `public_html/`,
   not inside a subfolder).
3. Done — visit your domain.

## 3. Deploy to Netlify

**Drag-and-drop:** go to [app.netlify.com/drop](https://app.netlify.com/drop)
and drag the `calcbeam` folder in. Netlify hosts it immediately.

**Git-based:** push this folder to a GitHub repo, then in Netlify choose
"Import from Git." Build command: leave blank. Publish directory: `/`
(the repo root, since there's no build step).

## 4. Deploy to GitHub Pages

1. Push the contents of `calcbeam/` to a GitHub repository.
2. Repo → **Settings → Pages** → Source: `main` branch, root folder.
3. Save. Your site will be live at `https://<username>.github.io/<repo>/`.
   - If deploying to a project subpath rather than a custom domain, update
     the `<link rel="canonical">` and `og:url` values (currently set to
     `https://calcbeam.com/...`) to match your real URL before relying on
     search engines indexing it.

## 5. Deploy to Cloudflare Pages

1. Connect the Git repo in the Cloudflare Pages dashboard, or upload the
   folder directly via "Direct Upload."
2. Build command: none. Output directory: `/`.

---

## Where to edit things

| What | Where |
|---|---|
| Global styles, colors, dark mode | `css/style.css` |
| Header/nav, footer, search, dark-mode toggle, "recently used" | `js/main.js` |
| One calculator's math logic | `js/calculators/<name>.js` |
| One calculator's page content (intro, formula, FAQ, related links) | `<name>.html` directly |
| Site branding (logo, favicon, OG image) | `assets/logo.svg`, `assets/favicon.svg`, `assets/images/og-default.svg` |
| Legal page text | `about.html`, `privacy-policy.html`, `terms.html`, etc. — plain HTML, edit directly |
| Blog articles | `scripts/build_blog.py` (article content lives in the `ARTICLES` list) then re-run `python3 scripts/build_blog.py` from the project root |

The `scripts/` folder holds the Python generators originally used to
scaffold the repeated page chrome (header, footer, breadcrumbs, schema)
consistently across every page. **They are optional** — every HTML file
in the repo is a plain, complete, static file you can hand-edit directly
with no Python involved. Only touch `scripts/` if you want to regenerate
many pages at once from a shared template.

## How to add a new calculator

1. Copy the closest existing calculator's `.html` file (e.g.
   `discount-calculator.html` for a simple percentage-based calculator) as
   your starting point, and copy its `js/calculators/<name>.js` file.
2. Update: `<title>`, meta description, canonical URL, `<h1>`, the
   breadcrumb, the JSON-LD `Article`/`FAQPage` blocks, the intro copy,
   formula section, worked example, FAQ, and "related calculators" links.
3. Rewrite the calculation logic in the new `js/calculators/<name>.js` —
   never use `eval()`; follow the pattern in `js/calculators/utils.js`
   (`CalcUtils.num`, `.fmt`, `.showError`, `.escapeHtml`) for safe parsing,
   formatting, and error handling.
4. Add a card for it on the relevant category page and on
   `calculators.html`.
5. Add the new URL to `sitemap.xml` (see below).

## How to update sitemap.xml

`sitemap.xml` is generated from whatever `.html` files actually exist in
the project root (excluding `404.html`). After adding or removing a page,
regenerate it:

```bash
cd calcbeam
python3 - <<'EOF'
import os
pages = sorted(f for f in os.listdir('.') if f.endswith('.html') and f != '404.html')
base = "https://calcbeam.com/"
lastmod = "2026-08-09"  # update to today's date
category = {"math-calculators.html","finance-calculators.html","health-calculators.html",
            "education-calculators.html","date-time-calculators.html","conversion-calculators.html"}
legal = {"about.html","contact.html","privacy-policy.html","terms.html","disclaimer.html",
         "cookie-policy.html","search.html"}
xml = ['<?xml version="1.0" encoding="UTF-8"?>','<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
for p in pages:
    prio = "1.0" if p == "index.html" else "0.9" if p == "calculators.html" else \
           "0.8" if p in category else "0.3" if p in legal else "0.7"
    freq = "yearly" if p in legal else "weekly" if (p in category or p in ("index.html","calculators.html")) else "monthly"
    xml += [f"  <url>", f"    <loc>{base}{p}</loc>", f"    <lastmod>{lastmod}</lastmod>",
            f"    <changefreq>{freq}</changefreq>", f"    <priority>{prio}</priority>", "  </url>"]
xml.append("</urlset>")
open("sitemap.xml","w").write("\n".join(xml) + "\n")
print(f"sitemap.xml regenerated with {len(pages)} URLs")
EOF
```

Also remember to include any new `blog/*.html` articles manually (the
script above only scans the root folder).

## Before going live: replace the domain placeholder

Every canonical tag, `og:url`, and the sitemap currently point at
`https://calcbeam.com/`. If your real domain is different, do a
project-wide find-and-replace of `calcbeam.com` before deploying, so
canonicals, Open Graph tags, and the sitemap all match your actual URL.

## Testing

Every calculator was verified with a headless-browser (Playwright) test
script that filled in real inputs and checked the computed result against
hand-calculated expected values, rather than just reading the code for
correctness. All 25 calculators pass. The test script itself isn't
included in this delivery (it isn't part of the live site), but the same
approach — `page.fill()` real values into each calculator's inputs and
read the `.readout` element — is a good way to regression-test after
future edits.

## Security notes

- No calculator uses `eval()` or `Function()` on user input. The
  Scientific Calculator uses a hand-written recursive-descent parser
  (`js/calculators/scientific-calculator.js`) restricted to numbers,
  named math functions, and arithmetic operators.
- Every calculator takes input only from `<input>`/`<select>` elements
  that are numeric, dropdown, or button-driven — none accept free-text
  that gets echoed back into the page unescaped.
- `CalcUtils.escapeHtml()` is available in `js/calculators/utils.js` for
  any future calculator that does need to echo free-text user input.

## AdSense readiness

Ad slot placeholders (`<div class="ad-slot">`) are positioned away from
calculator controls and page navigation, never overlapping clickable
elements. Before applying for AdSense, replace the placeholder divs with
your actual ad unit code and make sure you have a meaningful amount of
genuinely useful content live (the Phase 2 calculators + blog articles
will help here) — approval isn't guaranteed and depends on Google's
review.

---

Built as a static site: no npm, no build process, no server required.
