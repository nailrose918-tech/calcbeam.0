#!/usr/bin/env python3
from calc_template import build_calculator_page

# ============================================================ PERCENTAGE
build_calculator_page(
  slug="percentage-calculator", name="Percentage Calculator", category="Math", category_url="math-calculators.html",
  title="Percentage Calculator – Calculate Percentages Easily | CalcBeam",
  description="Free percentage calculator: find a percentage of a number, what percent one number is of another, and percentage increase or decrease.",
  intro="Calculate a percentage of a number, work out what percent one value is of another, or find a percentage increase or decrease — pick a mode below and get an instant result.",
  tool_html='''
      <div class="tool-tabs" role="tablist" aria-label="Percentage calculation type">
        <button class="tool-tab" data-mode="of" aria-selected="true" role="tab">% of a number</button>
        <button class="tool-tab" data-mode="isWhat" aria-selected="false" role="tab">X is what % of Y</button>
        <button class="tool-tab" data-mode="increase" aria-selected="false" role="tab">% Increase</button>
        <button class="tool-tab" data-mode="decrease" aria-selected="false" role="tab">% Decrease</button>
      </div>
      <div class="calc-panel" data-panel="of">
        <div class="field-row">
          <div class="field"><label for="ofPct">Percentage</label><div class="input-suffix"><input type="number" id="ofPct" value="15"><span>%</span></div></div>
          <div class="field"><label for="ofBase">Of number</label><input type="number" id="ofBase" value="240"></div>
        </div>
      </div>
      <div class="calc-panel" data-panel="isWhat" style="display:none;">
        <div class="field-row">
          <div class="field"><label for="iwPart">This number</label><input type="number" id="iwPart" placeholder="e.g. 45"></div>
          <div class="field"><label for="iwWhole">Is what % of</label><input type="number" id="iwWhole" placeholder="e.g. 180"></div>
        </div>
      </div>
      <div class="calc-panel" data-panel="increase" style="display:none;">
        <div class="field-row">
          <div class="field"><label for="incFrom">From</label><input type="number" id="incFrom" placeholder="e.g. 50"></div>
          <div class="field"><label for="incTo">To</label><input type="number" id="incTo" placeholder="e.g. 65"></div>
        </div>
      </div>
      <div class="calc-panel" data-panel="decrease" style="display:none;">
        <div class="field-row">
          <div class="field"><label for="decOriginal">Original value</label><input type="number" id="decOriginal" placeholder="e.g. 200"></div>
          <div class="field"><label for="decPct">Decrease by</label><div class="input-suffix"><input type="number" id="decPct" placeholder="e.g. 20"><span>%</span></div></div>
        </div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Choose the calculation you need using the tabs: percentage of a number, what percent X is of Y, percentage increase, or percentage decrease.",
    "Enter your values into the fields — the result updates instantly as you type.",
    "Read the result and supporting figures in the panel on the right.",
  ],
  formula_html="Percentage of a number: <br>(percentage &divide; 100) &times; number<br><br>X is what % of Y: <br>(X &divide; Y) &times; 100<br><br>Percentage change: <br>((new &minus; old) &divide; |old|) &times; 100",
  example_html="<p><strong>What is 15% of 240?</strong><br>(15 &divide; 100) &times; 240 = <strong>36</strong></p><p>If a $50 item rises to $65, the percentage increase is ((65&minus;50)&divide;50)&times;100 = <strong>30%</strong>.</p>",
  explanation="<p>A percentage expresses a number as a fraction of 100. It's the same underlying math whether you're calculating a tip, a grade, a discount, or a raise — only the labels change. Percentage increase and decrease always divide by the <em>original</em> value, not the new one, which is the detail most people get wrong.</p>",
  mistakes=[
    "Dividing by the new value instead of the original when calculating percentage change.",
    "Forgetting that a 50% decrease followed by a 50% increase does not return you to the original number.",
    "Mixing up 'percent of' with 'percentage points' — a change from 40% to 50% is a 10 percentage-point increase, but a 25% relative increase.",
  ],
  faqs=[
    ("How do I calculate a percentage increase?", "Subtract the original value from the new value, divide by the original value, then multiply by 100. A negative result means a decrease."),
    ("What's the difference between percentage and percentage points?", "Percentage measures relative change (e.g. a 25% increase), while percentage points measure the raw difference between two percentages (e.g. going from 40% to 50% is 10 percentage points)."),
    ("Can a percentage be negative?", "Yes — a negative percentage typically represents a decrease, such as a loss or a drop in value."),
  ],
  related=[("Discount Calculator","discount-calculator.html"),("Profit Margin Calculator","profit-margin-calculator.html"),("Ratio Calculator","ratio-calculator.html"),("Sales Tax Calculator","sales-tax-calculator.html")],
  js_file="percentage-calculator.js",
)

# ============================================================ AGE
build_calculator_page(
  slug="age-calculator", name="Age Calculator", category="Date & Time", category_url="date-time-calculators.html",
  title="Age Calculator – Find Your Exact Age | CalcBeam",
  description="Calculate your exact age in years, months and days from your date of birth, plus how many days until your next birthday.",
  intro="Enter your date of birth to find your exact age in years, months, and days, along with your total days lived and a countdown to your next birthday.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="dobInput">Date of birth</label><input type="date" id="dobInput"></div>
        <div class="field"><label for="asOfInput">Calculate age as of</label><input type="date" id="asOfInput"></div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter your date of birth in the first field.",
    "By default, age is calculated as of today — change the second date to calculate age as of any other date.",
    "View your exact age plus total days, weeks, months lived, and days until your next birthday.",
  ],
  formula_html="Years = end year &minus; birth year (adjusted if the birth month/day hasn't occurred yet)<br>Remaining months and days are calculated from the adjusted calendar difference, correctly accounting for leap years and varying month lengths.",
  example_html="<p>Someone born on <strong>March 14, 2000</strong>, checked on <strong>August 9, 2026</strong>, is <strong>26 years, 4 months, 26 days</strong> old — with their next birthday about 7 months away.</p>",
  explanation="<p>Calendar-based age isn't just \"days &divide; 365\" — months have different lengths and leap years add an extra day roughly every four years. This calculator walks the calendar month by month so the years/months/days breakdown always matches what a calendar would show.</p>",
  mistakes=[
    "Estimating age by dividing total days by 365.25 — this can be off by a day or two around leap years.",
    "Forgetting that if the birth day hasn't occurred yet this month, the day count borrows from the previous month.",
    "Assuming someone born on February 29 ages on February 28 in non-leap years without checking your specific use case.",
  ],
  faqs=[
    ("How is age calculated to the exact day?", "The calculator compares the year, month, and day of your birth date to the comparison date, borrowing from the previous month/year when the day or month hasn't occurred yet — the same way you'd count on a calendar."),
    ("Can I calculate age as of a future or past date?", "Yes — change the 'Calculate age as of' field to any date on or after the date of birth."),
    ("Does this account for leap years?", "Yes, the day and month math is calendar-accurate, so leap years are automatically handled."),
  ],
  related=[("Date Calculator","date-calculator.html"),("Time Calculator","time-calculator.html"),("GPA Calculator","gpa-calculator.html")],
  js_file="age-calculator.js",
)

# ============================================================ BMI
build_calculator_page(
  slug="bmi-calculator", name="BMI Calculator", category="Health", category_url="health-calculators.html",
  title="BMI Calculator – Body Mass Index Calculator | CalcBeam",
  description="Free BMI calculator supporting metric and imperial units. Calculate your body mass index and see which weight category it falls into.",
  intro="Calculate your Body Mass Index (BMI) from height and weight, in metric or imperial units, and see which weight category your result falls into.",
  tool_html='''
      <div class="tool-tabs" role="tablist" aria-label="Unit system">
        <button class="tool-tab" data-mode="metric" aria-selected="true" role="tab">Metric</button>
        <button class="tool-tab" data-mode="imperial" aria-selected="false" role="tab">Imperial</button>
      </div>
      <div id="panel-metric">
        <div class="field-row">
          <div class="field"><label for="mHeight">Height</label><div class="input-suffix"><input type="number" id="mHeight" placeholder="e.g. 170"><span>cm</span></div></div>
          <div class="field"><label for="mWeight">Weight</label><div class="input-suffix"><input type="number" id="mWeight" placeholder="e.g. 68"><span>kg</span></div></div>
        </div>
      </div>
      <div id="panel-imperial" style="display:none;">
        <div class="field-row">
          <div class="field"><label for="iFeet">Height (feet)</label><input type="number" id="iFeet" placeholder="e.g. 5"></div>
          <div class="field"><label for="iInches">Height (inches)</label><input type="number" id="iInches" placeholder="e.g. 7"></div>
        </div>
        <div class="field"><label for="iWeight">Weight</label><div class="input-suffix"><input type="number" id="iWeight" placeholder="e.g. 150"><span>lb</span></div></div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="callout callout-warn">This calculator provides an estimate and is not medical advice.</div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Choose Metric (cm/kg) or Imperial (ft/in/lb) units.",
    "Enter your height and weight.",
    "Your BMI and weight category appear instantly on the right.",
  ],
  formula_html="Metric: BMI = weight (kg) &divide; height (m)&sup2;<br>Imperial: BMI = 703 &times; weight (lb) &divide; height (in)&sup2;",
  example_html="<p>A person who is <strong>170 cm</strong> tall and weighs <strong>68 kg</strong>:<br>1.70&sup2; = 2.89<br>68 &divide; 2.89 = <strong>23.5</strong> — within the healthy weight range.</p>",
  explanation="<p>BMI is a screening tool, not a diagnosis. It doesn't distinguish between muscle and fat, so athletes and very muscular people can show a higher BMI without excess body fat. It's most useful as a general population-level indicator rather than a precise individual health measurement.</p>",
  mistakes=[
    "Entering height in the wrong unit (e.g. meters instead of centimeters in the metric field).",
    "Treating BMI as a precise medical diagnosis rather than a general screening estimate.",
    "Ignoring that BMI ranges are population averages and may not fit every body type, age, or muscle mass.",
  ],
  faqs=[
    ("What is a healthy BMI range?", "For most adults, 18.5–24.9 is considered a healthy weight range, 25–29.9 is overweight, and 30+ falls into the obesity range — though individual health depends on many other factors."),
    ("Is BMI accurate for athletes?", "Not always — BMI doesn't separate muscle from fat, so muscular individuals can register a higher BMI without higher body fat."),
    ("Does BMI differ for children?", "Yes, children and teens use age- and sex-specific BMI percentiles rather than the fixed adult categories used here."),
  ],
  related=[("Calorie Calculator","calorie-calculator.html"),("Average Calculator","average-calculator.html")],
  js_file="bmi-calculator.js",
)

# ============================================================ MORTGAGE
build_calculator_page(
  slug="mortgage-calculator", name="Mortgage Calculator", category="Finance", category_url="finance-calculators.html",
  title="Mortgage Calculator – Estimate Your Monthly Payment | CalcBeam",
  description="Free mortgage calculator. Estimate your monthly mortgage payment including principal, interest, property tax and home insurance.",
  intro="Estimate your total monthly mortgage payment, including principal, interest, property tax, and home insurance, based on your home price and loan terms.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="homePrice">Home price</label><div class="input-suffix"><input type="number" id="homePrice" placeholder="e.g. 350000"><span>$</span></div></div>
        <div class="field"><label for="downPayment">Down payment</label><div class="input-suffix"><input type="number" id="downPayment" placeholder="e.g. 70000"><span>$</span></div></div>
      </div>
      <div class="field-row">
        <div class="field"><label for="interestRate">Interest rate (annual)</label><div class="input-suffix"><input type="number" id="interestRate" placeholder="e.g. 6.5" step="0.01"><span>%</span></div></div>
        <div class="field"><label for="loanTerm">Loan term</label><div class="input-suffix"><input type="number" id="loanTerm" placeholder="e.g. 30"><span>yrs</span></div></div>
      </div>
      <div class="field-row">
        <div class="field"><label for="propertyTax">Annual property tax</label><div class="input-suffix"><input type="number" id="propertyTax" placeholder="e.g. 3600"><span>$</span></div></div>
        <div class="field"><label for="homeInsurance">Annual home insurance</label><div class="input-suffix"><input type="number" id="homeInsurance" placeholder="e.g. 1400"><span>$</span></div></div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter the home price and your planned down payment.",
    "Enter the annual interest rate and loan term in years.",
    "Optionally add estimated annual property tax and home insurance for a full monthly payment estimate.",
  ],
  formula_html="M = P &times; [r(1+r)&#8319;] &divide; [(1+r)&#8319; &minus; 1]<br><br>Where P = loan principal, r = monthly interest rate, n = number of payments (months)",
  example_html="<p>A <strong>$350,000</strong> home with a <strong>$70,000</strong> down payment, <strong>6.5%</strong> interest, and a <strong>30-year</strong> term gives a principal of $280,000 and a principal &amp; interest payment of roughly <strong>$1,770/month</strong> — before tax and insurance.</p>",
  explanation="<p>Your total monthly housing payment is often more than just principal and interest. Property tax and homeowners insurance are commonly collected monthly into an escrow account by your lender, which is why this calculator adds them to the principal-and-interest figure to estimate your full payment (sometimes called PITI).</p>",
  mistakes=[
    "Forgetting to include property tax and insurance, which can add hundreds of dollars to the real monthly cost.",
    "Using the home price instead of the loan amount (home price minus down payment) when comparing to a lender quote.",
    "Ignoring PMI (private mortgage insurance), which many lenders require when the down payment is under 20%.",
  ],
  faqs=[
    ("What does PITI mean?", "Principal, Interest, Taxes, and Insurance — the four components most lenders bundle into a single monthly mortgage payment."),
    ("Does this calculator include PMI?", "No. If your down payment is less than 20% of the home price, ask your lender about private mortgage insurance (PMI), which isn't included in this estimate."),
    ("Why is my real payment different from this estimate?", "Lenders may also include HOA fees, adjustable rates, or rounding conventions that differ slightly from this simplified estimate."),
  ],
  related=[("Loan Calculator","loan-calculator.html"),("Compound Interest Calculator","compound-interest-calculator.html"),("Investment Calculator","investment-calculator.html")],
  js_file="mortgage-calculator.js",
)

# ============================================================ LOAN
build_calculator_page(
  slug="loan-calculator", name="Loan Calculator", category="Finance", category_url="finance-calculators.html",
  title="Loan Calculator – Monthly Payment & Total Interest | CalcBeam",
  description="Free loan calculator for car loans, personal loans, and more. Calculate your monthly payment, total interest, and total repayment.",
  intro="Calculate the monthly payment, total interest, and total repayment for any fixed-rate loan — car loans, personal loans, and more.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="loanAmount">Loan amount</label><div class="input-suffix"><input type="number" id="loanAmount" placeholder="e.g. 20000"><span>$</span></div></div>
        <div class="field"><label for="loanRate">Interest rate (annual)</label><div class="input-suffix"><input type="number" id="loanRate" placeholder="e.g. 7.5" step="0.01"><span>%</span></div></div>
      </div>
      <div class="field"><label for="loanTermYears">Loan term</label><div class="input-suffix"><input type="number" id="loanTermYears" placeholder="e.g. 5"><span>yrs</span></div></div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter the loan amount you plan to borrow.",
    "Enter the annual interest rate offered by your lender.",
    "Enter the loan term in years to see your monthly payment and total interest.",
  ],
  formula_html="M = P &times; [r(1+r)&#8319;] &divide; [(1+r)&#8319; &minus; 1]<br><br>Where P = loan amount, r = monthly interest rate (annual rate &divide; 12), n = total number of monthly payments",
  example_html="<p>A <strong>$20,000</strong> loan at <strong>7.5%</strong> over <strong>5 years</strong> (60 payments) comes to about <strong>$401/month</strong>, with roughly <strong>$4,050</strong> in total interest.</p>",
  explanation="<p>This is the standard amortized loan formula used by nearly all fixed-rate installment loans. Each payment is the same amount, but early payments are weighted more toward interest and later payments more toward principal — the loan balance shrinks faster near the end of the term.</p>",
  mistakes=[
    "Comparing loans using only the monthly payment instead of total interest paid over the full term.",
    "Forgetting that a longer term lowers the monthly payment but usually increases total interest paid.",
    "Not accounting for lender fees or origination costs, which aren't part of this basic payment estimate.",
  ],
  faqs=[
    ("How is my monthly loan payment calculated?", "Using the standard amortization formula, which spreads the loan amount and interest evenly across every payment so the payment amount stays constant for the life of the loan."),
    ("Does a shorter loan term save money?", "Usually yes — a shorter term means less time for interest to accrue, so total interest paid is typically lower, even though the monthly payment is higher."),
    ("What if my loan has a variable interest rate?", "This calculator assumes a fixed rate for the full term. For variable-rate loans, payments will change if the rate changes."),
  ],
  related=[("Mortgage Calculator","mortgage-calculator.html"),("Simple Interest Calculator","simple-interest-calculator.html"),("ROI Calculator","roi-calculator.html")],
  js_file="loan-calculator.js",
)

# ============================================================ COMPOUND INTEREST
build_calculator_page(
  slug="compound-interest-calculator", name="Compound Interest Calculator", category="Finance", category_url="finance-calculators.html",
  title="Compound Interest Calculator – Project Your Savings Growth | CalcBeam",
  description="Free compound interest calculator with monthly contributions. See how your savings or investment could grow over time.",
  intro="See how your savings could grow with compound interest and optional monthly contributions, over any time period and compounding frequency.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="ciPrincipal">Starting amount</label><div class="input-suffix"><input type="number" id="ciPrincipal" placeholder="e.g. 5000"><span>$</span></div></div>
        <div class="field"><label for="ciRate">Annual interest rate</label><div class="input-suffix"><input type="number" id="ciRate" placeholder="e.g. 6" step="0.01"><span>%</span></div></div>
      </div>
      <div class="field-row">
        <div class="field"><label for="ciYears">Duration</label><div class="input-suffix"><input type="number" id="ciYears" placeholder="e.g. 10"><span>yrs</span></div></div>
        <div class="field"><label for="ciFreq">Compounding frequency</label>
          <select id="ciFreq">
            <option value="1">Annually</option><option value="4">Quarterly</option>
            <option value="12" selected>Monthly</option><option value="365">Daily</option>
          </select>
        </div>
      </div>
      <div class="field"><label for="ciContribution">Additional monthly contribution (optional)</label><div class="input-suffix"><input type="number" id="ciContribution" placeholder="e.g. 200"><span>$</span></div></div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter your starting amount and expected annual interest rate.",
    "Choose how often interest compounds — monthly is most common for savings accounts.",
    "Optionally add a monthly contribution to see how regular saving accelerates growth.",
  ],
  formula_html="A = P(1 + r/n)&#8319;&#7524; + PMT &times; [((1 + r/n)&#8319;&#7524; &minus; 1) / (r/n)]<br><br>Where P = principal, r = annual rate, n = compounds per year, t = years, PMT = periodic contribution",
  example_html="<p><strong>$5,000</strong> at <strong>6%</strong> annually, compounded monthly, with a <strong>$200/month</strong> contribution over <strong>10 years</strong>, grows to roughly <strong>$41,900</strong> — about $28,000 of that from contributions and interest combined beyond the original $5,000.</p>",
  explanation="<p>Compound interest means you earn interest not only on your original deposit, but also on the interest that's already been added. The more frequently interest compounds, and the longer your money stays invested, the bigger the gap between compound growth and simple, flat interest becomes.</p>",
  mistakes=[
    "Underestimating how much regular contributions matter compared to the starting lump sum over long periods.",
    "Assuming a fixed rate of return, when real markets fluctuate year to year.",
    "Confusing compounding frequency with contribution frequency — they can be different.",
  ],
  faqs=[
    ("What compounding frequency should I choose?", "Use whatever your bank or investment account actually applies — many savings accounts compound monthly or daily, while some bonds compound annually."),
    ("Is this guaranteed growth?", "No — this projects growth at a constant assumed rate. Real investments (outside of fixed-rate savings accounts) fluctuate, so treat this as an estimate, not a guarantee."),
    ("How much does compounding frequency actually matter?", "More frequent compounding produces slightly higher returns at the same stated annual rate, but the difference is usually smaller than the impact of the rate itself or added contributions."),
  ],
  related=[("Investment Calculator","investment-calculator.html"),("Simple Interest Calculator","simple-interest-calculator.html"),("ROI Calculator","roi-calculator.html")],
  js_file="compound-interest-calculator.js",
)

# ============================================================ TIP
build_calculator_page(
  slug="tip-calculator", name="Tip Calculator", category="Finance", category_url="finance-calculators.html",
  title="Tip Calculator – Split the Bill & Calculate Gratuity | CalcBeam",
  description="Free tip calculator. Work out the tip amount, total bill, and per-person split for any group size.",
  intro="Calculate the right tip, total bill, and per-person split — enter the bill, pick a tip percentage, and split it across your group.",
  tool_html='''
      <div class="field"><label for="billAmount">Bill amount</label><div class="input-suffix"><input type="number" id="billAmount" placeholder="e.g. 84.50" step="0.01"><span>$</span></div></div>
      <div class="field">
        <label>Tip percentage</label>
        <div class="radio-group">
          <button type="button" class="tool-tab tip-pill" data-tip="10">10%</button>
          <button type="button" class="tool-tab tip-pill" data-tip="15">15%</button>
          <button type="button" class="tool-tab tip-pill" data-tip="18">18%</button>
          <button type="button" class="tool-tab tip-pill" data-tip="20">20%</button>
        </div>
      </div>
      <div class="field-row">
        <div class="field"><label for="tipPercent">Custom tip %</label><div class="input-suffix"><input type="number" id="tipPercent" value="18"><span>%</span></div></div>
        <div class="field"><label for="peopleCount">Split between</label><input type="number" id="peopleCount" value="1" min="1"></div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter your bill total before tip.",
    "Pick a common tip percentage or type a custom one.",
    "Enter the number of people splitting the bill to see the per-person amount.",
  ],
  formula_html="Tip = Bill &times; (tip % &divide; 100)<br>Total = Bill + Tip<br>Per person = Total &divide; number of people",
  example_html="<p>An <strong>$84.50</strong> bill with an <strong>18%</strong> tip split between <strong>4</strong> people: tip = $15.21, total = $99.71, so each person pays about <strong>$24.93</strong>.</p>",
  explanation="<p>Tipping conventions vary by country and by service type, but the math is always the same: a percentage of the pre-tax (or sometimes pre-tip) bill. Splitting evenly is the simplest approach, though some groups prefer splitting based on what each person actually ordered.</p>",
  mistakes=[
    "Calculating the tip on the post-tax total instead of the pre-tax subtotal, which slightly over-tips.",
    "Forgetting that an even split assumes everyone ordered roughly the same amount.",
    "Rounding each person's share down, which can leave the total short of the actual bill.",
  ],
  faqs=[
    ("Should I tip on the total before or after tax?", "Tipping conventions vary, but many etiquette guides suggest tipping on the pre-tax subtotal. Use whichever the bill or local custom specifies."),
    ("What's a standard tip percentage?", "In the US, 15–20% is common for full-service dining; other services and countries vary widely."),
    ("How do I split a bill unevenly?", "This calculator assumes an even split. For itemized splitting, add up each person's items separately, then apply the same tip percentage to each portion."),
  ],
  related=[("Sales Tax Calculator","sales-tax-calculator.html"),("Discount Calculator","discount-calculator.html"),("Average Calculator","average-calculator.html")],
  js_file="tip-calculator.js",
)

# ============================================================ DISCOUNT
build_calculator_page(
  slug="discount-calculator", name="Discount Calculator", category="Finance", category_url="finance-calculators.html",
  title="Discount Calculator – Calculate Sale Price & Savings | CalcBeam",
  description="Free discount calculator. Enter the original price and discount percentage to find the sale price and amount saved.",
  intro="Enter the original price and discount percentage to instantly see the final sale price and how much you save.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="origPrice">Original price</label><div class="input-suffix"><input type="number" id="origPrice" placeholder="e.g. 89.99" step="0.01"><span>$</span></div></div>
        <div class="field"><label for="discountPct">Discount</label><div class="input-suffix"><input type="number" id="discountPct" placeholder="e.g. 25"><span>%</span></div></div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter the item's original price.",
    "Enter the discount percentage.",
    "See the final sale price and the amount you save.",
  ],
  formula_html="Amount off = Original price &times; (discount % &divide; 100)<br>Sale price = Original price &minus; Amount off",
  example_html="<p>An <strong>$89.99</strong> item at <strong>25%</strong> off: amount off = $22.50, so the sale price is <strong>$67.49</strong>.</p>",
  explanation="<p>A discount reduces the price by a percentage of the <em>original</em> price, not the sale price. Stacked discounts (like an extra 10% off an already-discounted item) are applied one after another, not added together — 25% off followed by 10% off is not the same as 35% off.</p>",
  mistakes=[
    "Adding two discount percentages together instead of applying them one after another.",
    "Applying the discount to the wrong price when an item has already been marked down once.",
    "Forgetting that sales tax is usually calculated on the discounted price, not the original price.",
  ],
  faqs=[
    ("How do I calculate a discount percentage from two prices?", "Use the Percentage Calculator's percentage-decrease mode, or subtract the sale price from the original, divide by the original, and multiply by 100."),
    ("How do stacked discounts work?", "Each discount applies to the price after the previous discount, so two 20% discounts together equal a 36% total discount, not 40%."),
    ("Does this include sales tax?", "No — this calculates the discounted price only. Use the Sales Tax Calculator to add tax on top of the discounted price."),
  ],
  related=[("Sales Tax Calculator","sales-tax-calculator.html"),("Percentage Calculator","percentage-calculator.html"),("Markup Calculator","markup-calculator.html")],
  js_file="discount-calculator.js",
)

# ============================================================ GPA
build_calculator_page(
  slug="gpa-calculator", name="GPA Calculator", category="Education", category_url="education-calculators.html",
  title="GPA Calculator – Calculate Your Grade Point Average | CalcBeam",
  description="Free GPA calculator. Add your courses, grades, and credit hours to calculate your semester or cumulative GPA on a 4.0 scale.",
  intro="Add each course's letter grade and credit hours to calculate your GPA on the standard 4.0 scale.",
  tool_html='''
      <div id="courseRows"></div>
      <button class="btn btn-ghost" id="addCourseBtn" type="button" style="margin-bottom:14px;">+ Add course</button>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "For each course, choose the letter grade you received (or expect).",
    "Enter the credit hours for that course.",
    "Add or remove course rows as needed — your GPA updates automatically.",
  ],
  formula_html="GPA = (sum of (grade points &times; credit hours)) &divide; (sum of credit hours)",
  example_html="<p>Three courses — A (3 credits), B+ (3 credits), A- (4 credits):<br>(4.0&times;3) + (3.3&times;3) + (3.7&times;4) = 12 + 9.9 + 14.8 = 36.7<br>36.7 &divide; 10 credits = <strong>3.67 GPA</strong></p>",
  explanation="<p>GPA weights each grade by how many credit hours the course is worth, so a 4-credit class affects your GPA more than a 1-credit class. This calculator uses the standard US 4.0 scale (A = 4.0 down to F = 0.0) — some schools use slightly different scales, so check your institution's official scale for registrar purposes.</p>",
  mistakes=[
    "Forgetting to weight grades by credit hours, which skews the average toward smaller classes.",
    "Using a school-specific grading scale that differs from the standard 4.0 scale without adjusting the grade points.",
    "Leaving out in-progress or repeated courses that your school counts differently in cumulative GPA.",
  ],
  faqs=[
    ("What GPA scale does this use?", "The standard US 4.0 scale, where A = 4.0, A- = 3.7, B+ = 3.3, and so on down to F = 0.0."),
    ("Does this calculate cumulative or semester GPA?", "Either — add only this semester's courses for a semester GPA, or all your courses to date for a cumulative GPA."),
    ("My school uses a different scale — can I still use this?", "The math (weighted average by credit hours) is the same everywhere; you may need to mentally convert your school's specific grade points if they differ from the standard scale shown here."),
  ],
  related=[("Grade Calculator","grade-calculator.html"),("Average Calculator","average-calculator.html"),("Percentage Calculator","percentage-calculator.html")],
  js_file="gpa-calculator.js",
)

# ============================================================ UNIT CONVERTER
build_calculator_page(
  slug="unit-converter", name="Unit Converter", category="Conversion", category_url="conversion-calculators.html",
  title="Unit Converter – Length, Weight, Temperature & More | CalcBeam",
  description="Free unit converter for length, weight, temperature, area, volume and speed. Fast, accurate conversions in your browser.",
  intro="Convert between units of length, weight, temperature, area, volume, and speed — pick a category, choose your units, and get an instant result.",
  tool_html='''
      <div class="field">
        <label for="convCategory">Category</label>
        <select id="convCategory">
          <option value="length" selected>Length</option>
          <option value="weight">Weight</option>
          <option value="temperature">Temperature</option>
          <option value="area">Area</option>
          <option value="volume">Volume</option>
          <option value="speed">Speed</option>
        </select>
      </div>
      <div class="field"><label for="convValue">Value</label><input type="number" id="convValue" placeholder="e.g. 100"></div>
      <div class="field-row" style="align-items:end;">
        <div class="field"><label for="convFrom">From</label><select id="convFrom"></select></div>
        <div class="field" style="display:flex;gap:8px;align-items:flex-end;">
          <div style="flex:1;"><label for="convTo">To</label><select id="convTo"></select></div>
          <button class="icon-btn" id="swapUnits" type="button" aria-label="Swap units" style="margin-bottom:2px;">&#8646;</button>
        </div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Choose a conversion category: length, weight, temperature, area, volume, or speed.",
    "Enter the value you want to convert.",
    "Pick the 'from' and 'to' units — use the swap button to quickly reverse the conversion.",
  ],
  formula_html="Most conversions: result = value &times; (from-unit factor &divide; to-unit factor), relative to a fixed base unit per category.<br><br>Temperature: &deg;F = &deg;C &times; 9/5 + 32  |  K = &deg;C + 273.15",
  example_html="<p><strong>100 kilometers</strong> converts to <strong>62.14 miles</strong>.<br><strong>100&deg;C</strong> converts to <strong>212&deg;F</strong>.</p>",
  explanation="<p>Length, weight, area, volume, and speed conversions are all simple multiplication once every unit is expressed relative to one base unit (like meters or kilograms). Temperature is the exception — it needs an offset, not just a multiplier, which is why 0&deg;C isn't 0&deg;F.</p>",
  mistakes=[
    "Treating temperature conversion as a simple multiplication instead of using the correct offset formula.",
    "Confusing US customary gallons/cups/ounces with UK imperial or metric equivalents of the same name.",
    "Mixing up mass (weight) units with volume units, especially for cooking measurements.",
  ],
  faqs=[
    ("Which gallon does this use — US or UK?", "This converter uses US customary units (US gallons, US cups, US fluid ounces) for volume."),
    ("Can I convert temperature the same way as other units?", "No — temperature scales have different zero points, so conversions use an offset formula rather than a simple multiplier."),
    ("How precise are the conversions?", "Results are shown to four decimal places using standard, widely accepted conversion factors."),
  ],
  related=[("Fuel Cost Calculator","fuel-cost-calculator.html"),("BMI Calculator","bmi-calculator.html"),("Average Calculator","average-calculator.html")],
  js_file="unit-converter.js",
)

# ============================================================ SCIENTIFIC
build_calculator_page(
  slug="scientific-calculator", name="Scientific Calculator", category="Math", category_url="math-calculators.html",
  title="Scientific Calculator – Free Online Calculator | CalcBeam",
  description="Free online scientific calculator with trigonometry, logarithms, powers, roots, and parentheses. Works entirely in your browser.",
  intro="A full scientific calculator with trigonometric functions, logarithms, powers, roots, and parentheses — all calculated safely in your browser.",
  tool_html='''
      <div class="field" style="background:var(--surface-2);border-radius:var(--radius-sm);padding:16px;text-align:right;">
        <div id="sciDisplay" style="font-family:var(--font-mono);font-size:1.4rem;min-height:1.6em;word-break:break-all;">0</div>
      </div>
      <div style="display:flex;justify-content:flex-end;margin:10px 0;">
        <button class="tool-tab" id="degModeToggle" aria-pressed="false" type="button">DEG</button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:8px;">
        <button class="btn btn-ghost sci-key" data-action="func" data-val="sin">sin</button>
        <button class="btn btn-ghost sci-key" data-action="func" data-val="cos">cos</button>
        <button class="btn btn-ghost sci-key" data-action="func" data-val="tan">tan</button>
        <button class="btn btn-ghost sci-key" data-action="func" data-val="log">log</button>
        <button class="btn btn-ghost sci-key" data-action="func" data-val="ln">ln</button>

        <button class="btn btn-ghost sci-key" data-val="(">(</button>
        <button class="btn btn-ghost sci-key" data-val=")">)</button>
        <button class="btn btn-ghost sci-key" data-val="pi">&pi;</button>
        <button class="btn btn-ghost sci-key" data-val="e">e</button>
        <button class="btn btn-ghost sci-key" data-action="back">&larr;</button>

        <button class="btn btn-ghost sci-key" data-val="7">7</button>
        <button class="btn btn-ghost sci-key" data-val="8">8</button>
        <button class="btn btn-ghost sci-key" data-val="9">9</button>
        <button class="btn btn-ghost sci-key" data-val="/">&divide;</button>
        <button class="btn btn-ghost sci-key" data-action="func" data-val="sqrt">&radic;</button>

        <button class="btn btn-ghost sci-key" data-val="4">4</button>
        <button class="btn btn-ghost sci-key" data-val="5">5</button>
        <button class="btn btn-ghost sci-key" data-val="6">6</button>
        <button class="btn btn-ghost sci-key" data-val="*">&times;</button>
        <button class="btn btn-ghost sci-key" data-val="^">x^y</button>

        <button class="btn btn-ghost sci-key" data-val="1">1</button>
        <button class="btn btn-ghost sci-key" data-val="2">2</button>
        <button class="btn btn-ghost sci-key" data-val="3">3</button>
        <button class="btn btn-ghost sci-key" data-val="-">&minus;</button>
        <button class="btn btn-ghost sci-key" data-val="%">%</button>

        <button class="btn btn-ghost sci-key" data-val="0">0</button>
        <button class="btn btn-ghost sci-key" data-val=".">.</button>
        <button class="btn btn-reset sci-key" data-action="clear">C</button>
        <button class="btn btn-ghost sci-key" data-val="+">+</button>
        <button class="btn btn-primary sci-key" data-action="equals">=</button>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button" style="display:none;">Reset</button></div>
  ''',
  how_to=[
    "Tap number and operator buttons to build an expression, just like a physical calculator.",
    "Use the DEG/RAD toggle to switch how trigonometric functions interpret angles.",
    "Press '=' to evaluate, or the back arrow to remove the last character.",
  ],
  formula_html="Standard order of operations (PEMDAS) applies: parentheses, exponents, multiplication/division, addition/subtraction, evaluated left to right within each level.",
  example_html="<p><code>sin(30) + sqrt(16)</code> in DEG mode evaluates to 0.5 + 4 = <strong>4.5</strong>.<br><code>2^10</code> evaluates to <strong>1024</strong>.</p>",
  explanation="<p>This calculator parses your expression using a dedicated interpreter, not JavaScript's <code>eval()</code> — that keeps it safe from malformed or malicious input, and lets it give clear error messages (like catching division by zero or an unmatched parenthesis) instead of crashing.</p>",
  mistakes=[
    "Forgetting to switch between DEG and RAD mode, which changes trig function results significantly.",
    "Leaving a parenthesis unclosed, which the calculator will flag as an error rather than guessing your intent.",
    "Entering log or ln of a non-positive number, which is mathematically undefined.",
  ],
  faqs=[
    ("Does this calculator use eval()?", "No. Expressions are parsed with a dedicated, safe interpreter that only recognizes numbers, operators, parentheses, and a fixed set of math functions — it never executes arbitrary code."),
    ("What's the difference between DEG and RAD mode?", "DEG mode treats numbers inside sin/cos/tan as degrees; RAD mode treats them as radians. Toggle the button above the keypad to switch."),
    ("Can I use keyboard input?", "This version is built for on-screen button input to keep behavior predictable and accessible across devices."),
  ],
  related=[("Percentage Calculator","percentage-calculator.html"),("Fraction Calculator","fraction-calculator.html"),("Average Calculator","average-calculator.html")],
  js_file="scientific-calculator.js",
)

# ============================================================ DATE CALCULATOR
build_calculator_page(
  slug="date-calculator", name="Date Calculator", category="Date & Time", category_url="date-time-calculators.html",
  title="Date Calculator – Add, Subtract & Find Days Between Dates | CalcBeam",
  description="Free date calculator. Add or subtract days from a date, or find the number of days, weeks, and business days between two dates.",
  intro="Add or subtract days from a date, or find the number of days, weeks, and business days between two dates.",
  tool_html='''
      <div class="tool-tabs" role="tablist" aria-label="Date calculation type">
        <button class="tool-tab" data-mode="addsub" aria-selected="true" role="tab">Add / Subtract Days</button>
        <button class="tool-tab" data-mode="diff" aria-selected="false" role="tab">Days Between Dates</button>
      </div>
      <div class="calc-panel" data-panel="addsub">
        <div class="field"><label for="addBaseDate">Start date</label><input type="date" id="addBaseDate"></div>
        <div class="field-row">
          <div class="field"><label for="addOp">Operation</label>
            <select id="addOp"><option value="add">Add days</option><option value="subtract">Subtract days</option></select>
          </div>
          <div class="field"><label for="addDays">Number of days</label><input type="number" id="addDays" min="0" placeholder="e.g. 45"></div>
        </div>
      </div>
      <div class="calc-panel" data-panel="diff" style="display:none;">
        <div class="field-row">
          <div class="field"><label for="diffStart">Start date</label><input type="date" id="diffStart"></div>
          <div class="field"><label for="diffEnd">End date</label><input type="date" id="diffEnd"></div>
        </div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Choose 'Add / Subtract Days' to shift a date forward or backward, or 'Days Between Dates' to compare two dates.",
    "Fill in the date fields — results update automatically.",
    "For date differences, both total days and business days (Monday–Friday) are shown.",
  ],
  formula_html="Add/subtract: result date = start date &plusmn; N days<br>Difference: total days = (end date &minus; start date) &divide; 1 day, in milliseconds",
  example_html="<p>Adding <strong>45 days</strong> to <strong>June 1, 2026</strong> lands on <strong>July 16, 2026</strong>.<br>The difference between <strong>Jan 1, 2026</strong> and <strong>Aug 9, 2026</strong> is <strong>220 days</strong>.</p>",
  explanation="<p>Date math looks simple but has real edge cases: months have different lengths, years have 365 or 366 days, and 'business days' means skipping weekends (and, depending on your needs, public holidays, which this calculator doesn't track). This tool handles calendar months and leap years automatically.</p>",
  mistakes=[
    "Assuming every month has 30 days when manually estimating a date shift.",
    "Forgetting that 'business days' calculations here exclude weekends but not public holidays.",
    "Mixing up which date is the start and which is the end when interpreting a negative day difference.",
  ],
  faqs=[
    ("Does the business day count include holidays?", "No — it excludes Saturdays and Sundays only. Public holidays vary by country and aren't factored in."),
    ("Can I calculate a date far in the past or future?", "Yes, any valid calendar date can be used in either mode."),
    ("How is 'days between' rounded?", "The result is rounded to the nearest whole day to avoid daylight-saving-time artifacts."),
  ],
  related=[("Age Calculator","age-calculator.html"),("Time Calculator","time-calculator.html")],
  js_file="date-calculator.js",
)


# ============================================================ SIMPLE INTEREST
build_calculator_page(
  slug="simple-interest-calculator", name="Simple Interest Calculator", category="Finance", category_url="finance-calculators.html",
  title="Simple Interest Calculator – Calculate Interest Earned | CalcBeam",
  description="Free simple interest calculator: find interest earned or owed and the final amount using principal, rate, and time.",
  intro="Calculate interest using the simple interest formula — enter your principal, annual rate, and time in years to see the interest earned and final amount.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="siPrincipal">Principal</label><div class="input-suffix"><input type="number" id="siPrincipal" value="1000"><span>$</span></div></div>
        <div class="field"><label for="siRate">Annual interest rate</label><div class="input-suffix"><input type="number" id="siRate" value="5"><span>%</span></div></div>
      </div>
      <div class="field"><label for="siTime">Time</label><div class="input-suffix"><input type="number" id="siTime" value="3"><span>years</span></div></div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter the principal amount (the sum you're investing or borrowing).",
    "Enter the annual interest rate as a percentage.",
    "Enter the time period in years — the interest earned and final amount update instantly.",
  ],
  formula_html="Simple Interest = Principal &times; Rate &times; Time<br>Final Amount = Principal + Interest<br><br>Unlike compound interest, simple interest is always calculated only on the original principal — it never earns interest on previously earned interest.",
  example_html="<p><strong>$1,000 at 5% for 3 years:</strong><br>Interest = 1000 &times; 0.05 &times; 3 = <strong>$150</strong><br>Final amount = 1000 + 150 = <strong>$1,150</strong></p>",
  explanation="<p>Simple interest grows in a straight line — the same dollar amount is added every year, since it's always calculated on the original principal. This is different from compound interest, where each year's interest also earns interest, producing accelerating growth over time.</p>",
  mistakes=[
    "Confusing simple interest with compound interest — simple interest never compounds.",
    "Entering the rate as a decimal (0.05) instead of a percentage (5) — this calculator expects a percentage.",
    "Forgetting to convert months into years when the time period isn't already in years.",
  ],
  faqs=[
    ("What's the difference between simple and compound interest?", "Simple interest is calculated only on the original principal every period. Compound interest is calculated on the principal plus any interest already earned, so it grows faster over time."),
    ("Where is simple interest actually used?", "Simple interest is common in short-term loans, certain bonds, and some auto loans. Most savings accounts and long-term investments use compound interest instead."),
  ],
  related=[("Compound Interest Calculator","compound-interest-calculator.html"),("Loan Calculator","loan-calculator.html"),("Investment Calculator","investment-calculator.html"),("ROI Calculator","roi-calculator.html")],
  js_file="simple-interest-calculator.js",
)

# ============================================================ INVESTMENT
build_calculator_page(
  slug="investment-calculator", name="Investment Calculator", category="Finance", category_url="finance-calculators.html",
  title="Investment Calculator – Project Your Investment Growth | CalcBeam",
  description="Free investment calculator: project the future value of an investment with an initial amount, monthly contributions, and an expected annual return.",
  intro="Estimate how an investment could grow over time, including regular monthly contributions and compounding returns.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="invInitial">Initial investment</label><div class="input-suffix"><input type="number" id="invInitial" value="5000"><span>$</span></div></div>
        <div class="field"><label for="invMonthly">Monthly contribution</label><div class="input-suffix"><input type="number" id="invMonthly" value="200"><span>$</span></div></div>
      </div>
      <div class="field-row">
        <div class="field"><label for="invReturn">Expected annual return</label><div class="input-suffix"><input type="number" id="invReturn" value="7"><span>%</span></div></div>
        <div class="field"><label for="invYears">Duration</label><div class="input-suffix"><input type="number" id="invYears" value="20"><span>years</span></div></div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter your initial investment amount, if any.",
    "Enter how much you plan to contribute each month.",
    "Enter your expected annual return and how many years you plan to invest — the projection updates instantly.",
  ],
  formula_html="Future Value = P(1+i)<sup>n</sup> + PMT &times; ((1+i)<sup>n</sup> &minus; 1) &divide; i<br>where P = initial investment, PMT = monthly contribution, i = monthly return rate, n = number of months.",
  example_html="<p><strong>$5,000 initial, $200/month, 7% annual return, 20 years:</strong><br>Total contributions: $53,000<br>Estimated final balance: roughly <strong>$110,000+</strong>, with the rest coming from investment growth.</p>",
  explanation="<p>This projection assumes a constant rate of return and monthly compounding, which real markets never deliver exactly — actual returns fluctuate year to year. The value of consistent contributions is that they benefit from compounding for longer, so money invested earlier tends to contribute disproportionately more to the final balance.</p>",
  mistakes=[
    "Assuming the projected return is guaranteed — real investments fluctuate and can lose value.",
    "Ignoring fees and taxes, which reduce real-world returns compared to this simplified projection.",
    "Underestimating how much consistent small contributions add up to over decades.",
  ],
  faqs=[
    ("Is the projected return guaranteed?", "No. This is an estimate based on a constant assumed rate of return. Actual investment returns vary and are never guaranteed — you could earn more or less, including losing money."),
    ("Does this account for inflation?", "No, this calculator shows nominal future value. To estimate purchasing power, you'd need to subtract expected inflation from your assumed return."),
  ],
  related=[("Compound Interest Calculator","compound-interest-calculator.html"),("ROI Calculator","roi-calculator.html"),("Simple Interest Calculator","simple-interest-calculator.html"),("Loan Calculator","loan-calculator.html")],
  js_file="investment-calculator.js",
)

# ============================================================ PROFIT MARGIN
build_calculator_page(
  slug="profit-margin-calculator", name="Profit Margin Calculator", category="Finance", category_url="finance-calculators.html",
  title="Profit Margin Calculator – Find Your Profit Margin | CalcBeam",
  description="Free profit margin calculator: calculate profit, profit margin percentage, and markup from revenue and cost.",
  intro="Enter your revenue and cost to instantly see your profit, profit margin percentage, and markup.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="pmRevenue">Revenue</label><div class="input-suffix"><input type="number" id="pmRevenue" value="500"><span>$</span></div></div>
        <div class="field"><label for="pmCost">Cost</label><div class="input-suffix"><input type="number" id="pmCost" value="350"><span>$</span></div></div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter your total revenue (what you sold the item for).",
    "Enter your total cost (what it cost you to make or acquire it).",
    "See your profit, profit margin percentage, and markup update instantly.",
  ],
  formula_html="Profit = Revenue &minus; Cost<br>Profit Margin % = (Profit &divide; Revenue) &times; 100<br>Markup % = (Profit &divide; Cost) &times; 100",
  example_html="<p><strong>Revenue $500, Cost $350:</strong><br>Profit = 500 &minus; 350 = <strong>$150</strong><br>Margin = (150 &divide; 500) &times; 100 = <strong>30%</strong><br>Markup = (150 &divide; 350) &times; 100 = <strong>42.9%</strong></p>",
  explanation="<p>Profit margin and markup answer different questions using the same profit figure. Margin shows profit as a percentage of the <em>selling price</em> — useful for understanding how much of each sale is profit. Markup shows profit as a percentage of the <em>cost</em> — useful for pricing decisions. The two numbers are always different (margin is always lower than markup) except at 0%.</p>",
  mistakes=[
    "Using margin and markup interchangeably — a 50% markup is a 33.3% margin, not 50%.",
    "Forgetting to include all costs (materials, labor, shipping) when calculating true cost.",
    "Confusing gross margin (this calculator) with net margin, which also subtracts operating expenses, taxes, and overhead.",
  ],
  faqs=[
    ("What's the difference between margin and markup?", "Margin is profit divided by revenue (selling price). Markup is profit divided by cost. They use the same profit number but different denominators, so they're never equal except when profit is zero."),
    ("What's a good profit margin?", "It varies enormously by industry — retail often runs 20–50%, while software and services can run much higher. There's no universal 'good' number."),
  ],
  related=[("Markup Calculator","markup-calculator.html"),("Discount Calculator","discount-calculator.html"),("ROI Calculator","roi-calculator.html"),("Percentage Calculator","percentage-calculator.html")],
  js_file="profit-margin-calculator.js",
)

# ============================================================ SALES TAX
build_calculator_page(
  slug="sales-tax-calculator", name="Sales Tax Calculator", category="Finance", category_url="finance-calculators.html",
  title="Sales Tax Calculator – Add or Remove Sales Tax | CalcBeam",
  description="Free sales tax calculator: add sales tax to a price or work backward from a tax-included total to find the pre-tax price.",
  intro="Add sales tax to a price, or work backward from a tax-included total to find the original pre-tax price — pick a mode below.",
  tool_html='''
      <div class="tool-tabs" role="tablist" aria-label="Sales tax calculation type">
        <button class="tool-tab" data-mode="add" aria-selected="true" role="tab">Add tax to a price</button>
        <button class="tool-tab" data-mode="remove" aria-selected="false" role="tab">Remove tax from a total</button>
      </div>
      <div class="calc-panel" data-panel="add">
        <div class="field-row">
          <div class="field"><label for="stPrice">Pre-tax price</label><div class="input-suffix"><input type="number" id="stPrice" value="80"><span>$</span></div></div>
          <div class="field"><label for="stRate">Tax rate</label><div class="input-suffix"><input type="number" id="stRate" value="8.25"><span>%</span></div></div>
        </div>
      </div>
      <div class="calc-panel" data-panel="remove" style="display:none;">
        <div class="field-row">
          <div class="field"><label for="stTotal">Total price (tax included)</label><div class="input-suffix"><input type="number" id="stTotal" placeholder="e.g. 108"><span>$</span></div></div>
          <div class="field"><label for="stRate2">Tax rate</label><div class="input-suffix"><input type="number" id="stRate2" placeholder="e.g. 8.25"><span>%</span></div></div>
        </div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Choose whether you want to add tax to a known pre-tax price, or remove tax from a total you already have.",
    "Enter the price (or total) and the tax rate for your area.",
    "Read the tax amount and final figure in the result panel.",
  ],
  formula_html="Adding tax: Total = Price &times; (1 + Rate &divide; 100)<br>Removing tax: Pre-tax price = Total &divide; (1 + Rate &divide; 100)",
  example_html="<p><strong>Adding tax:</strong> An $80 item with 8.25% tax costs 80 &times; 1.0825 = <strong>$86.60</strong>.<br><strong>Removing tax:</strong> A $108 total at 8.25% tax means the pre-tax price was 108 &divide; 1.0825 = <strong>$99.77</strong>.</p>",
  explanation="<p>Sales tax rates vary by country, state or province, and sometimes even by city or county — there's no single universal rate. This calculator applies whatever rate you enter, so check your local rate before relying on the result for anything official like invoicing or accounting.</p>",
  mistakes=[
    "Simply subtracting the tax percentage from a tax-included total instead of dividing — that only works for adding tax, not removing it.",
    "Using an outdated or wrong local tax rate — rates change and vary by jurisdiction.",
    "Forgetting that some items (groceries, medicine) are tax-exempt or taxed at a different rate in many places.",
  ],
  faqs=[
    ("How do I find my local sales tax rate?", "Check your state, provincial, or local government's official tax website — rates vary by location and this calculator doesn't look them up automatically."),
    ("Can I use this for VAT?", "Yes — the math for adding or removing a flat-rate VAT works the same way as sales tax, just enter your VAT percentage as the rate."),
  ],
  related=[("Discount Calculator","discount-calculator.html"),("Tip Calculator","tip-calculator.html"),("Markup Calculator","markup-calculator.html"),("Percentage Calculator","percentage-calculator.html")],
  js_file="sales-tax-calculator.js",
)

# ============================================================ MARKUP
build_calculator_page(
  slug="markup-calculator", name="Markup Calculator", category="Finance", category_url="finance-calculators.html",
  title="Markup Calculator – Turn Cost Into Selling Price | CalcBeam",
  description="Free markup calculator: calculate the selling price and profit margin from a cost and target markup percentage.",
  intro="Enter your cost and a target markup percentage to find the selling price and the profit margin it produces.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="mkCost">Cost</label><div class="input-suffix"><input type="number" id="mkCost" value="40"><span>$</span></div></div>
        <div class="field"><label for="mkPct">Markup</label><div class="input-suffix"><input type="number" id="mkPct" value="50"><span>%</span></div></div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter what the item costs you.",
    "Enter your target markup percentage.",
    "See the markup amount, final selling price, and the resulting profit margin update instantly.",
  ],
  formula_html="Markup Amount = Cost &times; (Markup % &divide; 100)<br>Selling Price = Cost + Markup Amount<br>Resulting Margin % = (Markup Amount &divide; Selling Price) &times; 100",
  example_html="<p><strong>$40 cost, 50% markup:</strong><br>Markup amount = 40 &times; 0.50 = <strong>$20</strong><br>Selling price = 40 + 20 = <strong>$60</strong><br>Resulting margin = (20 &divide; 60) &times; 100 = <strong>33.3%</strong></p>",
  explanation="<p>Markup is calculated on cost, which is why a 50% markup doesn't produce a 50% margin — margin is calculated on the higher selling price instead. If you're setting prices from a target markup, this calculator also shows you the margin that markup actually produces, since the two numbers are often confused.</p>",
  mistakes=[
    "Assuming a given markup percentage equals the same margin percentage — they're always different above 0%.",
    "Forgetting to include all costs (not just materials) before applying markup.",
    "Applying markup twice through a distribution chain without checking the compounding effect on final price.",
  ],
  faqs=[
    ("Is markup the same as profit margin?", "No. Markup is profit divided by cost; margin is profit divided by selling price. A 50% markup always produces a lower margin percentage (33.3% in this case)."),
    ("What markup should I use?", "It depends on your industry, competition, and costs beyond the item itself (overhead, labor, shipping). There's no single correct markup for every business."),
  ],
  related=[("Profit Margin Calculator","profit-margin-calculator.html"),("Discount Calculator","discount-calculator.html"),("Sales Tax Calculator","sales-tax-calculator.html"),("Percentage Calculator","percentage-calculator.html")],
  js_file="markup-calculator.js",
)

# ============================================================ ROI
build_calculator_page(
  slug="roi-calculator", name="ROI Calculator", category="Finance", category_url="finance-calculators.html",
  title="ROI Calculator – Calculate Return on Investment | CalcBeam",
  description="Free ROI calculator: calculate return on investment as a percentage, plus annualized ROI if you provide the holding period.",
  intro="Enter your initial investment and its final value to calculate ROI — add the holding period to also see an annualized return.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="roiInitial">Initial investment</label><div class="input-suffix"><input type="number" id="roiInitial" value="10000"><span>$</span></div></div>
        <div class="field"><label for="roiFinal">Final value</label><div class="input-suffix"><input type="number" id="roiFinal" value="14000"><span>$</span></div></div>
      </div>
      <div class="field"><label for="roiYears">Holding period (optional)</label><div class="input-suffix"><input type="number" id="roiYears" placeholder="e.g. 3"><span>years</span></div></div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter your initial investment amount.",
    "Enter the final value of the investment (what it's worth now, or what you sold it for).",
    "Optionally enter the holding period in years to also see an annualized return.",
  ],
  formula_html="ROI % = ((Final Value &minus; Initial Investment) &divide; Initial Investment) &times; 100<br>Annualized ROI % = ((Final Value &divide; Initial Investment)<sup>1/years</sup> &minus; 1) &times; 100",
  example_html="<p><strong>$10,000 grows to $14,000 over 3 years:</strong><br>ROI = ((14000&minus;10000)&divide;10000)&times;100 = <strong>40%</strong><br>Annualized ROI = ((14000&divide;10000)<sup>1/3</sup>&minus;1)&times;100 &asymp; <strong>11.9%/year</strong></p>",
  explanation="<p>Total ROI tells you the overall return over the whole holding period, but it doesn't account for how long that took — a 40% return over 3 years is very different from a 40% return over 10 years. Annualized ROI converts the total return into an equivalent yearly rate, making it possible to fairly compare investments held for different lengths of time.</p>",
  mistakes=[
    "Comparing total ROI across investments held for different time periods without annualizing.",
    "Forgetting to include fees, taxes, or dividends/distributions that affect the true final value.",
    "Treating a single ROI calculation as predictive of future returns.",
  ],
  faqs=[
    ("What counts as a 'good' ROI?", "It depends heavily on the asset class, risk level, and time period — there's no single benchmark that applies to every kind of investment."),
    ("Why is my annualized ROI lower than my total ROI?", "Annualized ROI spreads the total return evenly across each year using compounding math, so it will always be lower than the total ROI whenever the holding period is longer than one year."),
  ],
  related=[("Investment Calculator","investment-calculator.html"),("Compound Interest Calculator","compound-interest-calculator.html"),("Profit Margin Calculator","profit-margin-calculator.html"),("Simple Interest Calculator","simple-interest-calculator.html")],
  js_file="roi-calculator.js",
)

# ============================================================ AVERAGE
build_calculator_page(
  slug="average-calculator", name="Average Calculator", category="Math", category_url="math-calculators.html",
  title="Average Calculator – Mean, Median, Mode & Range | CalcBeam",
  description="Free average calculator: find the mean, median, mode, and range for any list of numbers.",
  intro="Enter a list of numbers separated by commas or spaces to instantly find the mean, median, mode, and range.",
  tool_html='''
      <div class="field"><label for="avgNumbers">Numbers</label><textarea id="avgNumbers" rows="4" placeholder="e.g. 4, 8, 15, 16, 23, 42" style="width:100%;padding:.7rem .9rem;border-radius:var(--radius-sm);border:1px solid var(--border);background:var(--surface);color:var(--ink);font-family:var(--font-mono);font-size:1rem;">4, 8, 15, 16, 23, 42</textarea></div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Type or paste your numbers into the box, separated by commas, spaces, or new lines.",
    "The mean, median, mode, and range calculate automatically as you type.",
    "Use Reset to clear the field and start over.",
  ],
  formula_html="Mean = Sum of values &divide; Count of values<br>Median = the middle value when sorted (average of the two middle values if the count is even)<br>Mode = the most frequently occurring value(s)<br>Range = Maximum value &minus; Minimum value",
  example_html="<p><strong>4, 8, 15, 16, 23, 42:</strong><br>Mean = 108 &divide; 6 = <strong>18</strong><br>Median = (15+16)&divide;2 = <strong>15.5</strong><br>Mode = None (no repeats)<br>Range = 42 &minus; 4 = <strong>38</strong></p>",
  explanation="<p>Mean, median, and mode are all 'averages' but answer different questions. The mean is sensitive to outliers — one very large or small number can pull it far from the rest of the data. The median is more robust to outliers since it only cares about the middle position. The mode is the only measure that works well for non-numeric categories, though for a list with no repeated values, there is no mode at all.</p>",
  mistakes=[
    "Using the mean when outliers are skewing it — the median often better represents 'typical' data in that case.",
    "Forgetting that the median calculation is different for an even versus odd count of numbers.",
    "Assuming every dataset has a mode — many don't, if no value repeats.",
  ],
  faqs=[
    ("When should I use median instead of mean?", "Use the median when your data has outliers or is skewed — for example, average home prices or incomes, where a few very high values would distort the mean."),
    ("Can a data set have more than one mode?", "Yes — if two or more values tie for the highest frequency, the data set is multimodal and all of those values are reported as the mode."),
  ],
  related=[("Percentage Calculator","percentage-calculator.html"),("Ratio Calculator","ratio-calculator.html"),("GPA Calculator","gpa-calculator.html"),("Grade Calculator","grade-calculator.html")],
  js_file="average-calculator.js",
)

# ============================================================ RATIO
build_calculator_page(
  slug="ratio-calculator", name="Ratio Calculator", category="Math", category_url="math-calculators.html",
  title="Ratio Calculator – Simplify Ratios & Solve Missing Values | CalcBeam",
  description="Free ratio calculator: simplify a ratio to its lowest terms, or solve for a missing value in an equivalent ratio.",
  intro="Simplify a ratio to its lowest terms, or solve for a missing value when two ratios are equivalent (A:B = C:D).",
  tool_html='''
      <div class="tool-tabs" role="tablist" aria-label="Ratio calculation type">
        <button class="tool-tab" data-mode="simplify" aria-selected="true" role="tab">Simplify a ratio</button>
        <button class="tool-tab" data-mode="missing" aria-selected="false" role="tab">Solve missing value</button>
      </div>
      <div class="calc-panel" data-panel="simplify">
        <div class="field-row">
          <div class="field"><label for="simA">A</label><input type="number" id="simA" value="12"></div>
          <div class="field"><label for="simB">B</label><input type="number" id="simB" value="18"></div>
        </div>
      </div>
      <div class="calc-panel" data-panel="missing" style="display:none;">
        <p style="color:var(--ink-soft);font-size:.9rem;margin:.2rem 0 .8rem;">Solving A : B = C : D</p>
        <div class="field-row">
          <div class="field"><label for="mvA">A</label><input type="number" id="mvA" placeholder="e.g. 4"></div>
          <div class="field"><label for="mvB">B</label><input type="number" id="mvB" placeholder="e.g. 6"></div>
        </div>
        <div class="field-row">
          <div class="field"><label for="mvC">C</label><input type="number" id="mvC" placeholder="e.g. 10"></div>
          <div class="field"><label for="mvD">D (solved)</label><input type="number" id="mvD" disabled placeholder="?"></div>
        </div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "To simplify a ratio, enter two whole numbers — the calculator reduces them to their lowest terms.",
    "To solve a missing value, enter A, B, and C in the equivalent ratio A:B = C:D — the calculator solves for D.",
    "Results update instantly as you type.",
  ],
  formula_html="Simplifying: divide both numbers by their greatest common divisor (GCD).<br>Missing value: if A:B = C:D, then D = (B &times; C) &divide; A.",
  example_html="<p><strong>Simplify 12:18</strong> &rarr; GCD is 6 &rarr; <strong>2 : 3</strong></p><p><strong>Solve 4:6 = 10:D</strong> &rarr; D = (6&times;10)&divide;4 = <strong>15</strong></p>",
  explanation="<p>A ratio compares two quantities. Simplifying finds the smallest whole-number version of that comparison, the same way a fraction gets reduced. Solving a missing value uses the fact that equivalent ratios are really the same fraction scaled up or down — cross-multiplying finds the scale factor needed.</p>",
  mistakes=[
    "Simplifying only one side of a ratio instead of dividing both numbers by the same factor.",
    "Mixing up the order of a ratio — 2:3 and 3:2 describe different comparisons.",
    "Forgetting that ratios describe relative size, not absolute totals — 2:3 could mean 2 and 3 of anything, or 200 and 300.",
  ],
  faqs=[
    ("How do I simplify a ratio?", "Find the greatest common divisor (GCD) of both numbers, then divide each number by it. For example, 12:18 has a GCD of 6, simplifying to 2:3."),
    ("What does it mean for two ratios to be equivalent?", "Two ratios are equivalent if one can be obtained from the other by multiplying or dividing both numbers by the same value — like 2:3 and 4:6."),
  ],
  related=[("Fraction Calculator","fraction-calculator.html"),("Percentage Calculator","percentage-calculator.html"),("Average Calculator","average-calculator.html"),("Unit Converter","unit-converter.html")],
  js_file="ratio-calculator.js",
)

# ============================================================ FRACTION
build_calculator_page(
  slug="fraction-calculator", name="Fraction Calculator", category="Math", category_url="math-calculators.html",
  title="Fraction Calculator – Add, Subtract, Multiply & Divide | CalcBeam",
  description="Free fraction calculator: add, subtract, multiply, or divide two fractions and get a simplified result plus decimal equivalent.",
  intro="Add, subtract, multiply, or divide two fractions — the result is automatically simplified and shown as a decimal too.",
  tool_html='''
      <div class="field-row" style="align-items:end;">
        <div class="field">
          <label>First fraction</label>
          <div style="display:flex;gap:6px;align-items:center;">
            <input type="number" id="fracN1" value="1" style="width:70px;text-align:center;">
            <span style="font-size:1.3rem;color:var(--ink-soft);">/</span>
            <input type="number" id="fracN1d" style="display:none;">
            <input type="number" id="fracD1" value="2" style="width:70px;text-align:center;">
          </div>
        </div>
        <div class="field" style="max-width:90px;">
          <label for="fracOp">Operation</label>
          <select id="fracOp">
            <option value="add">+</option>
            <option value="sub">&minus;</option>
            <option value="mul">&times;</option>
            <option value="div">&divide;</option>
          </select>
        </div>
        <div class="field">
          <label>Second fraction</label>
          <div style="display:flex;gap:6px;align-items:center;">
            <input type="number" id="fracN2" value="1" style="width:70px;text-align:center;">
            <span style="font-size:1.3rem;color:var(--ink-soft);">/</span>
            <input type="number" id="fracD2" value="3" style="width:70px;text-align:center;">
          </div>
        </div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter the numerator and denominator of the first fraction.",
    "Choose an operation: add, subtract, multiply, or divide.",
    "Enter the numerator and denominator of the second fraction — the simplified result appears instantly.",
  ],
  formula_html="Add/Subtract: a/b &plusmn; c/d = (ad &plusmn; cb) &divide; bd<br>Multiply: a/b &times; c/d = ac &divide; bd<br>Divide: a/b &divide; c/d = ad &divide; bc<br>The result is then simplified by dividing by the greatest common divisor.",
  example_html="<p><strong>1/2 + 1/3:</strong><br>(1&times;3 + 1&times;2) &divide; (2&times;3) = 5/6</p><p><strong>2/3 &times; 3/4:</strong><br>(2&times;3) &divide; (3&times;4) = 6/12 = <strong>1/2</strong> (simplified)</p>",
  explanation="<p>Adding or subtracting fractions requires a common denominator, which is why the formula multiplies both fractions' denominators together first. Multiplication and division don't need a common denominator — they work directly on the numerators and denominators. Every result is automatically reduced to its simplest form using the greatest common divisor.</p>",
  mistakes=[
    "Adding numerators and denominators straight across (1/2 + 1/3 is not 2/5) — a common denominator is required first.",
    "Forgetting to simplify the final answer to lowest terms.",
    "Dividing by a fraction without flipping (inverting) the second fraction first.",
  ],
  faqs=[
    ("Why do I need a common denominator to add fractions?", "Fractions represent parts of a whole, and you can only add or subtract them directly when those parts are the same size — which is what a common denominator ensures."),
    ("How is dividing fractions different from multiplying?", "Dividing by a fraction is the same as multiplying by its reciprocal (flipped fraction) — that's why the divide formula swaps the second fraction's numerator and denominator."),
  ],
  related=[("Ratio Calculator","ratio-calculator.html"),("Percentage Calculator","percentage-calculator.html"),("Average Calculator","average-calculator.html"),("Scientific Calculator","scientific-calculator.html")],
  js_file="fraction-calculator.js",
)

# ============================================================ CALORIE
build_calculator_page(
  slug="calorie-calculator", name="Calorie Calculator", category="Health", category_url="health-calculators.html",
  title="Calorie Calculator – Estimate Daily Calorie Needs | CalcBeam",
  description="Free calorie calculator: estimate your daily calorie needs using age, sex, height, weight, and activity level (Mifflin-St Jeor equation).",
  intro="Estimate how many calories you need per day to maintain your current weight, based on your age, sex, height, weight, and activity level.",
  tool_html='''
      <div class="tool-tabs" role="tablist" aria-label="Unit system">
        <button class="tool-tab" data-mode="metric" aria-selected="true" role="tab">Metric</button>
        <button class="tool-tab" data-mode="imperial" aria-selected="false" role="tab">Imperial</button>
      </div>
      <div class="calc-panel" data-panel="metric">
        <div class="field-row">
          <div class="field"><label for="calWeightKg">Weight</label><div class="input-suffix"><input type="number" id="calWeightKg" value="70"><span>kg</span></div></div>
          <div class="field"><label for="calHeightCm">Height</label><div class="input-suffix"><input type="number" id="calHeightCm" value="175"><span>cm</span></div></div>
        </div>
        <div class="field-row">
          <div class="field"><label for="calAgeM">Age</label><input type="number" id="calAgeM" value="30"></div>
          <div class="field"><label for="calSexM">Sex</label><select id="calSexM"><option value="male">Male</option><option value="female">Female</option></select></div>
        </div>
        <div class="field"><label for="calActivityM">Activity level</label>
          <select id="calActivityM">
            <option value="1.2">Sedentary (little or no exercise)</option>
            <option value="1.375">Light (exercise 1&ndash;3 days/week)</option>
            <option value="1.55" selected>Moderate (exercise 3&ndash;5 days/week)</option>
            <option value="1.725">Active (exercise 6&ndash;7 days/week)</option>
            <option value="1.9">Very active (hard exercise, physical job)</option>
          </select>
        </div>
      </div>
      <div class="calc-panel" data-panel="imperial" style="display:none;">
        <div class="field-row">
          <div class="field"><label for="calWeightLb">Weight</label><div class="input-suffix"><input type="number" id="calWeightLb" placeholder="e.g. 154"><span>lb</span></div></div>
          <div class="field"><label for="calHeightFt">Height (ft)</label><input type="number" id="calHeightFt" placeholder="e.g. 5"></div>
          <div class="field"><label for="calHeightIn">Height (in)</label><input type="number" id="calHeightIn" placeholder="e.g. 9"></div>
        </div>
        <div class="field-row">
          <div class="field"><label for="calAgeI">Age</label><input type="number" id="calAgeI" placeholder="e.g. 30"></div>
          <div class="field"><label for="calSexI">Sex</label><select id="calSexI"><option value="male">Male</option><option value="female">Female</option></select></div>
        </div>
        <div class="field"><label for="calActivityI">Activity level</label>
          <select id="calActivityI">
            <option value="1.2">Sedentary (little or no exercise)</option>
            <option value="1.375">Light (exercise 1&ndash;3 days/week)</option>
            <option value="1.55" selected>Moderate (exercise 3&ndash;5 days/week)</option>
            <option value="1.725">Active (exercise 6&ndash;7 days/week)</option>
            <option value="1.9">Very active (hard exercise, physical job)</option>
          </select>
        </div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Choose Metric or Imperial units.",
    "Enter your weight, height, age, and sex.",
    "Select your typical activity level to see your estimated daily maintenance calories.",
  ],
  formula_html="Mifflin-St Jeor BMR (men): 10 &times; weight(kg) + 6.25 &times; height(cm) &minus; 5 &times; age + 5<br>Mifflin-St Jeor BMR (women): 10 &times; weight(kg) + 6.25 &times; height(cm) &minus; 5 &times; age &minus; 161<br>Daily calories = BMR &times; activity multiplier",
  example_html="<p><strong>Male, 70kg, 175cm, age 30, moderately active:</strong><br>BMR = 10(70) + 6.25(175) &minus; 5(30) + 5 = <strong>1,674 cal/day</strong><br>Daily calories = 1,674 &times; 1.55 &asymp; <strong>2,595 cal/day</strong></p>",
  explanation="<p>This calculator estimates maintenance calories — the amount needed to keep your current weight stable. Eating consistently above this estimate tends to lead to weight gain over time, and eating below it tends to lead to weight loss, though individual metabolism varies and this is an estimate, not a precise measurement.</p>",
  mistakes=[
    "Overestimating activity level — many people rate themselves more active than their actual weekly exercise reflects.",
    "Treating the result as an exact number rather than a starting estimate to adjust based on real results over a few weeks.",
    "Using this for children, pregnant/breastfeeding people, or anyone with a medical condition — the Mifflin-St Jeor equation is designed for generally healthy adults.",
  ],
  faqs=[
    ("Is this calculator medically accurate?", "It provides a well-established estimate (the Mifflin-St Jeor equation) but individual metabolism varies. This calculator provides an estimate and is not medical advice."),
    ("Should I eat exactly this many calories?", "This is your estimated maintenance level. To lose weight you'd typically eat somewhat below it, and to gain weight, somewhat above it — consult a healthcare provider for personalized guidance."),
  ],
  related=[("BMI Calculator","bmi-calculator.html"),("Average Calculator","average-calculator.html"),("Percentage Calculator","percentage-calculator.html")],
  js_file="calorie-calculator.js",
)

# ============================================================ GRADE
build_calculator_page(
  slug="grade-calculator", name="Grade Calculator", category="Education", category_url="education-calculators.html",
  title="Grade Calculator – Weighted Grade & Final Exam Score | CalcBeam",
  description="Free grade calculator: find your current weighted grade from assignment scores, or the score you need on your final exam to hit a target grade.",
  intro="Calculate your current weighted grade from assignment scores, or find out what score you need on your final exam to reach a target grade.",
  tool_html='''
      <div class="tool-tabs" role="tablist" aria-label="Grade calculation type">
        <button class="tool-tab" data-mode="weighted" aria-selected="true" role="tab">Current weighted grade</button>
        <button class="tool-tab" data-mode="final" aria-selected="false" role="tab">Score needed on final</button>
      </div>
      <div class="calc-panel" data-panel="weighted">
        <div id="gradeRows"></div>
        <button type="button" class="btn btn-add" id="addGradeRow">+ Add assignment</button>
      </div>
      <div class="calc-panel" data-panel="final" style="display:none;">
        <div class="field-row">
          <div class="field"><label for="gfCurrent">Current grade</label><div class="input-suffix"><input type="number" id="gfCurrent" value="85"><span>%</span></div></div>
          <div class="field"><label for="gfWeight">Final exam weight</label><div class="input-suffix"><input type="number" id="gfWeight" value="25"><span>%</span></div></div>
        </div>
        <div class="field"><label for="gfTarget">Target overall grade</label><div class="input-suffix"><input type="number" id="gfTarget" value="90"><span>%</span></div></div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "For a current grade: add each assignment's score and weight — rows can be added or removed freely.",
    "For a final exam score: enter your current grade, the final's weight in the overall course, and your target grade.",
    "Results update instantly as you type.",
  ],
  formula_html="Weighted grade = &Sigma;(score &times; weight) &divide; &Sigma;(weight)<br>Score needed on final = (Target &minus; Current &times; (1 &minus; Final Weight)) &divide; Final Weight",
  example_html="<p><strong>Current grade 85%, final worth 25%, target 90%:</strong><br>Needed = (90 &minus; 85&times;0.75) &divide; 0.25 = (90 &minus; 63.75) &divide; 0.25 = <strong>105%</strong> &mdash; not achievable, meaning a 90% overall isn't possible from here without extra credit.</p>",
  explanation="<p>A weighted grade treats different assignments as contributing different amounts to your final grade — a 30%-weight midterm affects your grade three times as much as a 10%-weight quiz. The 'score needed on final' calculation works backward from your target, subtracting out the part of your grade that's already locked in from non-final work.</p>",
  mistakes=[
    "Entering weights that don't add up to 100% without realizing it — the calculator still computes correctly relative to whatever weights you enter, but the total should usually be checked.",
    "Forgetting that a 'score needed' above 100% means the target isn't reachable through the final exam alone.",
    "Mixing up which grade is 'current' (before the final) versus 'target' (after the final).",
  ],
  faqs=[
    ("What if I need a score above 100% on my final?", "That means your target grade isn't reachable through the final exam alone, given your current grade and the final's weight — you'd need extra credit or a grade change elsewhere."),
    ("Do my assignment weights need to add up to 100%?", "In most real courses, yes — but this calculator will still compute a correct weighted average even if they don't, treating whatever you enter as the relative weighting."),
  ],
  related=[("GPA Calculator","gpa-calculator.html"),("Average Calculator","average-calculator.html"),("Percentage Calculator","percentage-calculator.html")],
  js_file="grade-calculator.js",
)

# ============================================================ TIME
build_calculator_page(
  slug="time-calculator", name="Time Calculator", category="Date & Time", category_url="date-time-calculators.html",
  title="Time Calculator – Add, Subtract & Find Duration | CalcBeam",
  description="Free time calculator: add or subtract hours, minutes and seconds, or find the duration between two clock times.",
  intro="Add or subtract time values, or find the duration between two clock times — pick a mode below.",
  tool_html='''
      <div class="tool-tabs" role="tablist" aria-label="Time calculation type">
        <button class="tool-tab" data-mode="addsub" aria-selected="true" role="tab">Add / Subtract Time</button>
        <button class="tool-tab" data-mode="duration" aria-selected="false" role="tab">Duration Between Times</button>
      </div>
      <div class="calc-panel" data-panel="addsub">
        <div class="field-row">
          <div class="field"><label for="t1h">Hours</label><input type="number" id="t1h" value="2"></div>
          <div class="field"><label for="t1m">Minutes</label><input type="number" id="t1m" value="30"></div>
          <div class="field"><label for="t1s">Seconds</label><input type="number" id="t1s" value="0"></div>
        </div>
        <div class="field" style="max-width:120px;"><label for="tOp">Operation</label><select id="tOp"><option value="add">Add</option><option value="sub">Subtract</option></select></div>
        <div class="field-row">
          <div class="field"><label for="t2h">Hours</label><input type="number" id="t2h" value="1"></div>
          <div class="field"><label for="t2m">Minutes</label><input type="number" id="t2m" value="45"></div>
          <div class="field"><label for="t2s">Seconds</label><input type="number" id="t2s" value="0"></div>
        </div>
      </div>
      <div class="calc-panel" data-panel="duration" style="display:none;">
        <div class="field-row">
          <div class="field"><label for="tStart">Start time</label><input type="time" id="tStart"></div>
          <div class="field"><label for="tEnd">End time</label><input type="time" id="tEnd"></div>
        </div>
      </div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "To add or subtract time, enter hours/minutes/seconds for both values and choose an operation.",
    "To find a duration, enter a start time and an end time — if the end time is earlier, it's assumed to be the next day.",
    "Results update instantly.",
  ],
  formula_html="Add/Subtract: convert both times to total seconds, then add or subtract, converting back to h/m/s.<br>Duration: (end time &minus; start time) in minutes, adding 24 hours if the result is negative (crosses midnight).",
  example_html="<p><strong>2h 30m + 1h 45m</strong> = <strong>4h 15m</strong></p><p><strong>9:00 AM to 5:30 PM</strong> = <strong>8h 30m</strong> duration</p>",
  explanation="<p>Time math doesn't work in base 10 — 60 seconds make a minute and 60 minutes make an hour, so simple addition needs to carry over correctly (like 45 + 30 minutes becomes 1 hour 15 minutes, not 75 minutes). Duration calculations also need to handle times that cross midnight, where the end time is numerically smaller than the start time.</p>",
  mistakes=[
    "Adding minutes past 60 without carrying over into hours (e.g., treating 90 minutes as '1:90' instead of '2:30').",
    "Forgetting that a duration crossing midnight needs 24 hours added before subtracting.",
    "Mixing 12-hour and 24-hour time formats inconsistently.",
  ],
  faqs=[
    ("How does the duration calculator handle times that cross midnight?", "If the end time is earlier than the start time, the calculator assumes the end time is on the next day and adds 24 hours before calculating the duration."),
    ("Can I calculate duration across multiple days?", "This calculator handles durations within a single day-crossing (up to 24 hours). For multi-day spans, use the Date Calculator instead."),
  ],
  related=[("Date Calculator","date-calculator.html"),("Age Calculator","age-calculator.html")],
  js_file="time-calculator.js",
)

# ============================================================ FUEL COST
build_calculator_page(
  slug="fuel-cost-calculator", name="Fuel Cost Calculator", category="Conversion", category_url="conversion-calculators.html",
  title="Fuel Cost Calculator – Estimate Trip Fuel Cost | CalcBeam",
  description="Free fuel cost calculator: estimate how much fuel a trip will use and what it will cost based on distance, fuel efficiency, and fuel price.",
  intro="Estimate the fuel needed and total cost for a trip based on distance, your vehicle's fuel efficiency, and the price of fuel.",
  tool_html='''
      <div class="field-row">
        <div class="field"><label for="fcDistance">Trip distance</label><div class="input-suffix"><input type="number" id="fcDistance" value="300"><span>mi</span></div></div>
        <div class="field"><label for="fcEfficiency">Fuel efficiency</label><div class="input-suffix"><input type="number" id="fcEfficiency" value="28"><span>mpg</span></div></div>
      </div>
      <div class="field"><label for="fcPrice">Fuel price</label><div class="input-suffix"><input type="number" id="fcPrice" value="3.50"><span>$/gal</span></div></div>
      <div class="err-msg" id="calcError"></div>
      <div class="tool-actions"><button class="btn btn-reset" id="calcReset" type="button">Reset</button></div>
  ''',
  how_to=[
    "Enter your trip distance in miles.",
    "Enter your vehicle's fuel efficiency in miles per gallon.",
    "Enter the current price per gallon — the fuel needed and total cost update instantly.",
  ],
  formula_html="Fuel needed = Distance &divide; Fuel efficiency (mpg)<br>Fuel cost = Fuel needed &times; Price per gallon",
  example_html="<p><strong>300 mile trip, 28 mpg, $3.50/gallon:</strong><br>Fuel needed = 300 &divide; 28 = <strong>10.71 gallons</strong><br>Cost = 10.71 &times; 3.50 = <strong>$37.50</strong></p>",
  explanation="<p>This is a straightforward proportional calculation, but real-world fuel use varies with driving style, terrain, traffic, and vehicle load — the EPA-rated mpg figure is a useful estimate, not a guarantee, and highway versus city driving can shift actual mileage noticeably.</p>",
  mistakes=[
    "Using a vehicle's best-case (highway) mpg rating for a trip that's mostly city driving, underestimating cost.",
    "Forgetting that fuel prices vary by region and change over time — check a current local price for accuracy.",
    "Not accounting for round-trip distance when planning a return journey.",
  ],
  faqs=[
    ("Does this account for traffic or terrain?", "No — it uses a flat fuel-efficiency figure you provide. Actual fuel use can be higher in heavy traffic, hilly terrain, or with a loaded vehicle."),
    ("How do I convert this for liters and kilometers?", "Enter your distance in kilometers and efficiency in km per liter, and the same division/multiplication formula still applies — just adjust the labels mentally, or use the Unit Converter first."),
  ],
  related=[("Unit Converter","unit-converter.html"),("ROI Calculator","roi-calculator.html"),("Average Calculator","average-calculator.html")],
  js_file="fuel-cost-calculator.js",
)

print("All calculator pages generated.")
