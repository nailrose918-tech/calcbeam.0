#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from generate import *

ARTICLES = [
  dict(slug="how-to-calculate-percentage", title="How to Calculate a Percentage (With Examples)",
    desc="A clear, step-by-step guide to calculating percentages, percentage change, and percentage of a number — with worked examples.",
    read="4 min read", calc=("Percentage Calculator","percentage-calculator.html"),
    body='''
<p>Percentages show up everywhere — sales tax, tips, grades, discounts, interest rates — but the underlying math is always the same simple idea: a percentage is just a fraction out of 100.</p>
<h2>Finding a percentage of a number</h2>
<p>To find X% of a number, convert the percentage to a decimal (divide by 100) and multiply.</p>
<div class="formula-box">Result = (percentage &divide; 100) &times; number</div>
<div class="example-box"><strong>Example:</strong> 20% of 150 = (20 &divide; 100) &times; 150 = 0.2 &times; 150 = <strong>30</strong>.</div>
<h2>Finding what percent one number is of another</h2>
<p>Divide the part by the whole, then multiply by 100.</p>
<div class="formula-box">Percentage = (part &divide; whole) &times; 100</div>
<div class="example-box"><strong>Example:</strong> 30 is what percent of 150? (30 &divide; 150) &times; 100 = <strong>20%</strong>.</div>
<h2>Percentage increase and decrease</h2>
<p>This is where most mistakes happen. Percentage change is always calculated relative to the <em>original</em> value, not the new one.</p>
<div class="formula-box">% change = ((new &minus; old) &divide; |old|) &times; 100</div>
<div class="example-box"><strong>Example:</strong> A price rises from $40 to $52. Change = ((52&minus;40)&divide;40)&times;100 = <strong>30% increase</strong>.</div>
<h2>A common trap: percentage points vs. percent</h2>
<p>If an interest rate moves from 5% to 7%, that's a 2 <em>percentage point</em> increase, but a 40% <em>relative</em> increase (2 &divide; 5 &times; 100). Financial and political reporting often mixes these up, so it's worth reading carefully which one is meant.</p>
<h2>Try it yourself</h2>
<p>Use the CalcBeam Percentage Calculator to run any of these calculations instantly, including percentage of a number, reverse percentage, and percentage change.</p>
''',
    faqs=[
      ("What is 15% of 200?", "15% of 200 is 30, calculated as (15 ÷ 100) × 200."),
      ("How do I reverse a percentage increase?", "Divide the new value by (1 + percentage/100). For a 20% increase to 120, divide 120 by 1.2 to get the original value of 100."),
    ]),
  dict(slug="simple-interest-vs-compound-interest", title="Simple Interest vs. Compound Interest: What's the Difference?",
    desc="Understand how simple interest and compound interest differ, with formulas and side-by-side examples for savings and loans.",
    read="5 min read", calc=("Compound Interest Calculator","compound-interest-calculator.html"),
    body='''
<p>Both simple and compound interest describe how money grows (or how debt grows) over time, but they compound very differently as the years add up.</p>
<h2>Simple interest</h2>
<p>Simple interest is calculated only on the original principal — it never earns interest on previously earned interest.</p>
<div class="formula-box">Interest = Principal &times; Rate &times; Time</div>
<div class="example-box"><strong>Example:</strong> $1,000 at 5% simple interest for 3 years earns 1000 &times; 0.05 &times; 3 = <strong>$150</strong>, every time, regardless of when it's paid.</div>
<h2>Compound interest</h2>
<p>Compound interest is calculated on the principal <em>plus</em> any interest already added, so growth accelerates over time.</p>
<div class="formula-box">A = P(1 + r/n)&#8319;&#7524;</div>
<div class="example-box"><strong>Example:</strong> $1,000 at 5% compounded annually for 3 years grows to 1000 &times; 1.05&sup3; = <strong>$1,157.63</strong> — about $7.63 more than simple interest over the same period.</div>
<h2>Why the gap grows over time</h2>
<p>Over short periods, simple and compound interest look similar. Over decades, the difference becomes dramatic, because compound interest is earning interest on interest, not just on the original amount.</p>
<h2>Which one applies to you?</h2>
<p>Most everyday savings accounts, credit cards, and mortgages use compound interest. Simple interest is more common in short-term loans, some bonds, and certain promotional financing offers. Always check your specific account or loan terms.</p>
<h2>Try it yourself</h2>
<p>Use the Compound Interest Calculator to project long-term growth, or the Simple Interest Calculator for flat-rate interest calculations.</p>
''',
    faqs=[
      ("Which grows money faster, simple or compound interest?", "At the same stated rate, compound interest always grows a balance faster than simple interest once more than one compounding period has passed."),
      ("Does compounding frequency matter a lot?", "It matters, but usually less than the interest rate itself or the length of time invested. Monthly vs. annual compounding at the same rate produces a modest, not dramatic, difference."),
    ]),
  dict(slug="how-to-calculate-gpa", title="How to Calculate Your GPA (Step by Step)",
    desc="Learn how GPA is calculated from letter grades and credit hours, with a full worked example on the standard 4.0 scale.",
    read="4 min read", calc=("GPA Calculator","gpa-calculator.html"),
    body='''
<p>Your GPA (grade point average) summarizes your grades into a single number, weighted by how many credit hours each course is worth.</p>
<h2>Step 1: Convert each letter grade to grade points</h2>
<p>On the standard US 4.0 scale: A = 4.0, A- = 3.7, B+ = 3.3, B = 3.0, B- = 2.7, C+ = 2.3, C = 2.0, C- = 1.7, D+ = 1.3, D = 1.0, F = 0.0.</p>
<h2>Step 2: Multiply grade points by credit hours</h2>
<p>Each course contributes "quality points" equal to its grade points times its credit hours.</p>
<h2>Step 3: Divide total quality points by total credit hours</h2>
<div class="formula-box">GPA = (&sum; grade points &times; credit hours) &divide; (&sum; credit hours)</div>
<div class="example-box">
<strong>Example:</strong> Biology (A, 4 credits), English (B+, 3 credits), Art (A-, 2 credits)<br>
(4.0&times;4) + (3.3&times;3) + (3.7&times;2) = 16 + 9.9 + 7.4 = 33.3<br>
33.3 &divide; 9 credits = <strong>3.70 GPA</strong>
</div>
<h2>Semester GPA vs. cumulative GPA</h2>
<p>Semester GPA uses only the current term's courses. Cumulative GPA uses every course you've taken toward your degree. The calculation method is identical — only which courses you include changes.</p>
<h2>Try it yourself</h2>
<p>The GPA Calculator lets you add or remove courses and instantly see your weighted GPA.</p>
''',
    faqs=[
      ("Does a Pass/Fail course affect GPA?", "Typically no — most schools exclude Pass/Fail courses from GPA calculations, though credit hours may still count toward your degree. Check your school's policy."),
      ("What if my school uses a different grading scale?", "The weighting method (grade points × credit hours, divided by total credit hours) stays the same — you'd just substitute your school's specific grade point values."),
    ]),
  dict(slug="how-sales-tax-works", title="How Sales Tax Works (And How to Calculate It)",
    desc="A simple guide to calculating sales tax, finding a pre-tax price, and understanding how tax rates vary by location.",
    read="3 min read", calc=("Discount Calculator","discount-calculator.html"),
    body='''
<p>Sales tax is a percentage added to the price of goods or services at the point of sale, set by state, county, or city governments depending on where you are.</p>
<h2>Adding sales tax to a price</h2>
<div class="formula-box">Tax amount = Price &times; (tax rate &divide; 100)<br>Final price = Price + Tax amount</div>
<div class="example-box"><strong>Example:</strong> A $50 item with 8% sales tax: tax = $4.00, final price = <strong>$54.00</strong>.</div>
<h2>Finding the pre-tax price from a total</h2>
<p>If you only know the final price and the tax rate, divide by (1 + tax rate) to back out the original price.</p>
<div class="formula-box">Pre-tax price = Final price &divide; (1 + tax rate &divide; 100)</div>
<div class="example-box"><strong>Example:</strong> A $54 total at 8% tax: 54 &divide; 1.08 = <strong>$50.00</strong> pre-tax.</div>
<h2>Why rates vary so much</h2>
<p>Sales tax rates are set locally and can combine state, county, and city rates, which is why the same item can cost a different amount depending on where you buy it.</p>
<h2>Try it yourself</h2>
<p>A dedicated Sales Tax Calculator is coming soon to CalcBeam. In the meantime, the Discount Calculator handles the same percentage-of-price math for pricing scenarios.</p>
''',
    faqs=[
      ("Is sales tax the same everywhere?", "No — rates are set by state, county, and city governments and vary widely, even within the same country."),
      ("Is sales tax calculated before or after a discount?", "Sales tax is typically calculated on the discounted price, after any coupon or sale price is applied — but confirm with the specific retailer if it matters for your records."),
    ]),
]

def build_article(a):
    depth = 1
    faqs_block = faq_html(a["faqs"])
    crumb, crumb_ld = breadcrumb_html(depth, [("Home","index.html"),("Blog","blog/index.html"),(a["title"], None)])
    toc_items = "".join(f"<li>{h}</li>" for h in ["Introduction","Formula & examples","Common questions"])
    body = f'''{crumb}
<div class="container">
  <article class="prose">
    <h1>{a["title"]}</h1>
    <p class="article-meta">{a["read"]} &middot; CalcBeam Editorial</p>
    <div class="toc"><h2>In this article</h2><ol>{toc_items}</ol></div>
    {a["body"]}
    <h2>Frequently asked questions</h2>
    {faqs_block}
    <div class="callout callout-info">Related tool: <a href="../{a['calc'][1]}">{a['calc'][0]} &rarr;</a></div>
  </article>
  <div class="ad-slot in-article">Advertisement</div>
</div>
'''
    schema = {
        "@context": "https://schema.org", "@type": "Article",
        "headline": a["title"], "description": a["desc"],
        "author": {"@type": "Organization", "name": "CalcBeam"},
        "publisher": {"@type": "Organization", "name": "CalcBeam"},
    }
    html = page_shell(depth=depth, title=f'{a["title"]} | CalcBeam Blog', description=a["desc"],
        canonical=f"blog/{a['slug']}.html", body=body, schemas=[crumb_ld, schema, faq_schema(a["faqs"])])
    write(f"blog/{a['slug']}.html", html)

def build_blog_index():
    depth = 1
    crumb, ld = breadcrumb_html(depth, [("Home","index.html"),("Blog", None)])
    cards = "\n".join(f'''<a class="card calc-card" href="{a['slug']}.html">
      <span class="cat-tag">{a['read']}</span>
      <h3>{a['title']}</h3>
      <p>{a['desc']}</p>
    </a>''' for a in ARTICLES)
    body = f'''{crumb}
<div class="container">
  <h1>CalcBeam Blog</h1>
  <p class="lede" style="color:var(--ink-soft);max-width:65ch;">Plain-language guides to the math behind CalcBeam's calculators — percentages, interest, GPA, tax, and more.</p>
  <div class="grid grid-3" style="margin-top:28px;">{cards}</div>
</div>
'''
    html = page_shell(depth=depth, title="Blog | CalcBeam", description="Plain-language guides on percentages, interest, GPA, tax, and the math behind CalcBeam's calculators.",
        canonical="blog/index.html", active_url="blog/index.html", body=body, schemas=[ld])
    write("blog/index.html", html)

if __name__ == "__main__":
    build_blog_index()
    for a in ARTICLES:
        build_article(a)
    print("Blog built.")
