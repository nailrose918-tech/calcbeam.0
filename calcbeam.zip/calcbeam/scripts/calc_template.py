from generate import *

def build_calculator_page(*, slug, name, category, category_url, title, description,
                           intro, tool_html, how_to, formula_html, example_html,
                           explanation, mistakes, faqs, related, js_file, extra_head=""):
    depth = 0
    url = f"{slug}.html"
    crumb_html, crumb_ld = breadcrumb_html(depth, [("Home","index.html"),("Calculators","calculators.html"),(category, category_url),(name, None)])
    how_to_items = "".join(f"<li>{step}</li>" for step in how_to)
    mistake_items = "".join(f"<li>{m}</li>" for m in mistakes)
    faqs_block = faq_html(faqs)
    related_block = related_html(depth, related)

    body = f'''{crumb_html}
<div class="container">
  <h1>{name}</h1>
  <div class="beam-rule"></div>
  <p class="lede" style="color:var(--ink-soft);max-width:70ch;">{intro}</p>

  <div class="tool-wrap">
    <div class="tool-card">
      {tool_html}
    </div>
    <aside class="result-card" id="resultCard" aria-live="polite">
      <h3>Result</h3>
      <div id="resultBody"><p class="result-empty">Fill in the fields to see your result.</p></div>
    </aside>
  </div>

  <div class="ad-slot in-article">Advertisement</div>

  <article class="prose">
    <h2>How to use the {name}</h2>
    <ol>{how_to_items}</ol>

    <h2>Formula</h2>
    <div class="formula-box">{formula_html}</div>

    <h2>Worked example</h2>
    <div class="example-box">{example_html}</div>

    <h2>What this number means</h2>
    {explanation}

    <h2>Common mistakes</h2>
    <ul class="mistake-list">{mistake_items}</ul>

    <h2>Frequently asked questions</h2>
    {faqs_block}

    <h2>Related calculators</h2>
    {related_block}
  </article>
</div>
'''
    faq_ld = faq_schema(faqs)
    html = page_shell(depth=depth, title=title, description=description, canonical=url,
        active_url="calculators.html", body=body, schemas=[crumb_ld, faq_ld],
        extra_head=f'<script defer src="js/calculators/utils.js"></script><script defer src="js/calculators/{js_file}"></script>{extra_head}')
    write(url, html)
