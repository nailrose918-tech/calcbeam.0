#!/usr/bin/env python3
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from generate import *

CALC_ICONS = {
  "percentage-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/><path d="M19 5L5 19"/></svg>',
  "age-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>',
  "bmi-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
  "mortgage-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 11l8-7 8 7"/><path d="M6 10v10h12V10"/><path d="M10 20v-6h4v6"/></svg>',
  "loan-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="7" width="18" height="12" rx="2"/><path d="M3 11h18M8 15h3"/></svg>',
  "compound-interest-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 17l5-6 4 3 6-8"/><path d="M14 6h4v4"/></svg>',
  "discount-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 12L12 20 4 12V4h8z"/><circle cx="8.5" cy="8.5" r="1"/></svg>',
  "gpa-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M22 10L12 5 2 10l10 5 10-5z"/><path d="M6 12v5c3 2 9 2 12 0v-5"/></svg>',
  "unit-converter": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M7 10h13l-4-4M17 14H4l4 4"/></svg>',
  "scientific-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 7h8M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/></svg>',
  "date-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M8 15l2 2 4-4"/></svg>',
  "tip-calculator": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2v20M17 6H9.5a2.5 2.5 0 000 5H14a2.5 2.5 0 010 5H7"/></svg>',
  "default": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 12h8M12 8v8"/></svg>',
}

def calc_card(depth, c):
    icon = CALC_ICONS.get(c["id"], CALC_ICONS["default"])
    return f'''<a class="card calc-card" href="{rel(c["url"], depth)}">
      <div class="ci">{icon}</div>
      <span class="cat-tag">{c["cat"]}</span>
      <h3>{c["name"]}</h3>
      <p>{c["desc"]}</p>
    </a>'''

# Mirror the JS registry so Python can render cards server-side (kept in sync manually — see README).
CALCS = [
  dict(id="percentage-calculator", name="Percentage Calculator", cat="Math", url="percentage-calculator.html", desc="Find a percentage of a number, percentage change, and more."),
  dict(id="average-calculator", name="Average Calculator", cat="Math", url="average-calculator.html", desc="Mean, median, mode and range for any list of numbers."),
  dict(id="ratio-calculator", name="Ratio Calculator", cat="Math", url="ratio-calculator.html", desc="Simplify ratios, compare ratios, and solve for a missing value."),
  dict(id="fraction-calculator", name="Fraction Calculator", cat="Math", url="fraction-calculator.html", desc="Add, subtract, multiply and divide fractions with steps."),
  dict(id="scientific-calculator", name="Scientific Calculator", cat="Math", url="scientific-calculator.html", desc="Full scientific calculator with trig, logs, powers and roots."),
  dict(id="mortgage-calculator", name="Mortgage Calculator", cat="Finance", url="mortgage-calculator.html", desc="Estimate your monthly mortgage payment including tax and insurance."),
  dict(id="loan-calculator", name="Loan Calculator", cat="Finance", url="loan-calculator.html", desc="Monthly payment, total interest and payoff for any loan."),
  dict(id="compound-interest-calculator", name="Compound Interest Calculator", cat="Finance", url="compound-interest-calculator.html", desc="See how savings grow with compounding and regular contributions."),
  dict(id="simple-interest-calculator", name="Simple Interest Calculator", cat="Finance", url="simple-interest-calculator.html", desc="Calculate interest earned or owed using the simple interest formula."),
  dict(id="investment-calculator", name="Investment Calculator", cat="Finance", url="investment-calculator.html", desc="Project the future value of an investment with monthly contributions."),
  dict(id="discount-calculator", name="Discount Calculator", cat="Finance", url="discount-calculator.html", desc="Work out the sale price and amount saved on any discount."),
  dict(id="sales-tax-calculator", name="Sales Tax Calculator", cat="Finance", url="sales-tax-calculator.html", desc="Add or remove sales tax from a price in seconds."),
  dict(id="tip-calculator", name="Tip Calculator", cat="Finance", url="tip-calculator.html", desc="Split the bill and calculate the right tip per person."),
  dict(id="profit-margin-calculator", name="Profit Margin Calculator", cat="Finance", url="profit-margin-calculator.html", desc="Calculate profit, margin percentage and markup from cost and revenue."),
  dict(id="roi-calculator", name="ROI Calculator", cat="Finance", url="roi-calculator.html", desc="Calculate return on investment as a percentage and annualized rate."),
  dict(id="markup-calculator", name="Markup Calculator", cat="Finance", url="markup-calculator.html", desc="Turn cost into selling price using a target markup percentage."),
  dict(id="bmi-calculator", name="BMI Calculator", cat="Health", url="bmi-calculator.html", desc="Body mass index from height and weight, metric or imperial."),
  dict(id="calorie-calculator", name="Calorie Calculator", cat="Health", url="calorie-calculator.html", desc="Estimate daily calorie needs based on age, sex and activity level."),
  dict(id="gpa-calculator", name="GPA Calculator", cat="Education", url="gpa-calculator.html", desc="Calculate your grade point average from courses and credit hours."),
  dict(id="grade-calculator", name="Grade Calculator", cat="Education", url="grade-calculator.html", desc="Find your current grade and the score you need on the final."),
  dict(id="age-calculator", name="Age Calculator", cat="Date & Time", url="age-calculator.html", desc="Exact age in years, months and days, plus your next birthday."),
  dict(id="date-calculator", name="Date Calculator", cat="Date & Time", url="date-calculator.html", desc="Add or subtract days from a date, or find the days between two dates."),
  dict(id="time-calculator", name="Time Calculator", cat="Date & Time", url="time-calculator.html", desc="Add or subtract hours, minutes and seconds, or find a duration."),
  dict(id="unit-converter", name="Unit Converter", cat="Conversion", url="unit-converter.html", desc="Convert length, weight, temperature, area, volume and speed."),
  dict(id="fuel-cost-calculator", name="Fuel Cost Calculator", cat="Conversion", url="fuel-cost-calculator.html", desc="Estimate trip fuel use and cost from distance and efficiency."),
]

LIVE_IDS = {c["id"] for c in CALCS}  # all 25 calculators are now live

POPULAR = ["percentage-calculator","mortgage-calculator","bmi-calculator","loan-calculator",
           "tip-calculator","age-calculator","gpa-calculator","unit-converter"]

# ---------------- HOMEPAGE ----------------
def build_home():
    depth = 0
    popular_cards = "\n".join(calc_card(depth, next(c for c in CALCS if c["id"]==pid)) for pid in POPULAR)
    cat_cards = "\n".join(
        f'''<a class="card cat-card" href="{rel(url, depth)}">
          <h3>{name}</h3>
          <p class="count">{sum(1 for c in CALCS if c["cat"]==name)} calculators</p>
          <span style="color:var(--beam);font-weight:600;font-size:.88rem;">Browse &rarr;</span>
        </a>''' for name, url in CATEGORIES
    )
    body = f'''
<section class="hero">
  <div class="container hero-grid">
    <div>
      <span class="eyebrow">100% Free &middot; No Sign-up &middot; Works Offline</span>
      <h1>Smart Calculators.<br>Simple Answers.</h1>
      <p class="lede">Free online calculators for math, finance, health, education, and everyday calculations — all running instantly in your browser.</p>
      <form class="search-box" id="headerSearchForm" role="search">
        <label class="visually-hidden" for="headerSearchInput">Search calculators</label>
        <input id="headerSearchInput" type="text" placeholder="Search 25 calculators… try “interest” or “BMI”" autocomplete="off">
        <button type="submit" aria-label="Search">{icon_svg('search')}</button>
        <div class="search-results" id="headerSearchResults"></div>
      </form>
    </div>
    <div class="tool-card" aria-label="Live percentage calculator example">
      <h3 style="font-size:.8rem;text-transform:uppercase;letter-spacing:.08em;color:var(--ink-faint);margin-bottom:16px;">Try it now &mdash; % of a number</h3>
      <div class="field-row">
        <div class="field">
          <label for="heroA">Percentage</label>
          <div class="input-suffix"><input type="number" id="heroA" value="15" inputmode="decimal"><span>%</span></div>
        </div>
        <div class="field">
          <label for="heroB">Of number</label>
          <input type="number" id="heroB" value="240" inputmode="decimal">
        </div>
      </div>
      <div class="beam-underline filled" style="margin-top:4px;"></div>
      <div class="readout" id="heroResult">36.00</div>
      <p style="color:var(--ink-faint);font-size:.82rem;margin-top:10px;">This is a live preview. <a href="{rel('percentage-calculator.html', depth)}">Open the full Percentage Calculator &rarr;</a></p>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0;">
  <div class="container">
    <div class="section-head"><h2>Popular calculators</h2><a href="{rel('calculators.html', depth)}">View all 25 &rarr;</a></div>
    <div class="grid grid-4">{popular_cards}</div>
  </div>
</section>

<section class="section" id="recentSection" style="padding-top:0;">
  <div class="container">
    <div class="section-head"><h2>Recently used</h2></div>
    <div class="recent-strip" id="recentStrip"></div>
  </div>
</section>

<section class="section" style="background:var(--surface);border-top:1px solid var(--line);border-bottom:1px solid var(--line);padding-top:0;">
  <div class="container">
    <div class="section-head" style="padding-top:56px;"><h2>Browse by category</h2></div>
    <div class="grid grid-3">{cat_cards}</div>
  </div>
</section>

<section class="section">
  <div class="container two-col">
    <div>
      <h2>Why people use CalcBeam</h2>
      <p style="color:var(--ink-soft);">CalcBeam is built to answer one question at a time, quickly and clearly. Every calculator runs entirely in your browser — nothing you type is uploaded anywhere, there's nothing to install, and results update instantly.</p>
      <p style="color:var(--ink-soft);">Each tool includes a plain-language explanation of the formula behind it, a worked example, and answers to the questions people actually ask, so you understand the "why" behind the number — not just the number itself.</p>
    </div>
    <div>
      <div class="ad-slot leaderboard">Advertisement</div>
    </div>
  </div>
</section>
'''
    schemas = [
        {"@context":"https://schema.org","@type":"WebSite","name":"CalcBeam","url":SITE+"/",
         "potentialAction":{"@type":"SearchAction","target":SITE+"/search.html?q={search_term_string}","query-input":"required name=search_term_string"}},
        {"@context":"https://schema.org","@type":"Organization","name":"CalcBeam","url":SITE+"/","logo":SITE+"/assets/logo.svg"},
    ]
    html = page_shell(depth=depth, title="CalcBeam – Free Online Calculators for Math, Finance, Health & More",
        description="Free online calculators for math, finance, health, education, and everyday calculations. Fast, accurate, and instant — no sign-up required.",
        canonical="index.html", active_url="index.html", body=body, schemas=schemas,
        extra_head=f'<script defer src="{rel("js/main.js",depth)}"></script><script defer>document.addEventListener("DOMContentLoaded",function(){{function u(){{var a=parseFloat(document.getElementById("heroA").value)||0,b=parseFloat(document.getElementById("heroB").value)||0;document.getElementById("heroResult").textContent=((a/100)*b).toLocaleString("en-US",{{minimumFractionDigits:2,maximumFractionDigits:2}});}}document.getElementById("heroA").addEventListener("input",u);document.getElementById("heroB").addEventListener("input",u);}});</script>')
    write("index.html", html)

# ---------------- CALCULATORS HUB ----------------
def build_calculators_hub():
    depth = 0
    cards = "\n".join(calc_card(depth, c) for c in CALCS)
    body = f'''
{breadcrumb_html(depth, [("Home","index.html"),("Calculators", None)])[0]}
<div class="container">
  <h1>All Calculators</h1>
  <p class="lede" style="color:var(--ink-soft);max-width:65ch;">Browse all 25 CalcBeam calculators, organized alphabetically. Use the search bar above or jump to a <a href="{rel('calculators.html',depth)}">category</a> to narrow things down.</p>
  <div class="grid grid-4" style="margin-top:28px;">
    {cards}
  </div>
</div>
'''
    schema, ld = breadcrumb_html(depth, [("Home","index.html"),("Calculators", None)])
    html = page_shell(depth=depth, title="All Calculators — 25 Free Tools | CalcBeam",
        description="Browse all 25 free CalcBeam calculators for math, finance, health, education, date & time, and unit conversion.",
        canonical="calculators.html", active_url="calculators.html", body=body, schemas=[ld])
    write("calculators.html", html)

# ---------------- CATEGORY PAGES ----------------
CATEGORY_INTROS = {
  "Math": "Core math tools for percentages, ratios, fractions, averages, and full scientific calculations.",
  "Finance": "Loan, mortgage, interest, tax and profit calculators for everyday financial decisions.",
  "Health": "Simple health estimators for body mass index and daily calorie needs.",
  "Education": "GPA and grade calculators built for students tracking coursework.",
  "Date & Time": "Work out ages, date differences, and durations down to the day.",
  "Conversion": "Convert between units of length, weight, temperature, area, volume, speed and fuel cost.",
}

def build_category_pages():
    depth = 0
    for name, url in CATEGORIES:
        items = [c for c in CALCS if c["cat"] == name]
        cards = "\n".join(calc_card(depth, c) for c in items)
        crumb_html, ld = breadcrumb_html(depth, [("Home","index.html"),("Calculators","calculators.html"),(name, None)])
        body = f'''
{crumb_html}
<div class="container">
  <h1>{name} Calculators</h1>
  <p class="lede" style="color:var(--ink-soft);max-width:65ch;">{CATEGORY_INTROS[name]}</p>
  <div class="grid grid-4" style="margin-top:28px;">{cards}</div>
</div>
'''
        html = page_shell(depth=depth, title=f"{name} Calculators — Free & Instant | CalcBeam",
            description=f"{CATEGORY_INTROS[name]} All free, instant, and running in your browser.",
            canonical=url, active_url="calculators.html", body=body, schemas=[ld])
        write(url, html)

# ---------------- ABOUT / CONTACT / LEGAL / SEARCH / 404 ----------------
def simple_page(path, title, meta_desc, h1, body_inner, active=""):
    depth = 0
    crumb, ld = breadcrumb_html(depth, [("Home","index.html"),(h1, None)])
    body = f'''{crumb}
<div class="container legal-page">
  <h1>{h1}</h1>
  <div class="prose">{body_inner}</div>
</div>'''
    html = page_shell(depth=depth, title=title, description=meta_desc, canonical=path, active_url=active, body=body, schemas=[ld])
    write(path, html)

def build_about():
    body = '''
<p>CalcBeam is a free collection of browser-based calculators for math, finance, health, education, date &amp; time, and unit conversion. The goal is simple: give people a fast, accurate answer without ads blocking the calculator, without an account, and without sending any of their numbers to a server.</p>
<h2>How CalcBeam works</h2>
<p>Every calculator on this site runs entirely as HTML, CSS and JavaScript in your own browser. When you type a number into a CalcBeam calculator, that number is never transmitted anywhere — the math happens on your device and stays there.</p>
<h2>What CalcBeam is not</h2>
<p>CalcBeam calculators produce estimates based on standard formulas. They are not a substitute for advice from a qualified financial advisor, doctor, accountant, or lender. Always confirm important decisions — a mortgage, a medical question, a tax filing — with a licensed professional.</p>
<h2>Who built it</h2>
<p>CalcBeam is an independent, ad-supported website. It is not affiliated with any bank, lender, gym, university, or government agency referenced in its calculators.</p>
'''
    simple_page("about.html", "About CalcBeam | Free Online Calculators", "Learn what CalcBeam is, how the calculators work, and what they are not intended for.", "About CalcBeam", body, active="about.html")

def build_contact():
    body = '''
<p>Have a question, spotted a bug, or want to suggest a calculator CalcBeam should add? Reach out using the details below.</p>
<h2>General inquiries</h2>
<p>Email: <a href="mailto:hello@calcbeam.com">hello@calcbeam.com</a></p>
<h2>Report a calculation issue</h2>
<p>If you believe a calculator is producing an incorrect result, please tell us the calculator name, the exact inputs you used, and the result you expected. This helps us verify and fix issues quickly.</p>
<h2>Advertising &amp; partnerships</h2>
<p>Email: <a href="mailto:ads@calcbeam.com">ads@calcbeam.com</a></p>
'''
    simple_page("contact.html", "Contact CalcBeam", "Get in touch with the CalcBeam team for questions, bug reports, or partnership inquiries.", "Contact Us", body, active="contact.html")

def build_privacy():
    body = '''
<p>Last updated: August 2026</p>
<h2>What we collect</h2>
<p>CalcBeam calculators run in your browser. Numbers you type into a calculator are processed locally on your device and are not sent to CalcBeam's servers. CalcBeam may use standard, privacy-respecting analytics to understand which pages are visited, and may display advertising through third-party networks such as Google AdSense.</p>
<h2>Cookies &amp; local storage</h2>
<p>CalcBeam uses your browser's local storage to remember your dark/light mode preference and your recently used calculators. This information stays on your device and can be cleared at any time through your browser settings. See our <a href="cookie-policy.html">Cookie Policy</a> for details.</p>
<h2>Third-party advertising</h2>
<p>CalcBeam may work with advertising partners, including Google, which may use cookies to serve ads based on your prior visits to this or other websites. You can opt out of personalized advertising through Google's Ads Settings.</p>
<h2>Children's privacy</h2>
<p>CalcBeam does not knowingly collect personal information from children under 13.</p>
<h2>Contact</h2>
<p>Questions about this policy can be sent to <a href="mailto:hello@calcbeam.com">hello@calcbeam.com</a>.</p>
'''
    simple_page("privacy-policy.html", "Privacy Policy | CalcBeam", "How CalcBeam handles data, cookies, local storage, and third-party advertising.", "Privacy Policy", body)

def build_terms():
    body = '''
<p>Last updated: August 2026</p>
<h2>Use of the site</h2>
<p>CalcBeam grants you a limited, non-exclusive license to use this website and its calculators for personal or internal business purposes. You may not copy, scrape, or republish CalcBeam's content or code as your own product.</p>
<h2>No warranty</h2>
<p>Calculators are provided "as is," without warranty of any kind. While CalcBeam aims for mathematical accuracy, results are estimates and may not reflect your exact real-world circumstances, fees, or local rules.</p>
<h2>Limitation of liability</h2>
<p>CalcBeam is not liable for financial, medical, academic, or other decisions made based on results from this website. See our <a href="disclaimer.html">Disclaimer</a> for more detail.</p>
<h2>Changes</h2>
<p>These terms may be updated periodically. Continued use of CalcBeam after changes means you accept the revised terms.</p>
'''
    simple_page("terms.html", "Terms & Conditions | CalcBeam", "The terms governing your use of CalcBeam's calculators and website.", "Terms & Conditions", body)

def build_disclaimer():
    body = '''
<h2>General</h2>
<p>CalcBeam provides free calculators for informational and educational purposes only. Results are estimates based on the inputs you provide and standard formulas — they are not guarantees.</p>
<h2>Financial calculators</h2>
<p>Mortgage, loan, interest, investment, ROI, and similar calculators do not account for every fee, tax rule, or lender-specific term. They are not financial advice. Consult a licensed financial professional before making financial decisions.</p>
<h2>Health calculators</h2>
<p>BMI and calorie calculators provide general estimates only and are not medical advice. They do not account for individual health conditions. Consult a doctor or registered dietitian for personalized guidance.</p>
<h2>Education calculators</h2>
<p>GPA and grade calculators follow common grading conventions but may not match your specific school's grading scale or policy.</p>
'''
    simple_page("disclaimer.html", "Disclaimer | CalcBeam", "CalcBeam calculators provide estimates only and are not financial, medical, or professional advice.", "Disclaimer", body)

def build_cookie_policy():
    body = '''
<h2>What cookies and local storage do we use?</h2>
<p>CalcBeam uses your browser's <code>localStorage</code> to remember your theme preference (light or dark mode) and a short list of your recently used calculators. This data never leaves your device.</p>
<h2>Third-party cookies</h2>
<p>If CalcBeam displays advertising, ad providers such as Google may set their own cookies to measure ad performance and, where permitted, personalize ads. CalcBeam does not control these third-party cookies directly.</p>
<h2>Managing cookies</h2>
<p>You can clear cookies and local storage at any time through your browser's settings, or opt out of personalized ads via your ad provider's preference tools.</p>
'''
    simple_page("cookie-policy.html", "Cookie Policy | CalcBeam", "How CalcBeam uses local storage and third-party cookies.", "Cookie Policy", body)

def build_search_page():
    depth = 0
    crumb, ld = breadcrumb_html(depth, [("Home","index.html"),("Search", None)])
    body = f'''{crumb}
<div class="container">
  <h1>Search Calculators</h1>
  <form class="search-box" id="pageSearchForm" role="search" style="max-width:640px;margin-bottom:28px;">
    <label class="visually-hidden" for="pageSearchInput">Search calculators</label>
    <input id="pageSearchInput" type="text" placeholder="Try “interest”, “BMI”, “age”, or “convert”" autocomplete="off">
    <button type="submit" aria-label="Search">{icon_svg('search')}</button>
  </form>
  <div id="pageSearchOutput" class="grid grid-3"></div>
</div>
<script src="js/main.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function(){{
  var input = document.getElementById("pageSearchInput");
  var out = document.getElementById("pageSearchOutput");
  var params = new URLSearchParams(window.location.search);
  function render(q){{
    var matches = searchCalculators(q);
    if(q.trim() === ""){{ out.innerHTML = ""; return; }}
    if(matches.length === 0){{ out.innerHTML = '<p style="color:var(--ink-faint);">No calculators matched "'+q+'".</p>'; return; }}
    out.innerHTML = matches.map(function(c){{
      return '<a class="card calc-card" href="'+c.url+'"><span class="cat-tag">'+c.cat+'</span><h3>'+c.name+'</h3><p>'+c.desc+'</p></a>';
    }}).join("");
  }}
  var q0 = params.get("q") || "";
  input.value = q0;
  render(q0);
  input.addEventListener("input", function(){{ render(input.value); }});
  document.getElementById("pageSearchForm").addEventListener("submit", function(e){{ e.preventDefault(); render(input.value); }});
}});
</script>
'''
    html = page_shell(depth=depth, title="Search Calculators | CalcBeam",
        description="Search CalcBeam's full library of free calculators by name, category, or keyword.",
        canonical="search.html", body=body, schemas=[ld])
    write("search.html", html)

def build_404():
    depth = 0
    body = '''
<div class="container error-page">
  <div class="code">404</div>
  <h1>Page not found</h1>
  <p style="color:var(--ink-soft);max-width:44ch;margin:0 auto 24px;">The page you're looking for doesn't exist or may have moved. Try searching for a calculator instead.</p>
  <a class="btn btn-primary" href="index.html">Back to homepage</a>
</div>
'''
    html = page_shell(depth=depth, title="Page Not Found | CalcBeam", description="This page could not be found.",
        canonical="404.html", body=body)
    write("404.html", html)

if __name__ == "__main__":
    build_home()
    build_calculators_hub()
    build_category_pages()
    build_about()
    build_contact()
    build_privacy()
    build_terms()
    build_disclaimer()
    build_cookie_policy()
    build_search_page()
    build_404()
