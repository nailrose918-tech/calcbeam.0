#!/usr/bin/env python3
"""
CalcBeam static site generator.
Produces plain .html files (no build step needed at runtime — this script
is only a content-authoring convenience; the OUTPUT is pure static HTML/CSS/JS).
"""
import os, json, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # project root, one level up from /scripts
SITE = "https://calcbeam.com"  # placeholder domain — replace in README step 1

NAV_LINKS = [
    ("Home", "index.html"),
    ("Calculators", "calculators.html"),
    ("Blog", "blog/index.html"),
    ("About", "about.html"),
    ("Contact", "contact.html"),
]

CATEGORIES = [
    ("Math", "math-calculators.html"),
    ("Finance", "finance-calculators.html"),
    ("Health", "health-calculators.html"),
    ("Education", "education-calculators.html"),
    ("Date & Time", "date-time-calculators.html"),
    ("Conversion", "conversion-calculators.html"),
]

LEGAL_LINKS = [
    ("Privacy Policy", "privacy-policy.html"),
    ("Terms & Conditions", "terms.html"),
    ("Disclaimer", "disclaimer.html"),
    ("Cookie Policy", "cookie-policy.html"),
]

def rel(path, depth):
    """depth=0 for root pages, 1 for /blog/ pages -> prefix ../ as needed."""
    return ("../" * depth) + path

def icon_svg(name):
    icons = {
        "search": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>',
        "sun": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
        "menu": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>',
    }
    return icons[name]

def logo_svg():
    return '''<svg width="30" height="30" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <rect width="40" height="40" rx="11" fill="var(--beam)"/>
      <path d="M11 27L20 11L20 21L29 21L20 29" stroke="white" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
    </svg>'''

def header_html(depth, active_url=""):
    logo_link = rel("index.html", depth)
    nav_items = "\n".join(
        f'<a href="{rel(url, depth)}"{" aria-current=\"page\"" if url == active_url else ""}>{label}</a>'
        for label, url in NAV_LINKS
    )
    return f'''<header class="site-header">
  <div class="container nav-row">
    <a class="brand" href="{logo_link}">
      {logo_svg()}
      <span>CalcBeam<small>Smart Calculators. Simple Answers.</small></span>
    </a>
    <nav class="main-nav" id="mainNav" aria-label="Primary">
      {nav_items}
    </nav>
    <div class="nav-actions">
      <div class="search-box" style="display:none" id="navSearchBox"></div>
      <button class="icon-btn" id="themeToggle" aria-label="Toggle dark mode" type="button">{icon_svg("sun")}</button>
      <button class="icon-btn menu-toggle" id="menuToggle" aria-label="Open menu" aria-expanded="false" type="button">{icon_svg("menu")}</button>
    </div>
  </div>
</header>'''

def footer_html(depth):
    cat_items = "\n".join(f'<li><a href="{rel(url, depth)}">{name}</a></li>' for name, url in CATEGORIES)
    legal_items = "\n".join(f'<li><a href="{rel(url, depth)}">{name}</a></li>' for name, url in LEGAL_LINKS)
    return f'''<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <a class="brand" href="{rel('index.html', depth)}" style="margin-bottom:12px;">
          {logo_svg()}
          <span>CalcBeam</span>
        </a>
        <p style="color:var(--ink-soft);font-size:.9rem;max-width:34ch;">Free, fast, browser-based calculators for math, finance, health, education and everyday life.</p>
      </div>
      <div>
        <h4>Categories</h4>
        <ul>{cat_items}</ul>
      </div>
      <div>
        <h4>Company</h4>
        <ul>
          <li><a href="{rel('about.html', depth)}">About</a></li>
          <li><a href="{rel('contact.html', depth)}">Contact</a></li>
          <li><a href="{rel('blog/index.html', depth)}">Blog</a></li>
          <li><a href="{rel('search.html', depth)}">Search</a></li>
        </ul>
      </div>
      <div>
        <h4>Legal</h4>
        <ul>{legal_items}</ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; 2026 CalcBeam. All calculations are estimates for informational purposes only.</span>
      <span>Built with HTML, CSS &amp; JavaScript.</span>
    </div>
  </div>
</footer>'''

def breadcrumb_html(depth, trail):
    """trail = list of (label, url_or_None). Last item has no link."""
    parts = []
    ld_items = []
    for i, (label, url) in enumerate(trail):
        if url:
            parts.append(f'<a href="{rel(url, depth)}">{label}</a>')
        else:
            parts.append(f'<span aria-current="page">{label}</span>')
        ld_items.append({
            "@type": "ListItem", "position": i + 1, "name": label,
            "item": f"{SITE}/{url}" if url else f"{SITE}/{trail[-1][1] or ''}"
        })
    schema = {
        "@context": "https://schema.org", "@type": "BreadcrumbList",
        "itemListElement": ld_items
    }
    html = f'<nav class="breadcrumb container" aria-label="Breadcrumb">{" &rsaquo; ".join(parts)}</nav>'
    return html, schema

def faq_schema(faqs):
    return {
        "@context": "https://schema.org", "@type": "FAQPage",
        "mainEntity": [
            {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}}
            for q, a in faqs
        ]
    }

def faq_html(faqs):
    items = "\n".join(f'''<details class="faq-item">
        <summary class="faq-q">{q}<span class="plus">+</span></summary>
        <div class="faq-a">{a}</div>
      </details>''' for q, a in faqs)
    return f'<div class="faq-list">{items}</div>'

def related_html(depth, items):
    """items = list of (label, url)"""
    links = "\n".join(f'<a href="{rel(url, depth)}">{label}</a>' for label, url in items)
    return f'<div class="related-list">{links}</div>'

def page_shell(*, depth, title, description, canonical, active_url="", body, schemas=None,
               og_type="website", extra_head=""):
    schemas = schemas or []
    schema_tags = "\n".join(
        f'<script type="application/ld+json">{json.dumps(s)}</script>' for s in schemas
    )
    css_href = rel("css/style.css", depth)
    js_main = rel("js/main.js", depth)
    canonical_url = f"{SITE}/{canonical}"
    og_image = f"{SITE}/{rel('assets/images/og-default.svg', 0)}"
    return f'''<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<meta name="description" content="{description}">
<link rel="canonical" href="{canonical_url}">
<meta name="robots" content="index, follow">
<meta property="og:type" content="{og_type}">
<meta property="og:site_name" content="CalcBeam">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{description}">
<meta property="og:url" content="{canonical_url}">
<meta property="og:image" content="{og_image}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{title}">
<meta name="twitter:description" content="{description}">
<link rel="icon" href="{rel('assets/favicon.svg', depth)}" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{css_href}">
{extra_head}
{schema_tags}
</head>
<body>
<a class="visually-hidden" href="#main">Skip to content</a>
{header_html(depth, active_url)}
<main id="main">
{body}
</main>
{footer_html(depth)}
<script src="{js_main}"></script>
</body>
</html>'''

def write(path, html):
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(html)
    print("wrote", path)
